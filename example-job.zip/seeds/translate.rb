require 'openstudio'

include OpenStudio::Model

def osload(path)
  translator = OpenStudio::OSVersion::VersionTranslator.new
  ospath = OpenStudio::Path.new(path)
  model = translator.loadModel(ospath)
  if model.empty?
    raise "Path '#{path}' is not a valid path to an OpenStudio Model"
  else
    model =  model.get
  end
  return model
end

m = osload('SeedModel.osm')
m.save('SeedModel.osm')
