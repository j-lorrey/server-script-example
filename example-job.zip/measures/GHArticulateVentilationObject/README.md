

###### (Automatically generated documentation)

# GH_ArticulateVentilationObject

## Description
This measure is used to approximate an Ventilatoin controller beating a human controller on the deadband width of closing ventilation openings

## Modeler Description
Looks at the OS:ZoneVentilation:DesignFlowRate object and changes the Minimum temperatures (indoor and outdoor) to lower if done manually and higher if done automatically.... IE a broader deadband on closed versus open.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Ventilation/Heating Automatic Controls present?

**Name:** controller_incl,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Degrees Fahrenheit to Adjust heating Setpoint By

**Name:** heating_adjustment,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Amount of Airchange from ventilation system

**Name:** ventilation_ach,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




