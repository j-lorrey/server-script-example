# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class GHArticulateVentilationObject < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'GH_ArticulateVentilationObject'
  end

  # human readable description
  def description
    return 'This measure is used to approximate an Ventilatoin controller beating a human controller on the deadband width of closing ventilation openings'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Looks at the OS:ZoneVentilation:DesignFlowRate object and changes the Minimum temperatures (indoor and outdoor) to lower if done manually and higher if done automatically.... IE a broader deadband on closed versus open.'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # a vector of choices
    controller = OpenStudio::StringVector.new
    controller << 'Yes'
    controller << 'No'
    
    controller_incl = OpenStudio::Ruleset::OSArgument::makeChoiceArgument("controller_incl",controller,true)
    controller_incl.setDisplayName("Ventilation/Heating Automatic Controls present?")
    controller_incl.setDefaultValue("Yes")
    args << controller_incl

    # during development I used indoor min, but for now I am going to hard code the dT for the tolerance difference between controlled and uncontrolled at 5degF
    # later it may be required to characterize the delta

    # indoor_min = OpenStudio::Measure::OSArgument.makeDoubleArgument("indoor_min", true)
    # indoor_min.setDisplayName('This is the lower indoor threshold in degF')
    # indoor_min.setDefaultValue(55)
    # args << indoor_min

    # outdoor_min = OpenStudio::Measure::OSArgument.makeDoubleArgument("outdoor_min", true)
    # outdoor_min.setDisplayName('This is the lower outdoor threshold in degF')
    # outdoor_min.setDefaultValue(55)
    # args << outdoor_min
    
    heating_adjustment = OpenStudio::Measure::OSArgument.makeDoubleArgument('heating_adjustment', true)
    heating_adjustment.setDisplayName('Degrees Fahrenheit to Adjust heating Setpoint By')
    heating_adjustment.setDefaultValue(60)
    args << heating_adjustment

    ventilation_ach = OpenStudio::Measure::OSArgument.makeDoubleArgument('ventilation_ach', true)
    ventilation_ach.setDisplayName('Amount of Airchange from ventilation system')
    ventilation_ach.setDefaultValue(13)
    args << ventilation_ach

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # # assign the user inputs to variables
    
    # use the tolerance and heating adjustment numbers to control these from front end instead of direct input
    # indoor_min = runner.getDoubleArgumentValue("indoor_min", user_arguments)
    # outdoor_min = runner.getDoubleArgumentValue("outdoor_min", user_arguments)
    heating_adjustment = runner.getDoubleArgumentValue('heating_adjustment', user_arguments)
    ventilation_ach = runner.getDoubleArgumentValue('ventilation_ach', user_arguments)

    controller_incl = runner.getStringArgumentValue('controller_incl', user_arguments)

    heating_adjustment_c = OpenStudio.convert(heating_adjustment,"F","C")
    
    # Cast OpenStudio OptionalDouble to Float for arithmetic
    heating_adjustment_c = heating_adjustment_c.to_f

    #If statement for Controller "yes" or "no" infleuencing the control tolerance

    if controller_incl == "Yes"
      tolerance = 0
    else
    tolerance = 2.77778 # In Kelvin  aka 5degF(R)
    end
    
    deadband = 2.22222 #In Kelvin aka 4degF(R)

    indoor_min_c = heating_adjustment_c - tolerance
    outdoor_min_c = heating_adjustment_c - tolerance

    # indoor_min_c = ((indoor_min-32)*(5/9))
   
    # setup OpenStudio units that we will need
    # temperature_ip_unit = OpenStudio.createUnit('F').get
    # temperature_si_unit = OpenStudio.createUnit('C').get

    # define starting units
    # indoor_min_ip = OpenStudio::Quantity.new(indoor_min, temperature_ip_unit)

    # indoor_min_c = OpenStudio.convert(indoor_min,"F","C")
    # indoor_min_c = indoor_min_c.to_f

    # indoor_min_c = indoor_min-32

    puts "MinimumIndoorTemp is set at degC"
    puts indoor_min_c

        # model.getZoneVentilationDesignFlowRateFields.each do |mintemp|
    #   mintemp = mintemp.to_ZoneVentilation_DesignFlowRateFields.get
    #   mintemp.setMinimumIndoorTemperature(indoor_min_c)
    # end


    
    # This is the try for getModelObjectsByName

    # variable = model.getModelObjectsByName('Natural Ventilation', true)
    # variable = variable[0]
    # variable = variable.to_ZoneVentilationDesignFlowRate.get
    # variable.setMinimumIndoorTemperature(indoor_min_c)
    
    naturalvent = model.getZoneVentilationDesignFlowRates.each do |naturalvent|
      if naturalvent.name.get.match("Natural Ventilation")
        naturalvent.setMinimumIndoorTemperature(indoor_min_c)
        naturalvent.setMinimumOutdoorTemperature(outdoor_min_c)
        naturalvent.setAirChangesperHour(ventilation_ach)
      end
    end
    

    

    return true
  end
end

# register the measure to be used by the application
GHArticulateVentilationObject.new.registerWithApplication
