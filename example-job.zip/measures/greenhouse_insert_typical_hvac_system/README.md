

###### (Automatically generated documentation)

# Greenhouse_Insert_Typical_HVAC_system

## Description
Draft of a measure for tweaking greenhouse systems without using Create Typical

## Modeler Description
references the standards gem directly so as to access the model_add_hvac_system method directly

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Enter the System Type

**Name:** system_type,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false






