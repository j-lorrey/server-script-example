

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class GreenhouseInsertTypicalHVACSystem < OpenStudio::Measure::ModelMeasure

  # JWT32

  require 'openstudio-standards'

  # load OpenStudio measure libraries from openstudio-extension gem
  require 'openstudio-extension'
  require 'openstudio/extension/core/os_lib_helper_methods'
  require 'openstudio/extension/core/os_lib_model_generation.rb'

  # require_relative 'resources/os_lib_model_generation.rb'

  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'Greenhouse_Insert_Typical_HVAC_system'
  end

  # human readable description
  def description
    return 'Draft of a measure for tweaking greenhouse systems without using Create Typical'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'references the standards gem directly so as to access the model_add_hvac_system method directly'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # # make a choice argument for model objects
    # space_handles = OpenStudio::StringVector.new
    # space_display_names = OpenStudio::StringVector.new

    # # putting model object and names into hash
    # space_args = model.getThermalZones
    # space_args_hash = {}
    # space_args.each do |space_arg|
    #   space_args_hash[space_arg.name.to_s] = space_arg
    # end

    # # looping through sorted hash of model objects
    # space_args_hash.sort.map do |key, value|
    #   space_handles << value.handle.to_s
    #   space_display_names << key
    # end

    # # see if building name contains any template values
    # default_string = '90.1-2010'
    # get_templates.each do |template_string|
    #   if model.getBuilding.name.to_s.include?(template_string)
    #     default_string = template_string
    #     next
    #   end
    # end

    # # Make argument for template
    # template = OpenStudio::Measure::OSArgument.makeChoiceArgument('template', get_templates, true)
    # template.setDisplayName('Target Standard')
    # template.setDefaultValue(default_string)
    # args << template

    # # make a choice argument for veg_space type or entire building
    # space = OpenStudio::Measure::OSArgument.makeChoiceArgument('space', space_handles, space_display_names, true)
    # space.setDisplayName('Choose a space')
    # args << space# the name of the space to add to the model
    system_type = OpenStudio::Measure::OSArgument.makeStringArgument('system_type', true)
    system_type.setDisplayName('Enter the System Type')
    args << system_type

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables
    system_type = runner.getStringArgumentValue('system_type', user_arguments)
    # template = runner.getStringArgumentValue('template', user_arguments)

    # space = runner.getOptionalWorkspaceObjectChoiceValue('space', user_arguments, model)
    # space = space.get.to_ThermalZone.get
    # zone = space.thermalZone.get.to_ThermalZone.get

    

    zones = []
    
    model.getThermalZones.each do |zone|
      zones << zone
    end

    standard = Standard.build('90.1-2016')

    if system_type == "PTHP"
      standard.model_add_hvac_system(model, 'PTHP', ht = 'Electricity', znht = nil, cl = 'Electricity', zones)
    elsif system_type == "VRF"
      standard.model_add_hvac_system(model, 'VRF', ht = 'Electricity', znht = nil, cl = 'Electricity', zones)
    elsif system_type == "Baseboard gas boiler"
      standard.model_add_hvac_system(model, 'Baseboards', ht = 'NaturalGas', znht = nil, cl = 'Electricity', zones)
    elsif system_type == "Gas unit heaters"
      standard.model_add_hvac_system(model, 'Unit Heaters', ht = 'NaturalGas', znht = nil, cl = 'Electricity', zones)
    elsif system_type == "Water Source Heat Pumps"
      standard.model_add_hvac_system(model, 'Water Source Heat Pumps', ht = 'Electricity', znht = nil, cl = 'Electricity', zones)
    end

    # check the space_name for reasonableness
    # if space_name.empty?
    #   runner.registerError('Empty space name was entered.')
    #   return false
    # end

    # # report initial condition of model
    # runner.registerInitialCondition("The building started with #{model.getSpaces.size} spaces.")

    # # add a new space to the model
    # new_space = OpenStudio::Model::Space.new(model)
    # new_space.setName(space_name)

    # # echo the new space's name back to the user
    # runner.registerInfo("Space #{new_space.name} was added.")

    # # report final condition of model
    # runner.registerFinalCondition("The building finished with #{model.getSpaces.size} spaces.")

    return true
  end
end

# register the measure to be used by the application
GreenhouseInsertTypicalHVACSystem.new.registerWithApplication
