# JWT32

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CustomizePrototypeTstats < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'customize_prototype_Tstats'
  end

  # human readable description
  def description
    return 'A measure to inspect and edit the prototypical Tstat schedules for the OS Control Tool at VEIC'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Inspect the ruleset schedules and edit the temperature values'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # clg_setpoint
    clg_setpoint = OpenStudio::Measure::OSArgument.makeDoubleArgument('clg_setpoint', true)
    clg_setpoint.setDisplayName('Cooling Setpoint')
    clg_setpoint.setDescription('Enter a desired Cooling Setpoint')
    clg_setpoint.setDefaultValue(73.2)
    args << clg_setpoint

    # htg_setpoint
    htg_setpoint = OpenStudio::Measure::OSArgument.makeDoubleArgument('htg_setpoint', true)
    htg_setpoint.setDisplayName('Heating Setpoint')
    htg_setpoint.setDescription('Enter a desired Cooling Setpoint')
    htg_setpoint.setDefaultValue(68.0)
    args << htg_setpoint

    # setback
    setback = OpenStudio::Measure::OSArgument.makeDoubleArgument('setback', true)
    setback.setDisplayName('Setback')
    setback.setDescription('Setback')
    setback.setDefaultValue(5)
    args << setback

    # cooling boolean
    cooling_bool = OpenStudio::Measure::OSArgument.makeBoolArgument('cooling_bool', true)
    cooling_bool.setDisplayName('A swtich to turn off cooling')
    cooling_bool.setDefaultValue(false)
    args << cooling_bool

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables
    setback = runner.getDoubleArgumentValue('setback', user_arguments)
    htg_setpoint = runner.getDoubleArgumentValue('htg_setpoint', user_arguments)
    clg_setpoint = runner.getDoubleArgumentValue('clg_setpoint', user_arguments)
    cooling_bool = runner.getBoolArgumentValue('cooling_bool', user_arguments)

    if cooling_bool == true
      clg_setpoint = 120 #deg F
    end

    # convert the user arguments to si units
    setback_deg_k = OpenStudio::convert(setback, "R", "K").get
    htg_setpoint_deg_c = OpenStudio::convert(htg_setpoint, "F", "C").get
    clg_setpoint_deg_c = OpenStudio::convert(clg_setpoint, "F", "C").get

    info =""
    # build an info string
    info << "User entered #{setback} deg R which was converted to #{setback_deg_k.to_f.round(2)} deg K, "
    info << "User entered #{htg_setpoint} deg F which was converted to #{htg_setpoint_deg_c.to_f.round(2)} deg C, "
    info << "User entered #{clg_setpoint} deg F which was converted to #{clg_setpoint_deg_c.to_f.round(2)} deg C."

        # get the Thermostat schedules
    # do this by starting with ThermalZone -> ThermostatSetpointDualSetpoint -> H & C Schedule:Rulesets
    thermal_zones = model.getThermalZones

    tz_count = 0
    h_sched_array = []
    c_sched_array = []

    # a text element to describe the initial condition
    initial_condition = ""
    final_condition = ""

    # loop through all the thermal zones in the model and get the heating and cooling schedules by way of the ThermostatSetpointDualSetpoint object
    thermal_zones.each do |tz|
      tstatspdual = tz.thermostatSetpointDualSetpoint.get
      tz_count = tz_count +1
      h_sched = tstatspdual.heatingSetpointTemperatureSchedule.get  #this gets as a Schedule needs to be casted to Schedule:Ruleset later
      c_sched = tstatspdual.coolingSetpointTemperatureSchedule.get
      h_sched_array << h_sched
      c_sched_array << c_sched
    end
    # log how many Thermal Zones
    initial_condition << "The model has #{thermal_zones.size} Thermal Zones in it.  "

    # build an array of unique heating_schedules
    unique_h_sched = []
    unique_c_sched = []

    puts h_sched_array.size
    puts c_sched_array.size

    # use the .uniq ruby method to ignore the duplicate objects
    unique_h_sched = h_sched_array.uniq
    unique_c_sched = c_sched_array.uniq

    #create an array of the unique schedule names for the log
    for a in 0..unique_h_sched.size-1
      unique_h_names = ""
      unique_h_names << "#{unique_h_sched[a].name}"
    end


    initial_condition << "\nThere are #{unique_h_sched.size} unique Heating Setpoint, named #{unique_h_names} "
    initial_condition << "\nand #{unique_c_sched.size} unique Cooling Setpoint schedules within the model"

    # add some counters for the runner messages
    count_wo_sb = 0
    count_w_sb = 0 

    #TODO cooling
    #begin to edit each unique schedule
    for i in 0..unique_h_sched.size-1 
      schedule_ruleset = unique_h_sched[i]

      sched_rule_vector = []

      schedule_ruleset = schedule_ruleset.to_ScheduleRuleset.get # casting from Schedule (any type) into a ScheduleRuleset

      #collect the default day schedule and rule day schedules into an array of day schedules to be edited
      day_sched_array = []

      default_day = schedule_ruleset.defaultDaySchedule
      # make the default day the first item in the array
      day_sched_array[0]=default_day 
      schedule_ruleset.scheduleRules.each do |rule|
        sched_rule_vector << rule
      end

      # gets the Schedule:Day objects from the Schedule:Rule adds to the day schedule array after the default day
      for m in 0..sched_rule_vector.size-1
        day_sched_array[m+1] = sched_rule_vector[m].daySchedule
      end

      info << "\n there are #{day_sched_array.size} Day schedules in the Thermostat schedule #{unique_h_sched[i].name}"

      # needs a loop here to loop through all of the Schedule:Day objects in the array
      for n in 0..day_sched_array.size-1
        puts "n loop day_sched array step #{n}"
        #obtain the time and value pairs from the Schedule:Day definitions
        times = day_sched_array[n].times # vector of schedule times
        values = day_sched_array[n].values # vector of schedule values

        old_values_in_c=[]
        old_values_in_f=[]
        new_values=[]
        
    
        #clear the old day schedule
        day_sched_array[n].clearValues
        # take the old times and save them 
        #TODO report the old values for the register info
        for l in 0..values.size-1
          value_in_c = values[l]
          old_values_in_c[l]= values[l]
          old_values_in_f[l]= (OpenStudio::convert(old_values_in_c[l], "C", "F")).to_f
          old_max_f = old_values_in_f.max
          old_min_f = old_values_in_f.min
          old_setback_f = old_max_f-old_min_f

          # if the values vector is less than three than this assumes that is not a regular prototype schedule and hard sets it as a straight line schedule
          if values.size < 3
            new_values[l]= htg_setpoint_deg_c-setback_deg_k
            count_wo_sb = count_wo_sb + 1
          else 
            # sets all the values equal to the setpoint minus the setback
            new_values[l]= htg_setpoint_deg_c-setback_deg_k
          end

          # if the values vector is greater or equal to three assumes it is an existing schedule with a setback this comes through and resets the second to last value to the setpoint the high value
          if values.size >= 3
            new_values[values.size-2] = htg_setpoint_deg_c
            count_w_sb = count_w_sb + 1
          end
          
          # value_in_c = value_in_c + 3.2
          # new_values[l]=value_in_c
          day_sched_array[n].addValue(times[l], new_values[l])
        end
        if values.size >= 3 # what about a schedule (like ag) that has only two items but still a setback assume okay for most of create by space type workflwo
          info << "\n The day schedule #{day_sched_array[n].name} prototypically had a heating setpoint of #{old_max_f.to_f.round(2)} and a setback of #{old_setback_f.round(2)}."
          
        else
          info << "\n The day schedule #{day_sched_array[n].name} prototypically had a heating setpoint of #{old_max_f.to_f.round(2)} and no temperature setback."
        end
        puts day_sched_array[n]
      end
    # begin repeat for cooling
      #create an array of the unique schedule names for the log
      for a in 0..unique_c_sched.size-1
        unique_c_names = ""
        unique_c_names << "#{unique_c_sched[a].name}"
      end
  
  
      # initial_condition << "\nThere are #{unique_c_sched.size} unique Coolin Setpoint, named #{unique_c_names} "
      # initial_condition << "\nand #{unique_c_sched.size} unique Cooling Setpoint schedules within the model"
  
      # add some counters for the runner messages
      count_c_wo_sb = 0
      count_c_w_sb = 0
  
      #TODO cooling
      #begin to edit each unique schedule
      for i in 0..unique_c_sched.size-1 
        schedule_ruleset = unique_c_sched[i]
  
        sched_rule_vector = []
  
        schedule_ruleset = schedule_ruleset.to_ScheduleRuleset.get # casting from Schedule (any type) into a ScheduleRuleset
  
        #collect the default day schedule and rule day schedules into an array of day schedules to be edited
        day_sched_array = []
  
        default_day = schedule_ruleset.defaultDaySchedule
        # make the default day the first item in the array
        day_sched_array[0]=default_day 
        schedule_ruleset.scheduleRules.each do |rule|
          sched_rule_vector << rule
        end
  
        # gets the Schedule:Day objects from the Schedule:Rule adds to the day schedule array after the default day
        for m in 0..sched_rule_vector.size-1
          day_sched_array[m+1] = sched_rule_vector[m].daySchedule
        end
  
        info << "\n there are #{day_sched_array.size} Day schedules in the Thermostat schedule #{unique_c_sched[i].name}"
  
        # needs a loop here to loop through all of the Schedule:Day objects in the array
        for n in 0..day_sched_array.size-1
          puts "n loop day_sched array step #{n}"
          #obtain the time and value pairs from the Schedule:Day definitions
          times = day_sched_array[n].times # vector of schedule times
          values = day_sched_array[n].values # vector of schedule values
  
          old_values_in_c=[]
          old_values_in_f=[]
          new_values=[]
          
      
          #clear the old day schedule
          day_sched_array[n].clearValues
          # take the old times and save them 
          #TODO report the old values for the register info
          for l in 0..values.size-1
            value_in_c = values[l]
            old_values_in_c[l]= values[l]
            old_values_in_f[l]= (OpenStudio::convert(old_values_in_c[l], "C", "F")).to_f
            old_max_f = old_values_in_f.max
            old_min_f = old_values_in_f.min
            old_setback_f = old_max_f-old_min_f
  
            # if the values vector is less than three than this assumes that is not a regular prototype schedule and hard sets it as a straight line schedule
            if values.size < 3
              new_values[l]= clg_setpoint_deg_c+setback_deg_k
              count_c_wo_sb = count_c_wo_sb + 1
            else 
              # sets all the values equal to the setpoint minus the setback
              new_values[l]= clg_setpoint_deg_c+setback_deg_k
            end
  
            # if the values vector is greater or equal to three assumes it is an existing schedule with a setback this comes through and resets the second to last value to the setpoint the high value
            if values.size >= 3
              new_values[values.size-2] = clg_setpoint_deg_c
              count_c_w_sb = count_c_w_sb + 1
            end
            
            # value_in_c = value_in_c + 3.2
            # new_values[l]=value_in_c
            day_sched_array[n].addValue(times[l], new_values[l])
          end
          if values.size >= 3 # what about a schedule (like ag) that has only two items but still a setback assume okay for most of create by space type workflwo
            info << "\n The day schedule #{day_sched_array[n].name} prototypically had a cooling setpoint of #{old_max_f.to_f.round(2)} and a setback of #{old_setback_f.round(2)}."
            
          else
            info << "\n The day schedule #{day_sched_array[n].name} prototypically had a cooling setpoint of #{old_max_f.to_f.round(2)} and no temperature setback."
          end
          puts day_sched_array[n]
        end
      end
    end

    # report initial, info, final runner messages 
    runner.registerInitialCondition(initial_condition)

    runner.registerInfo(info)

    final_condition << "A total of #{count_w_sb} different Schedule:Day objects got reset to a heating setpoint of #{htg_setpoint} degF with a setback of #{setback} degF"
    final_condition << "\n A total of #{count_wo_sb} different Schedule:Day objects got reset to a heating setpoint of #{htg_setpoint-setback} degF these are the off weekend/holidays"
    final_condition << "A total of #{count_c_w_sb} different Schedule:Day objects got reset to a heating setpoint of #{clg_setpoint} degF with a setback of #{setback} degF"
    final_condition << "\n A total of #{count_c_wo_sb} different Schedule:Day objects got reset to a heating setpoint of #{clg_setpoint-setback} degF these are the off weekend/holidays"
    
    runner.registerFinalCondition(final_condition)
    
    
    return true
  end
end

# register the measure to be used by the application
CustomizePrototypeTstats.new.registerWithApplication
