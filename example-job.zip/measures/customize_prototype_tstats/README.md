

###### (Automatically generated documentation)

# customize_prototype_Tstats

## Description
A measure to inspect and edit the prototypical Tstat schedules for the OS Control Tool at VEIC

## Modeler Description
Inspect the ruleset schedules and edit the temperature values

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Cooling Setpoint
Enter a desired Cooling Setpoint
**Name:** clg_setpoint,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Heating Setpoint
Enter a desired Cooling Setpoint
**Name:** htg_setpoint,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Setback
Setback
**Name:** setback,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### A swtich to turn off cooling

**Name:** cooling_bool,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false






