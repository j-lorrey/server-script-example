

###### (Automatically generated documentation)

# apply_simultaneous_heatingandcooling_fault

## Description
A measure for representing a fault condition of simultaneous heating and cooling.

## Modeler Description
There are two logic paths through this measure to implement two kinds of simultaneous heating and cooling depending on the system type present and
    there is a True False boolean to run the mueasure (TRUE) or not.
    1) for VAV systems where the cooling coil is over cooling and the reheat is making up the difference.   
    Where the MAT temp gets set down from 55 defF to 50degF.  
    This is accomplished in the model by using the MAT SetpointManager:Warmest object and reseting down the MIN and MAX variables.  
    This measure assumes that the upstream MAT is as defined by the standards-gem and equal 55deg F and 60degF.  
    A user agrument for entering degF values is presented in the measure arguments for testing purposes, the worfklow will retain
    the default settings
    2) 
    

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Apply a simultaneous heating and cooling fault?
This will lower the discharge MAT to drive more cooling and heating
**Name:** simultaneous_heatandcool,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Enter a min temp setpoint for this SetpointManager:Warmest
Assumes that the standards-gem sets this at 55 degF.  This measures defaults to 50 degF to drive simultaneous heating and cooling
**Name:** spmngr_warmest_min_sp_temp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Enter a min temp setpoint for this SetpointManager:Warmest
Assumes that the standards-gem sets this at 60 degF.  This measures defaults to 55 degF to drive simultaneous heating and cooling
**Name:** spmngr_warmest_max_sp_temp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false






