# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class ApplySimultaneousHeatingandcoolingFault < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'apply_simultaneous_heatingandcooling_fault'
  end

  # human readable description
  def description
    return 'A measure for representing a fault condition of simultaneous heating and cooling.'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'There are two logic paths through this measure to implement two kinds of simultaneous heating and cooling depending on the system type present and
    there is a True False boolean to run the mueasure (TRUE) or not.
    1) for VAV systems where the cooling coil is over cooling and the reheat is making up the difference.   
    Where the MAT temp gets set down from 55 defF to 50degF.  
    This is accomplished in the model by using the MAT SetpointManager:Warmest object and reseting down the MIN and MAX variables.  
    This measure assumes that the upstream MAT is as defined by the standards-gem and equal 55deg F and 60degF.  
    A user agrument for entering degF values is presented in the measure arguments for testing purposes, the worfklow will retain
    the default settings
    2) 
    '
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    simultaneous_heatandcool = OpenStudio::Measure::OSArgument.makeBoolArgument('simultaneous_heatandcool', true)
    simultaneous_heatandcool.setDisplayName('Apply a simultaneous heating and cooling fault?')
    simultaneous_heatandcool.setDescription('This will lower the discharge MAT to drive more cooling and heating')
    args << simultaneous_heatandcool

    spmngr_warmest_min_sp_temp = OpenStudio::Measure::OSArgument.makeDoubleArgument('spmngr_warmest_min_sp_temp', true)
    spmngr_warmest_min_sp_temp.setDisplayName('Enter a min temp setpoint for this SetpointManager:Warmest')
    spmngr_warmest_min_sp_temp.setDescription('Assumes that the standards-gem sets this at 55 degF.  This measures defaults to 50 degF to drive simultaneous heating and cooling')
    spmngr_warmest_min_sp_temp.setDefaultValue(50)
    args << spmngr_warmest_min_sp_temp

    spmngr_warmest_max_sp_temp = OpenStudio::Measure::OSArgument.makeDoubleArgument('spmngr_warmest_max_sp_temp', true)
    spmngr_warmest_max_sp_temp.setDisplayName('Enter a min temp setpoint for this SetpointManager:Warmest')
    spmngr_warmest_max_sp_temp.setDescription('Assumes that the standards-gem sets this at 60 degF.  This measures defaults to 55 degF to drive simultaneous heating and cooling')
    spmngr_warmest_max_sp_temp.setDefaultValue(55)
    args << spmngr_warmest_max_sp_temp

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    simultaneous_heatandcool = runner.getBoolArgumentValue('simultaneous_heatandcool', user_arguments)
    spmngr_warmest_max_sp_temp = runner.getDoubleArgumentValue('spmngr_warmest_max_sp_temp', user_arguments)
    spmngr_warmest_min_sp_temp = runner.getDoubleArgumentValue('spmngr_warmest_min_sp_temp', user_arguments)


    runner.registerInfo("simultaneous_heatandcool was set to #{simultaneous_heatandcool}")

    if simultaneous_heatandcool == true
      # if true begin measure logic for simultaneous heating and cooling
      # if statement to check which kind of Simultaneous heating and cooling is present.  SetpointManagerWarmest inidcates a PVAV or VAV system.
      if !model.getSetpointManagerWarmests.empty?

        #if the models is NOT empty of SetpointManagerWarmets objects
        # then run the loop to impletment VAV type simultaneous heating and cooling

        # In a VAV system use the SetpointManager:Warmest objects and edit the discharge temp
        spmngr_warmests = model.getSetpointManagerWarmests
        spmngr_warmests.each do |spm_w|
          #obtain the object settings from the model
          old_min_si = spm_w.minimumSetpointTemperature
          old_max_si = spm_w.maximumSetpointTemperature

          old_min_ip = OpenStudio.convert(old_min_si, 'C', 'F').get
          old_max_ip = OpenStudio.convert(old_max_si, 'C', 'F').get

          new_min_ip = spmngr_warmest_min_sp_temp
          new_max_ip = spmngr_warmest_max_sp_temp

          new_min_si = OpenStudio.convert(new_min_ip, 'F', 'C').get
          new_max_si = OpenStudio.convert(new_max_ip, 'F', 'C').get

          
          runner.registerInfo("Model identified as a PVAV or VAV by the #{spm_w.name} within the model")
          runner.registerInfo("Simultaneous Heating and Cooling is implemented by way of setting down the MIN and MAX temperatures settings")
          
          runner.registerInfo("Initial min and max setpoints #{old_min_ip} and #{old_max_ip} respectively")

          #repopulate the SetpointManager:Warmests with the new MIN MAX Values in SI units
          spm_w.setMaximumSetpointTemperature(new_max_si)
          spm_w.setMinimumSetpointTemperature(new_min_si)

          #return the actual object with it's new settings for the Info message
          runner.registerInfo("#{OpenStudio.convert(spm_w.maximumSetpointTemperature, 'C', 'F').get} is the new MAX")
          runner.registerInfo("#{OpenStudio.convert(spm_w.minimumSetpointTemperature, 'C', 'F').get} is the new MIN")

        #end the do loop
        end
      # begin second path of logic for the run method
      elsif !model.getCoilHeatingWaterBaseboards.empty?
        runner.registerInfo("Model identified as having baseboard by baseboard objects existing within the model")

        # use some built in engineering rules to approximate the minimum flow rate for this fault condition
        building = model.getBuilding
        building_size_si = building.floorArea
        
        # the general rules are 20 Btuh / sqft of floor area = boiler size, and Q = 500 * gpm * dT for hydronic heating
        # this measure sets up the minimum flow rate of the heating loop to 10% of the total estimated design load.
        # Building sqft * 20 Btuh / ( 500 * dT = 20) * 10% = minimum flow rate [gpm]

        building_size_ip = OpenStudio.convert(building_size_si, 'm^2', 'ft^2').get

        min_flow_ip = ((building_size_ip * 20) / (500 * 20 )) / 10

        min_flow_si = OpenStudio.convert(min_flow_ip, 'gal/min', 'm^3/s').get

        runner.registerInfo("#{min_flow_si} [m^3/s] and #{min_flow_ip} [gpm]")

        coil_heating_water_baseboards = model.getCoilHeatingWaterBaseboards
        # obtain the appropriate plant loop from the baseboard objects
        plant_loop_array = []
        coil_heating_water_baseboards.each do |bb|
          plant_loop = bb.plantLoop
          plant_loop = plant_loop.get.to_PlantLoop.get
          plant_loop_array << plant_loop
        end

        #assume that if the first and last plant loops are the same then that means all of the baseboards are on the same plant loop        
        if plant_loop_array[0] = plant_loop_array[plant_loop_array.size-1]
          runner.registerInfo("All baseboards are indentified as being on the same heating plant loop, this method of implementing simultaneous heating and cooling will work")
          plant_loop_array[0].setMinimumLoopFlowRate(min_flow_si)
          runner.registerInfo("The PlantLoop #{plant_loop_array[0].name.get} had the total minimum flow reset to #{OpenStudio.convert(plant_loop_array[0].minimumLoopFlowRate.get, 'm^3/s', 'gal/min').get} [gpm]")
          # runner.registerInfo("#{plant_loop_array[0]}")
          # get all of the pumps in the model and loop for the one that is the HWS pump
          # use a check to see if the supplyInletNode of this plant_loop equals the inletPort
          pumps = model.getPumpVariableSpeeds
            #begin checking the loops match
            pumps.each do |pump|
              connected_plantloop = pump.plantLoop.get
              if connected_plantloop = plant_loop_array[0]
                og_pump_min_flow_si = pump.minimumFlowRate
                og_pump_min_flow_ip = OpenStudio.convert(og_pump_min_flow_si, 'm^3/s', 'gal/min').get
                runner.registerInfo("The pump #{pump.name} originally had a min flow rate of #{og_pump_min_flow_ip} gpm and")
                runner.registerInfo("this measure reset it upwards to represent simultaneous heating and cooling as an HWS valve leakage")
                runner.registerInfo("using a basic sqft based calc the minimum flow was increased to equal approximately 10% of the total loop flow")
                pump.setMinimumFlowRate(min_flow_si)
                #use the object on the confirming log message
                runner.registerInfo("The new minimum pump and loop flow is #{OpenStudio.convert(pump.minimumFlowRate, 'm^3/s', 'gal/min').get} [gpm]")
              end # end the if
            end # the do loop          
        end # end checking to see that all of the baseboard equipment shares the same plant loop  


      # end the check if ScheduleManagerWarmest, or  elsif CoilHeatingWaterBaseboards is NOT empty.
      end
    #end if true  
    end


    return true
  end
end

# register the measure to be used by the application
ApplySimultaneousHeatingandcoolingFault.new.registerWithApplication
