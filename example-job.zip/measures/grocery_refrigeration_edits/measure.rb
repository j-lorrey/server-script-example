# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class GroceryRefrigerationEdits < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'GroceryRefrigerationEdits'
  end

  # human readable description
  def description
    return 'This measure supports editing refrigeration system characteristics to support efficiency and GHG within the Grocery store market'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Select the Refrigeration:System name and edit CondenserFanSpeedControlType RatedFanPower MinimumCondensingTemperature RefrigerationSystemWorkingFluidType  and add a subcooler mechanical yes or no.

'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    #Input arguments

    # lotemp_acu_fan_speed_control_type # text 4 list plus default
    # hitemp_acu_fan_speed_control_type  # text

    lotemp_acu_fan_speed_control_type = OpenStudio::Measure::OSArgument.makeChoiceArgument('lotemp_acu_fan_speed_control_type', false)
    args << lotemp_acu_fan_speed_control_type
    hitemp_acu_fan_speed_control_type = OpenStudio::Measure::OSArgument.makeChoiceArgument('hitemp_acu_fan_speed_control_type', false)
    args << hitemp_acu_fan_speed_control_type

    # lotemp_min_cond_temp_setpoint #numerical degF
    # hitemp_min_cond_temp_setpoint #numerical degF
    lotemp_min_cond_temp_setpoint = OpenStudio::Measure::OSArgument.makeDoubleArgument('lotemp_min_cond_temp_setpoint', true)
    args << lotemp_min_cond_temp_setpoint
    hitemp_min_cond_temp_setpoint = OpenStudio::Measure::OSArgument.makeDoubleArgument('hitemp_min_cond_temp_setpoint', true)
    args << hitemp_min_cond_temp_setpoint
    # lotemp_accu_fan_hp #numerical HP numerical or 0 for default
    # hitemp_accu_fan_hp #numerical HP
    lotemp_accu_fan_hp = OpenStudio::Measure::OSArgument.makeDoubleArgument('lotemp_accu_fan_hp', true)
    args << lotemp_accu_fan_hp
    hitemp_accu_fan_hp = OpenStudio::Measure::OSArgument.makeDoubleArgument('hitemp_accu_fan_hp', true)
    args << hitemp_accu_fan_hp

    # lotemp_ref_fluid # text 4 list plus default
    # hitemp_ref_fluid # text
    lotemp_ref_fluid = OpenStudio::Measure::OSArgument.makeChoiceArgument('lotemp_ref_fluid', true)
    args << lotemp_ref_fluid
    hitemp_ref_fluid = OpenStudio::Measure::OSArgument.makeChoiceArgument('hitemp_ref_fluid', true)
    args << hitemp_ref_fluid
    # lotemp_add_subcooler # yes, no, default
    # hitemp_add_subcooler # yes, no, default
    lotemp_add_subcooler = OpenStudio::Measure::OSArgument.makeChoiceArgument('lotemp_add_subcooler', true)
    args << lotemp_add_subcooler
    hitemp_add_subcooler = OpenStudio::Measure::OSArgument.makeChoiceArgument('hitemp_add_subcooler', true)
    args << hitemp_add_subcooler

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    #Work on the Medium Temperature System
    
    # assign the user inputs to variables
    hitemp_acu_fan_speed_control_type = runner.getSChoiceArgumentValue('hitemp_acu_fan_speed_control_type', user_arguments)
    hitemp_ref_fluid = runner.getChoiceArgumentValue('hitemp_ref_fluid', user_arguments)
    hitemp_accu_fan_hp = runner.getDoubleArgumentValue('hitemp_accu_fan_hp', user_arguments)
    hitemp_add_subcooler = runner.getChoiceArgumentValue('hitemp_add_subcooler', user_arguments)
    #unit conversion
    hitemp_accu_fan_watts = hitemp_accu_fan_hp*745.7 #conversion of hp to watts
    hitemp_min_cond_temp_setpoint  = runner.getDoubleArgumentValue('hitemp_min_cond_temp_setpoint', user_arguments)
    # convert from ip temp to si temp
    # min_cond_temp_setpoint_deg_c = (min_cond_temp_setpoint.to_f-32)*(5/9)
    # TODO: Why does the arithmetic not work with the brackets?
    hitemp_min_cond_temp_setpoint_deg_c = hitemp_min_cond_temp_setpoint-32
    hitemp_min_cond_temp_setpoint_deg_c = hitemp_min_cond_temp_setpoint_deg_c*5
    hitemp_min_cond_temp_setpoint_deg_c = hitemp_min_cond_temp_setpoint_deg_c/9

    
    ref_system_lookup_by_name = model.getRefrigerationSystems.each do |ref_system_lookup_by_name|
      if ref_system_lookup_by_name.name.get.match("Medium Temperature")
        if hitemp_ref_fluid == "Default"
        #do nothing
        elsif hitemp_ref_fluid == "R448a"
          #do nothing
        elsif hitemp_ref_fluid == "R290"
          #do nothing
        else ref_system_lookup_by_name.setRefrigerationSystemWorkingFluidType(hitemp_ref_fluid)
        end
        # check the defaults
        if hitemp_min_cond_temp_setpoint == 0
          #do nothing
        else ref_system_lookup_by_name.setMinimumCondensingTemperature(hitemp_min_cond_temp_setpoint_deg_c)
        end

        

          # check the default conditions before setting object's items
          if hitemp_acu_fan_speed_control_type == "Default"
            #do nothing
          else 
            if not ref_system_lookup_by_name.refrigerationCondenser.empty?
              
              condenser = ref_system_lookup_by_name.refrigerationCondenser.get
              condenser = condenser.to_RefrigerationCondenserAirCooled.get
              condenser.setCondenserFanSpeedControlType(hitemp_acu_fan_speed_control_type)
            end
          end
          # check the default conditions before setting object's items
          if hitemp_accu_fan_hp == 0
            #do nothing
          else 
            if not ref_system_lookup_by_name.refrigerationCondenser.empty?
              
              condenser = ref_system_lookup_by_name.refrigerationCondenser.get
              condenser = condenser.to_RefrigerationCondenserAirCooled.get
              condenser.setRatedFanPower(hitemp_accu_fan_watts.to_f)
          end
        end

        if hitemp_add_subcooler == "Default"
          #do nothing
        elsif hitemp_add_subcooler == "No"
          ref_system_lookup_by_name.resetMechanicalSubcooler
        else hitemp_add_subcooler == "Yes"
          subcooler = OpenStudio::Model::RefrigerationSubcoolerMechanical.new(model)
          subcooler.setName("New Subcooler Added")
          subcooler.setCapacityProvidingSystem(ref_system_lookup_by_name)
          ref_system_lookup_by_name.setMechanicalSubcooler(subcooler)
        end
                
      end
    end

    #Work on the Low Temperature System
    
    # assign the user inputs to variables
    lotemp_acu_fan_speed_control_type = runner.getChoiceArgumentValue('lotemp_acu_fan_speed_control_type', user_arguments)
    lotemp_ref_fluid = runner.getChoiceArgumentValue('lotemp_ref_fluid', user_arguments)
    lotemp_accu_fan_hp = runner.getDoubleArgumentValue('lotemp_accu_fan_hp', user_arguments)
    lotemp_add_subcooler = runner.getChoiceArgumentValue('lotemp_add_subcooler', user_arguments)
    #unit conversion
    lotemp_accu_fan_watts = lotemp_accu_fan_hp*745.7 #conversion of hp to watts
    lotemp_min_cond_temp_setpoint  = runner.getDoubleArgumentValue('lotemp_min_cond_temp_setpoint', user_arguments)
    # convert from ip temp to si temp
    # min_cond_temp_setpoint_deg_c = (min_cond_temp_setpoint.to_f-32)*(5/9)
    # TODO: Why does the arithmetic not work with the brackets?
    lotemp_min_cond_temp_setpoint_deg_c = lotemp_min_cond_temp_setpoint-32
    lotemp_min_cond_temp_setpoint_deg_c = lotemp_min_cond_temp_setpoint_deg_c*5
    lotemp_min_cond_temp_setpoint_deg_c = lotemp_min_cond_temp_setpoint_deg_c/9

    
    ref_system_lookup_by_name = model.getRefrigerationSystems.each do |ref_system_lookup_by_name|
      if ref_system_lookup_by_name.name.get.match("Low Temperature")
        if lotemp_ref_fluid == "Default"
        #do nothing
        else ref_system_lookup_by_name.setRefrigerationSystemWorkingFluidType(lotemp_ref_fluid)
        end
        # check the defaults
        if lotemp_min_cond_temp_setpoint == 0
          #do nothing
        else ref_system_lookup_by_name.setMinimumCondensingTemperature(lotemp_min_cond_temp_setpoint_deg_c)
        end

        

          # check the default conditions before setting object's items
          if lotemp_acu_fan_speed_control_type == "Default"
            #do nothing
          else 
            if not ref_system_lookup_by_name.refrigerationCondenser.empty?
              
              condenser = ref_system_lookup_by_name.refrigerationCondenser.get
              condenser = condenser.to_RefrigerationCondenserAirCooled.get
              condenser.setCondenserFanSpeedControlType(lotemp_acu_fan_speed_control_type)
            end
          end
          # check the default conditions before setting object's items
          if lotemp_accu_fan_hp == 0
            #do nothing
          else 
            if not ref_system_lookup_by_name.refrigerationCondenser.empty?
              
              condenser = ref_system_lookup_by_name.refrigerationCondenser.get
              condenser = condenser.to_RefrigerationCondenserAirCooled.get
              condenser.setRatedFanPower(lotemp_accu_fan_watts.to_f)
          end
        end

        if lotemp_add_subcooler == "Default"
          #do nothing
        elsif lotemp_add_subcooler == "No"
          ref_system_lookup_by_name.resetMechanicalSubcooler
        else lotemp_add_subcooler == "Yes"
          subcooler = OpenStudio::Model::RefrigerationSubcoolerMechanical.new(model)
          subcooler.setName("New Subcooler Added")
          subcooler.setCapacityProvidingSystem(ref_system_lookup_by_name)
          ref_system_lookup_by_name.setMechanicalSubcooler(subcooler)
        end
                
      end
    end


    #TODO:Output messages!!!!!

    return true
  end
end

# register the measure to be used by the application
GroceryRefrigerationEdits.new.registerWithApplication
