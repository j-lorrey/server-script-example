

###### (Automatically generated documentation)

# Create Typical Building from Model

## Description
Takes a model with space and stub space types, and assigns constructions, schedules, internal loads, hvac, and other loads such as exterior lights and service water heating.

## Modeler Description
It is important that the template argument chosen for this measure is in line with the building types for the stub space types of the model passed in.

## Measure Type
ModelMeasure

[//]: # (Only finds value if taxonomy method is added to measure.rb, won't read out of measure.xml)
## Taxonomy
Whole Building.Space Types

___
## Table of Contents
- [Measure Overview](#measure-overview)<br/>
- [DOE and DEER Template and Buildid Type Mapping](#doe-and-deer-template-and-building-type-mapping)<br/>
- [HVAC Configuration Arguments](#hvac-configuration-arguments)<br/>
- [Exterior Lighting Arguments](#exterior-lighting-arguments)<br/>
- [Bool Arguments to Enable/Disable Elements of This Measure](#bool-arguments-to-enabledisable-elements-of-this-measure)<br/>
- [Hours of Operation Arguments](#hours-of-operation-arguments)<br/>
- [Other Arguments](#other-arguments)<br/>
- [Development Comments](#development-comments)<br/>
- [Automatically Generated Argument List](#arguments)<br/>

## Measure Overview

While this measure has many arguments, they all have default values so you can start using it to get familiar with out without using the arguments. What is important is that the model passed in contains spaces with stub space types assigned. In addition to choice arguments, this measure has a number of bool arguments allowing the measure to be customized to meet your needs or to be split into two parts with other measures add in the model. You can for example use this to add constructions only, or to add everything else but leave constructions alone. An example use case for splitting this apart and adding other measures between would be to apply energy efficiency measures for new construction. The HVAC system should be added after the EE measures because an autosizing simulation is run to set the system equipment efficiencies for the selected template.

## DOE and DEER Template and Building Type Mapping

Note, that this particular measure has access to both DOE and DEER templates (vintages). It is important for using this measure that the template chosen is in line with the  building type(s) for the stub space types in the seed model. Below is a list of for each.

#### DOE
- Templates:
  - DOE Ref Pre-1980
  - DOE Ref 1980 - 2004
  - 90.1-2004
  - 90.1-2007
  - 90.1-2010
  - 90.1-2013
  - 90.1-2016
  - 90.1-2019
  - NREL ZNE Ready 2017 (not currently complete for all building types)
  - ComStock DOE Ref Pre-1980
  - ComStock DOE Ref 1980-2004
  - ComStock 90.1-2004
  - ComStock 90.1-2007
  - ComStock 90.1-2010
  - ComStock 90.1-2013
- Building Types:
  - SecondarySchool
  - PrimarySchool
  - SmallOffice
  - MediumOffice
  - LargeOffice
  - SmallHotel
  - LargeHotel
  - Warehouse
  - RetailStandalone
  - RetailStripmall
  - QuickServiceRestaurant
  - FullServiceRestaurant
  - MidriseApartment
  - HighriseApartment
  - Hospital
  - Outpatient
  - SuperMarket
  - Laboratory
  - LargeDataCenterLowITE
  - LargeDataCenterHighITE
  - SmallDataCenterLowITE
  - SmallDataCenterHighITE

#### DEER
- Templates:
  - DEER Pre-1975
  - DEER 1985
  - DEER 1996
  - DEER 2003
  - DEER 2007
  - DEER 2011
  - DEER 2014
  - DEER 2015
  - DEER 2017
  - DEER 2020
  - DEER 2025
  - DEER 2030
  - DEER 2035
  - DEER 2040
  - DEER 2045
  - DEER 2050
  - DEER 2055
  - DEER 2060
  - DEER 2065
  - DEER 2070
  - DEER 2075
- Building Types:
  - Asm
  - DMo
  - ECC
  - EPr
  - ERC
  - ESe
  - EUn
  - GHs
  - Gro
  - Hsp
  - Htl
  - MBT
  - MFm
  - MLI
  - Mtl
  - Nrs
  - OfL
  - OfS
  - RFF
  - RSD
  - Rt3
  - RtL
  - RtS
  - SCn
  - SFm
  - SUn
  - WRf

[//]: # (Provide link to map DEER abbreviation to full building type name)
[//]: # (Would be nice to make these lists dynamic from the measure to they don't become outdated)

## HVAC Configuration Arguments

- `HVAC System Type` can be set to 'Inferred', 'Ideal Air Loads', or more than 50 additional system types. When choosing Inferred additional arguments listed below will impact the selected system type as elements of the seed model.

- `HVAC System Delivery Type` can be set to `Forced Air` or `Hydronic`

- `HVAC Heating Source` can be set to `Electricity`, `NaturalGas`, `DistrictHeating`, or `DistrictAmbient`

- `HVAC Cooling Source` can be set to `Electricity`, or `DistrictCooling`

- `Service Water Heating Source`can be set to `Inferred`, `NaturalGas`, `Electricity`, or `HeatPump`.

- `Kitchen Exhaust MakeUp Air Calculation Method` is used to determine if makeup air is modeled for kitchen exhaust and what zone that comes from. While the default choice of `Adajcent` makes sence for custom user geometry, if the geometry was autogenerated without representing an actual plan, you can set makeup air to come from the `Largest Zone`. `None` is also an option, which disables makeup air.

## Exterior Lighting Arguments

- `Exterior Lighting Zone` is used to identify the exterior lighting allowances based on how urban or rural the site for the buidling is. The `Template also impacts the target value.

- `Onsite Parking Fraction` can reduce or eliminate the amount of exterior lighting for parking added to the model. This wil not reduce exterior facade, walkway, or entry lighting.

## Bool Arguments to Enable/Disable Elements of This Measure

The following is a list of arguments for elements of the model that can be enabled or disabled for the measure.
- `Add Constructions to Model`
- `Add Space Type Loads to Model`
- `Add Elevators to Model`. This will only be added to buildings with more than one story. Number of floors will be used to determine the elevator type, and the number of occupants can determine both the number of elevators and can impact the schedule. To avoid large jumps in parametric analyses, the number of elevators is a double instead of an integer, but will never be less than 1.0 for multi-story buildings, but can for example be 2.6 or 1.5 elevators, instead of just 1 or 2. The logic used isn't depending on a space or space type existing for elevators. The space load will be added to the largest space on the first story. Fraction of heat lost will be set to 1.0 for traction elevators.
- `Add Internal Mass to Model`
- `Add Exterior Lights to Model`
- `Add Exhaust Fans to Model`
- `Add Service Water Heating to Model`
- `Add Thermostats`
- `Add HVAC System to Model`. This may add a secondary system for zones with internal loads or schedules that are dis-similar from the typical zones. For thermal zones on the primary zone, where  multi-zone air loops are added, one air loop will be added for each building story. A sizing run will be performed however the elements in the model will stay autosized. The sizing run is to identify the proper target system efficiency.
- `Add Refrigeration to Model`

## Hours of Operation Arguments

There are three arguments each for weekday and weekend behavior. In each case there are the following arguments.

- Bool argument to enable/disable altering of weekdays or weekends
- Operating hours start time
- Operating hours duration

## Other Arguments

- `Use Upstream Argument Values` can be left at the default value of true for most cases. This argument shows up in a number of measures, and then intent is to enable the synchronization of arguments that may be used as a variable in a parametric study across multiple measures. Generally measures gave unique argument names that don't exist in other measures, but some such as `template` are used frequently. This argument, when set to true, will use the value of `Template` from an earlier measure in the workflow, if found, in place of what is entered as the value for this measure.
- `Unmet Hours Tolerance` is used to change the tolerance used in EnergyPlus for unmet heating and cooling hours.
- `Clean Model of non-geometry objects` should be set to false when you have a non-empty model with objects that you want to maintain. If you have split this measure in two the second instance of this should have it set to false or it will overwrite elements made by the earlier measure.
- `Enable Daylight Savings` will change daylighting saving to true when enabled.

## Development Comments

This measure relies on the openstudio-standards gem which is included in the OpenStudio CLI as well as a number of resources files listed below that are contained in the openstudio-extension gem which is also included in the OpenStudio CLI. Other than the arguments almost none of the measure code is in the measure.rb file. The resource files are used by a number of measures and should be updated from the shared library and not within this measure.
- os_lib_model_generation.rb
- os_lib_model_simplification.rb
- os_lib_geometry.rb
- os_lib_helper_methods.rb

___

*(Automatically generated argument information follows)*

## Arguments


### Target Standard

**Name:** template,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["DOE Ref Pre-1980", "DOE Ref 1980-2004", "90.1-2004", "90.1-2007", "90.1-2010", "90.1-2013", "90.1-2016", "90.1-2019", "ComStock DOE Ref Pre-1980", "ComStock DOE Ref 1980-2004", "ComStock 90.1-2004", "ComStock 90.1-2007", "ComStock 90.1-2010", "ComStock 90.1-2013", "DEER Pre-1975", "DEER 1985", "DEER 1996", "DEER 2003", "DEER 2007", "DEER 2011", "DEER 2014", "DEER 2015", "DEER 2017", "DEER 2020"]


### HVAC System Type

**Name:** system_type,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Inferred", "Ideal Air Loads", "Baseboard electric", "Baseboard gas boiler", "Baseboard central air source heat pump", "Baseboard district hot water", "Direct evap coolers with baseboard electric", "Direct evap coolers with baseboard gas boiler", "Direct evap coolers with baseboard central air source heat pump", "Direct evap coolers with baseboard district hot water", "Direct evap coolers with forced air furnace", "Direct evap coolers with gas unit heaters", "Direct evap coolers with no heat", "DOAS with fan coil chiller with boiler", "DOAS with fan coil chiller with central air source heat pump", "DOAS with fan coil chiller with district hot water", "DOAS with fan coil chiller with baseboard electric", "DOAS with fan coil chiller with gas unit heaters", "DOAS with fan coil chiller with no heat", "DOAS with fan coil air-cooled chiller with boiler", "DOAS with fan coil air-cooled chiller with central air source heat pump", "DOAS with fan coil air-cooled chiller with district hot water", "DOAS with fan coil air-cooled chiller with baseboard electric", "DOAS with fan coil air-cooled chiller with gas unit heaters", "DOAS with fan coil air-cooled chiller with no heat", "DOAS with fan coil district chilled water with boiler", "DOAS with fan coil district chilled water with central air source heat pump", "DOAS with fan coil district chilled water with district hot water", "DOAS with fan coil district chilled water with baseboard electric", "DOAS with fan coil district chilled water with gas unit heaters", "DOAS with fan coil district chilled water with no heat", "DOAS with VRF", "DOAS with water source heat pumps fluid cooler with boiler", "DOAS with water source heat pumps cooling tower with boiler", "DOAS with water source heat pumps with ground source heat pump", "DOAS with water source heat pumps district chilled water with district hot water", "Fan coil chiller with boiler", "Fan coil chiller with central air source heat pump", "Fan coil chiller with district hot water", "Fan coil chiller with baseboard electric", "Fan coil chiller with gas unit heaters", "Fan coil chiller with no heat", "Fan coil air-cooled chiller with boiler", "Fan coil air-cooled chiller with central air source heat pump", "Fan coil air-cooled chiller with district hot water", "Fan coil air-cooled chiller with baseboard electric", "Fan coil air-cooled chiller with gas unit heaters", "Fan coil air-cooled chiller with no heat", "Fan coil district chilled water with boiler", "Fan coil district chilled water with central air source heat pump", "Fan coil district chilled water with district hot water", "Fan coil district chilled water with baseboard electric", "Fan coil district chilled water with gas unit heaters", "Fan coil district chilled water with no heat", "Forced air furnace", "Gas unit heaters", "PTAC with baseboard electric", "PTAC with baseboard gas boiler", "PTAC with baseboard district hot water", "PTAC with gas unit heaters", "PTAC with electric coil", "PTAC with gas coil", "PTAC with gas boiler", "PTAC with central air source heat pump", "PTAC with district hot water", "PTAC with no heat", "PTHP", "PSZ-AC with baseboard electric", "PSZ-AC with baseboard gas boiler", "PSZ-AC with baseboard district hot water", "PSZ-AC with gas unit heaters", "PSZ-AC with electric coil", "PSZ-AC with gas coil", "PSZ-AC with gas boiler", "PSZ-AC with central air source heat pump", "PSZ-AC with district hot water", "PSZ-AC with no heat", "PSZ-AC district chilled water with baseboard electric", "PSZ-AC district chilled water with baseboard gas boiler", "PSZ-AC district chilled water with baseboard district hot water", "PSZ-AC district chilled water with gas unit heaters", "PSZ-AC district chilled water with electric coil", "PSZ-AC district chilled water with gas coil", "PSZ-AC district chilled water with gas boiler", "PSZ-AC district chilled water with central air source heat pump", "PSZ-AC district chilled water with district hot water", "PSZ-AC district chilled water with no heat", "PSZ-HP", "PVAV with gas boiler reheat", "PVAV with central air source heat pump reheat", "PVAV with district hot water reheat", "PVAV with PFP boxes", "PVAV with gas heat with electric reheat", "Residential AC with baseboard electric", "Residential AC with baseboard gas boiler", "Residential AC with baseboard central air source heat pump", "Residential AC with baseboard district hot water", "Residential AC with residential forced air furnace", "Residential AC with no heat", "Residential heat pump", "Residential heat pump with no cooling", "Residential forced air furnace", "VAV chiller with gas boiler reheat", "VAV chiller with central air source heat pump reheat", "VAV chiller with district hot water reheat", "VAV chiller with PFP boxes", "VAV chiller with gas coil reheat", "VAV chiller with no reheat with baseboard electric", "VAV chiller with no reheat with gas unit heaters", "VAV chiller with no reheat with zone heat pump", "VAV air-cooled chiller with gas boiler reheat", "VAV air-cooled chiller with central air source heat pump reheat", "VAV air-cooled chiller with district hot water reheat", "VAV air-cooled chiller with PFP boxes", "VAV air-cooled chiller with gas coil reheat", "VAV air-cooled chiller with no reheat with baseboard electric", "VAV air-cooled chiller with no reheat with gas unit heaters", "VAV air-cooled chiller with no reheat with zone heat pump", "VAV district chilled water with gas boiler reheat", "VAV district chilled water with central air source heat pump reheat", "VAV district chilled water with district hot water reheat", "VAV district chilled water with PFP boxes", "VAV district chilled water with gas coil reheat", "VAV district chilled water with no reheat with baseboard electric", "VAV district chilled water with no reheat with gas unit heaters", "VAV district chilled water with no reheat with zone heat pump", "VRF", "Water source heat pumps fluid cooler with boiler", "Water source heat pumps cooling tower with boiler", "Water source heat pumps with ground source heat pump", "Water source heat pumps district chilled water with district hot water", "Window AC with baseboard electric", "Window AC with baseboard gas boiler", "Window AC with baseboard central air source heat pump", "Window AC with baseboard district hot water", "Window AC with forced air furnace", "Window AC with unit heaters", "Window AC with no heat"]


### HVAC System Delivery Type
How the HVAC system delivers heating or cooling to the zone.
**Name:** hvac_delivery_type,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Forced Air", "Hydronic"]


### HVAC Heating Source
The primary source of heating used by HVAC systems in the model.
**Name:** htg_src,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Electricity", "NaturalGas", "DistrictHeating", "DistrictAmbient"]


### HVAC Cooling Source
The primary source of cooling used by HVAC systems in the model.
**Name:** clg_src,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Electricity", "DistrictCooling", "DistrictAmbient"]


### Service Water Heating Source
The primary source of heating used by SWH systems in the model.
**Name:** swh_src,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Inferred", "NaturalGas", "Electricity", "HeatPump"]


### Kitchen Exhaust MakeUp Air Calculation Method
Determine logic to identify dining or cafe zones to provide makeup air to kitchen exhaust.
**Name:** kitchen_makeup,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["None", "Largest Zone", "Adjacent"]


### Exterior Lighting Zone
Identify the Exterior Lighting Zone for the Building Site.
**Name:** exterior_lighting_zone,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["0 - Undeveloped Areas Parks", "1 - Developed Areas Parks", "2 - Neighborhood", "3 - All Other Areas", "4 - High Activity"]


### Add Constructions to Model
Construction Set will be applied to entire building
**Name:** add_constructions,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add Space Type Loads to Model
Populate existing space types in model with internal loads.
**Name:** add_space_type_loads,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add Elevators to Model
Elevators will be add directly to space in model vs. being applied to a space type.
**Name:** add_elevators,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add Internal Mass to Model
Adds internal mass to each space.
**Name:** add_internal_mass,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add Exterior Lights to Model
Multiple exterior lights objects will be added for different classes of lighting such as parking and facade.
**Name:** add_exterior_lights,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Onsite Parking Fraction
If set to 0 no exterior lighting for parking will be added
**Name:** onsite_parking_fraction,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add Exhaust Fans to Model
Depending upon building type exhaust fans can be in kitchens, restrooms or other space types
**Name:** add_exhaust,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add Service Water Heating to Model
This will add both the supply and demand side of service water heating.
**Name:** add_swh,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add Thermostats
Add Thermostat to model based on Space Type Standards information of spaces assigned to thermal zones.
**Name:** add_thermostat,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add HVAC System to Model
Add HVAC System to the model
**Name:** add_hvac,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Add Refrigeration to Model
Add refrigeration cases and walkins model
**Name:** add_refrigeration,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Modify weekday hours of operation
Modify the weekday hours of operation in the model.
**Name:** modify_wkdy_op_hrs,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Weekday Operating Hours Start Time
Enter 24 hour values with fractional values converted to minutes. e.g. 17.25 = 5:15pm. Only used if Modify weekday hours of operation is true.
**Name:** wkdy_op_hrs_start_time,
**Type:** Double,
**Units:** Hours,
**Required:** true,
**Model Dependent:** false


### Weekday Operating Hours Duration
Length of weekday operating hours. Enter 24 hour values with fractional values converted to minutes. e.g. 17.25 = 5:15pm. Only used if Modify weekday hours of operation is true.
**Name:** wkdy_op_hrs_duration,
**Type:** Double,
**Units:** Hours,
**Required:** true,
**Model Dependent:** false


### Modify weekend hours of operation
Modify the weekend hours of operation in the model.
**Name:** modify_wknd_op_hrs,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Weekend Operating Hours Start Time
Enter 24 hour values with fractional values converted to minutes. e.g. 17.25 = 5:15pm.  Only used if Modify weekend hours of operation is true.
**Name:** wknd_op_hrs_start_time,
**Type:** Double,
**Units:** Hours,
**Required:** true,
**Model Dependent:** false


### Weekend Operating Hours Duration
Length of weekend operating hours. Enter 24 hour values with fractional values converted to minutes. e.g. 17.25 = 5:15pm.  Only used if Modify weekend hours of operation is true.
**Name:** wknd_op_hrs_duration,
**Type:** Double,
**Units:** Hours,
**Required:** true,
**Model Dependent:** false


### Unmet Hours Tolerance
Set the thermostat setpoint tolerance for unmet hours in degrees Rankine
**Name:** unmet_hours_tolerance,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Clean Model of non-geometry objects
Only removes objects of type that are selected to be added.
**Name:** remove_objects,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Use Upstream Argument Values
When true this will look for arguments or registerValues in upstream measures that match arguments from this measure, and will use the value from the upstream measure in place of what is entered for this measure.
**Name:** use_upstream_args,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Enable Daylight Savings
By default this will force daylight savings to be enabled. Set to false if in a location where DST is not followed, or if needed for specific use case.
**Name:** enable_dst,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Climate Zone.

**Name:** climate_zone,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Lookup From Model", "ASHRAE 169-2013-1A", "ASHRAE 169-2013-1B", "ASHRAE 169-2013-2A", "ASHRAE 169-2013-2B", "ASHRAE 169-2013-3A", "ASHRAE 169-2013-3B", "ASHRAE 169-2013-3C", "ASHRAE 169-2013-4A", "ASHRAE 169-2013-4B", "ASHRAE 169-2013-4C", "ASHRAE 169-2013-5A", "ASHRAE 169-2013-5B", "ASHRAE 169-2013-5C", "ASHRAE 169-2013-6A", "ASHRAE 169-2013-6B", "ASHRAE 169-2013-7A", "ASHRAE 169-2013-8A", "CEC T24-CEC1", "CEC T24-CEC2", "CEC T24-CEC3", "CEC T24-CEC4", "CEC T24-CEC5", "CEC T24-CEC6", "CEC T24-CEC7", "CEC T24-CEC8", "CEC T24-CEC9", "CEC T24-CEC10", "CEC T24-CEC11", "CEC T24-CEC12", "CEC T24-CEC13", "CEC T24-CEC14", "CEC T24-CEC15", "CEC T24-CEC16"]





