# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class GHThermalCurtainsOnOff < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'GH_ThermalCurtainsOnOff'
  end

  # human readable description
  def description
    return 'Uses shading devices and schedules to represent the thermal savings from a thermal curtain in ag.  Uses conductivity, and emmisivity, VLT properties etc for a shade:material,  then a schedule for closed at night.'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Looks for Shade Control 3, and sets schedule to AlwaysOff or OnIfAvailabile'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    sched_type = OpenStudio::StringVector.new
    sched_type << 'OnNightIfLowOutdoorTempAndOffDay'
    sched_type << 'OnIfScheduleAllows'
    sched_type << 'AlwaysOff'

    # the name of the space to add to the model
    thermal_curtain_sched = OpenStudio::Measure::OSArgument.makeChoiceArgument('thermal_curtain_sched',sched_type,true)
    thermal_curtain_sched.setDisplayName('Choose Control Type for Shading:Control')
    thermal_curtain_sched.setDefaultValue("AlwaysOFf")
    args << thermal_curtain_sched

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables
    thermal_curtain_sched = runner.getStringArgumentValue('thermal_curtain_sched', user_arguments)

    control = model.getShadingControls.each do |control|
      if control.name.get.match("Shading Control 3")
        control.setShadingControlType(thermal_curtain_sched)
      end
    end
    

    return true
  end
end

# register the measure to be used by the application
GHThermalCurtainsOnOff.new.registerWithApplication
