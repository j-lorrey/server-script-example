

###### (Automatically generated documentation)

# GH_ThermalCurtainsOnOff

## Description
Uses shading devices and schedules to represent the thermal savings from a thermal curtain in ag.  Uses conductivity, and emmisivity, VLT properties etc for a shade:material,  then a schedule for closed at night.

## Modeler Description
Looks for Shade Control 3, and sets schedule to AlwaysOff or OnIfAvailabile

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose Control Type for Shading:Control

**Name:** thermal_curtain_sched,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false




