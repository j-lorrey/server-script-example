# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class GroceryCustomRefrigerants < OpenStudio::Ruleset::WorkspaceUserScript

  # define the name that a user will see, this method may be deprecated as
  # the display name in PAT comes from the name field in measure.xml
  def name
    return "GroceryCustomRefrigerants"
  end
  # define the arguments that the user will input
  def arguments(workspace)
    args = OpenStudio::Ruleset::OSArgumentVector.new

    lotemp_ref_fluid = OpenStudio::Measure::OSArgument.makeChoiceArgument('lotemp_ref_fluid', true)
    args << lotemp_ref_fluid
    hitemp_ref_fluid = OpenStudio::Measure::OSArgument.makeChoiceArgument('hitemp_ref_fluid', true)
    args << hitemp_ref_fluid

    return args
  end #end the arguments method

  # define what happens when the measure is run
  def run(workspace, runner, user_arguments)
    super(workspace, runner, user_arguments)

    #use the built-in error checking 
    if not runner.validateUserArguments(arguments(workspace), user_arguments)
      return false
    end

    # assign the user inputs to variables
    # file_name = runner.getStringArgumentValue("file_name", user_arguments)
    # file_directory = runner.getStringArgumentValue("file_directory", user_arguments)
    file_directory = "./resources"
    hitemp_ref_fluid = runner.getChoiceArgumentValue("hitemp_ref_fluid", user_arguments)

    # Commenting out sections intended to combine the two parts of the measure
    # refsys_name = runner.getStringArgumentValue("refsys_name", user_arguments)

    # report initial condtion
    runner.registerInitialCondition("The initial IDF file had #{workspace.objects.size} objects.")

    if not hitemp_ref_fluid == "R448a"
      return false
    end
    
    
    if hitemp_ref_fluid == "R448a"
      file_name = "R448a.idf"
    elsif hitemp_ref_fluid == "R290"
      file_name = "R290.idf"
    end
    
    unless (Pathname.new file_directory).absolute?
      file_directory = File.expand_path(File.join(File.dirname(__FILE__), file_directory))
    end
    
    #merge file name and path
    idf_file = File.join(file_directory, file_name)
    # runner.registerInfo("idf_file")
    # runner.registerInfo(idf_file)

    #load from ./resources folder
    source_idf = OpenStudio::IdfFile.load(OpenStudio::Path.new(idf_file)).get

    # add objects to workspace, aka into the in.idf after checking them against the idd
    workspace.addObjects(source_idf.objects)

    # Development registers for info
    # runner.registerInfo("refsys_name")
    # runner.registerInfo(refsys_name)
    # # runner.registerInfo(refsys_name.class)
    # runner.registerInfo("additional_ref_fluid_selection")
    # runner.registerInfo(additional_ref_fluid_selection)
    # # runner.registerInfo(additional_ref_fluid_selection.class)
  
    # review the objects idd screened into the workspace for valid Refrigeration:Systems that match the name
    ref_sys = workspace.getObjectByTypeAndName("Refrigeration:System".to_IddObjectType, "Medium Temperature").get
    runner.registerInfo("ref_sys")
    runner.registerInfo(ref_sys.to_s)
  
    ref_sys.setString(6, hitemp_ref_fluid.to_s)

    runner.registerInfo("ref_sys_modified")
    runner.registerInfo(ref_sys.to_s)

    # report final condition
    runner.registerFinalCondition("The final IDF file had #{workspace.objects.size} objects.")

  return true

  end #end the run method

end #end the measure

#this allows the measure to be use by the application
GroceryCustomRefrigerants.new.registerWithApplication