

###### (Automatically generated documentation)

# Peak Report

## Description
foo

## Modeler Description
bar 

## Measure Type
ReportingMeasure

## Taxonomy


## Arguments


### Coincident Peak Demand and Peak energy

**Name:** coincident_section,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false




