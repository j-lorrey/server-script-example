# *******************************************************************************
# OpenStudio(R), Copyright (c) 2008-2018, Alliance for Sustainable Energy, LLC.
# All rights reserved.
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# (1) Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# (2) Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# (3) Neither the name of the copyright holder nor the names of any contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission from the respective party.
#
# (4) Other than as required in clauses (1) and (2), distributions in any form
# of modifications or other derivative works may not use the "OpenStudio"
# trademark, "OS", "os", or any other confusingly similar designation without
# specific prior written permission from Alliance for Sustainable Energy, LLC.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER(S) AND ANY CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER(S), ANY CONTRIBUTORS, THE
# UNITED STATES GOVERNMENT, OR THE UNITED STATES DEPARTMENT OF ENERGY, NOR ANY OF
# THEIR EMPLOYEES, BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# *******************************************************************************

require 'json'

module OsLib_Reporting_example
  # setup - get model, sql, and setup web assets path
  def self.setup(runner)
    results = {}

    # get the last model
    model = runner.lastOpenStudioModel
    if model.empty?
      runner.registerError('Cannot find last model.')
      return false
    end
    model = model.get

    # get the last idf
    workspace = runner.lastEnergyPlusWorkspace
    if workspace.empty?
      runner.registerError('Cannot find last idf file.')
      return false
    end
    workspace = workspace.get

    # get the last sql file
    sqlFile = runner.lastEnergyPlusSqlFile
    if sqlFile.empty?
      runner.registerError('Cannot find last sql file.')
      return false
    end
    sqlFile = sqlFile.get
    model.setSqlFile(sqlFile)

    # populate hash to pass to measure
    results[:model] = model
    # results[:workspace] = workspace
    results[:sqlFile] = sqlFile
    results[:web_asset_path] = OpenStudio.getSharedResourcesPath / OpenStudio::Path.new('web_assets')

    return results
  end


  # create section
  def self.coincident_section(model, sqlFile, runner, name_only = false)
    # array to hold tables
    tables = []

    # gather data for section
    @coincident_section = {}
    @coincident_section[:title] = 'Coincident Peak Demand and Peak energy'
    @coincident_section[:tables] = tables

    # stop here if only name is requested this is used to populate display name for arguments
    if name_only == true
      return @coincident_section
    end

    # create table
    coincidentPeakTable = {}
    coincidentPeakTable[:title] = 'Coincident Peak Demand Table'
    coincidentPeakTable[:header] = ['Summer On', 'Winter On']
    coincidentPeakTable[:units] = ['kW', 'kW']
    coincidentPeakTable[:data] = []

    #Start On Winter Coincident Peak Demand
    query = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='COINCIDENT_PEAK' AND TableName='Native Variables' AND RowName='PeakDemand'"
    onPeakArray = sqlFile.execAndReturnVectorOfDouble(query).get
    query1 = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='COINCIDENT_PEAK' AND TableName='Native Variables' AND RowName='IsWinter'"
    isWinterArray = sqlFile.execAndReturnVectorOfInt(query1).get
    winterOnPeakDemandArray = []
    for i in 0..(onPeakArray.size-3)
      winterOnPeakDemandArray << (isWinterArray[i].to_i)*(onPeakArray[i].to_f)
    end
    winterOnPeakDemandMax = winterOnPeakDemandArray.max

    #Start On Summer Coincident Peak Demand
    query = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='COINCIDENT_PEAK' AND TableName='Native Variables' AND RowName='PeakDemand'"
    onPeakArray = sqlFile.execAndReturnVectorOfDouble(query).get
    query1 = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='COINCIDENT_PEAK' AND TableName='Native Variables' AND RowName='IsSummer'"
    isSummerArray = sqlFile.execAndReturnVectorOfInt(query1).get
    summerOnPeakDemandArray = []
    for i in 0..(onPeakArray.size-3)
      summerOnPeakDemandArray << (isSummerArray[i].to_i)*(onPeakArray[i].to_f)
    end
    summerOnPeakDemandMax = summerOnPeakDemandArray.max
    # add Data to table
    coincidentPeakTable[:data] << [summerOnPeakDemandMax, winterOnPeakDemandMax]


    #Start Loadshapes
    # create table
    loadshapePeakTable = {}
    loadshapePeakTable[:title] = 'Summer/Winter On/Off Peak Table'
    loadshapePeakTable[:header] = ['Season','On Peak', 'Off Peak']
    loadshapePeakTable[:units] = ['','kW', 'kW']
    loadshapePeakTable[:data] = []

    #Gather Updated isSummer and isWinter arrays
    query1 = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='ENERGY_LOADSHAPE' AND TableName='Native Variables' AND RowName='IsWinter'"
    isWinterArray = sqlFile.execAndReturnVectorOfInt(query1).get

    query1 = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='ENERGY_LOADSHAPE' AND TableName='Native Variables' AND RowName='IsSummer'"
    isSummerArray = sqlFile.execAndReturnVectorOfInt(query1).get

    query = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='ENERGY_LOADSHAPE' AND TableName='Native Variables' AND RowName='PeakEnergy'"
    onPeakLoadshapeArray = sqlFile.execAndReturnVectorOfDouble(query).get
    summerOnPeakLoadshapeArray = []
    for i in 0..(onPeakLoadshapeArray.size-3)
      summerOnPeakLoadshapeArray << (isSummerArray[i].to_i)*(onPeakLoadshapeArray[i].to_f)
    end
    summerOnPeakLoadshapeSum = 0 
    summerOnPeakLoadshapeArray.each { |a| summerOnPeakLoadshapeSum+=a }
    
    query = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='ENERGY_LOADSHAPE' AND TableName='Native Variables' AND RowName='OffPeakEnergy'"
    offPeakLoadshapeArray = sqlFile.execAndReturnVectorOfDouble(query).get

    summerOffPeakLoadshapeArray = []
    for i in 0..(offPeakLoadshapeArray.size-3)
      summerOffPeakLoadshapeArray << (isSummerArray[i].to_i)*(offPeakLoadshapeArray[i].to_f)
    end
    summerOffPeakLoadshapeSum = 0 
    summerOffPeakLoadshapeArray.each { |b| summerOffPeakLoadshapeSum+=b }

    loadshapePeakTable[:data] << ['Summer', summerOnPeakLoadshapeSum.round(2), summerOffPeakLoadshapeSum.round(2)]


    query = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='ENERGY_LOADSHAPE' AND TableName='Native Variables' AND RowName='PeakEnergy'"
    onPeakLoadshapeArray = sqlFile.execAndReturnVectorOfDouble(query).get
    winterOnPeakLoadshapeArray = []
    for i in 0..(onPeakLoadshapeArray.size-3)
      winterOnPeakLoadshapeArray << (isWinterArray[i].to_i)*(onPeakLoadshapeArray[i].to_f)
    end
    winterOnPeakLoadshapeSum = 0 
    winterOnPeakLoadshapeArray.each { |c| winterOnPeakLoadshapeSum+=c }
    
    query = "SELECT Value FROM tabulardatawithstrings WHERE ReportName='Tariff Report' AND ReportForString='ENERGY_LOADSHAPE' AND TableName='Native Variables' AND RowName='OffPeakEnergy'"
    offPeakLoadshapeArray = sqlFile.execAndReturnVectorOfDouble(query).get

    winterOffPeakLoadshapeArray = []
    for i in 0..(offPeakLoadshapeArray.size-3)
      winterOffPeakLoadshapeArray << (isWinterArray[i].to_i)*(offPeakLoadshapeArray[i].to_f)
    end
    winterOffPeakLoadshapeSum = 0 
    winterOffPeakLoadshapeArray.each { |d| winterOffPeakLoadshapeSum+=d }

    loadshapePeakTable[:data] << ['Winter', winterOnPeakLoadshapeSum.round(2), winterOffPeakLoadshapeSum.round(2)]

    # add table to array of tables
    tables << coincidentPeakTable
    tables << loadshapePeakTable

    return @coincident_section

  end

end
