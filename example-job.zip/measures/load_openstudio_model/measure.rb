# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure

#require "#{File.dirname(__FILE__)}/resources"

class LoadOpenStudioModel < OpenStudio::Ruleset::ModelUserScript

  # human readable name
  def name
    return "Load OpenStudio Model"
  end

  # human readable description
  def description
    return "This measure is intended to be used in place of a create DOE prototype when looking at different buildings. This is needed for difficult HVAC system swaps, or for developing specific prototypes - IE Vermont generalized - or Radiant floor 5zone etc"
  end

  # human readable description of modeling approach
  def modeler_description
    return "Loads an OSM from within the measure resource folder."
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Ruleset::OSArgumentVector.new

    osm_directory = OpenStudio::Measure::OSArgument.makeStringArgument("osm_directory", true)
	  osm_directory.setDisplayName("OSM File Directory")
    osm_directory.setDescription("Absolute (or relative) directory to model files.")
	  osm_directory.setDefaultValue("./resources")
  	args << osm_directory

	  osm_file_name = OpenStudio::Measure::OSArgument.makeStringArgument("osm_file_name", true)
	  osm_file_name.setDisplayName("OSM File Name")
    osm_file_name.setDescription("Name of the File including the .osm extention")
    osm_file_name.setDefaultValue("ex. MyModel.osm")
    args << osm_file_name
	
    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

	    # assign the user inputs to variables
    osm_file_name = runner.getStringArgumentValue("osm_file_name", user_arguments)
	  osm_directory = runner.getStringArgumentValue("osm_directory", user_arguments)
	
  	runner.registerInitialCondition("Original model is: #{model.building.get}")
	
	# make and empty workspace
	  workspace = OpenStudio::Workspace.new("Draft".to_StrictnessLevel, "EnergyPlus".to_IddFileType)
    

	# Set Model File 
	unless (Pathname.new osm_directory).absolute?
    osm_directory = File.expand_path(File.join(File.dirname(__FILE__), osm_directory))
  end
	#merge file name and path
  osm_file = File.join(osm_directory, osm_file_name)

  model_path = OpenStudio::Path.new(osm_file)
  translator = OpenStudio::OSVersion::VersionTranslator.new
  
  if OpenStudio::exists(model_path)
    oModel = translator.loadModel(model_path)
    if oModel.empty?
      puts "Version translation failed for #{model_path}"
    else
      newModel = oModel.get
    end
  else
    puts "The model couldn't be found at #{model_path}"
  end

  weatherFile = newModel.getOptionalWeatherFile
  if not weatherFile.empty?
    weatherFile.get.remove
  end
  originalWeatherFile = model.getOptionalWeatherFile
  if not originalWeatherFile.empty?
    originalWeatherFile.get.clone(newModel)
  end
  runner.registerInfo("Replacing alternate model's weather file object.")

  
  handles = OpenStudio::UUIDVector.new
    model.objects.each do |obj|
      handles << obj.handle
    end
    model.removeObjects(handles)
    # add new file to empty model
    model.addObjects(newModel.toIdfFile.objects)
  
  runner.registerInfo("Path supplied by user is: #{osm_file}")
  
	runner.registerFinalCondition("Loaded model is: #{model.building.get}")
  
  return model

  end
    
end

# register the measure to be used by the application
LoadOpenStudioModel.new.registerWithApplication