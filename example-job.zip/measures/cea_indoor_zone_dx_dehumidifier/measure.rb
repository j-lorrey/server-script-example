# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CeaIndoorZoneDxDehumidifier < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'cea_indoor_zone_dx_dehumidifier'
  end

  # human readable description
  def description
    return 'Adds a thermal zone level dehumidifiier '
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Finds Thermal Zones withing the model - user selectable - add adds a zone dehumidifier with rated efficiency as a float.  Includes adding a ZoneHVAC:Dehumidifier:DX.

'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # make a choice argument for model objects
    space_handles = OpenStudio::StringVector.new
    space_display_names = OpenStudio::StringVector.new

    # putting model object and names into hash
    space_args = model.getSpaces
    space_args_hash = {}
    space_args.each do |space_arg|
      space_args_hash[space_arg.name.to_s] = space_arg
    end

    # looping through sorted hash of model objects
    space_args_hash.sort.map do |key, value|
      space_handles << value.handle.to_s
      space_display_names << key
    end

    # make a choice argument for veg_space type or entire building
    veg_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('veg_space', space_handles, space_display_names, true)
    veg_space.setDisplayName('Choose a veg space')
    args << veg_space
    flower_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('flower_space', space_handles, space_display_names, true)
    flower_space.setDisplayName('Choose a flower space')
    args << flower_space

    # veg_rated_efficiency_factor = OpenStudio::Measure::OSArgument.makeDoubleArgument('veg_rated_efficiency_factor', true)
    # veg_rated_efficiency_factor.setDisplayName('Enter the Rated Efficiency Factor for Veg DX Dehumidiier')
    # veg_rated_efficiency_factor.setDefaultValue(3.41) #mL/Wh is the OS input - EPlus shows l/kwh  edit: these are equal
    # args << veg_rated_efficiency_factor

    veg_num_of_dh_units = OpenStudio::Measure::OSArgument.makeDoubleArgument('veg_num_of_dh_units', true)
    veg_num_of_dh_units.setDisplayName('How many dh units are installed in the veg zone?')
    veg_num_of_dh_units.setDefaultValue(0) #0 skips this measre in the run method
    args << veg_num_of_dh_units

    rated_efficiency_factor = OpenStudio::Measure::OSArgument.makeDoubleArgument('rated_efficiency_factor', true)
    rated_efficiency_factor.setDisplayName('Enter the Rated Efficiency Factor for DX Dehumidiier')
    rated_efficiency_factor.setDefaultValue(3.41) #mL/Wh is the OS input - EPlus shows l/kwh  edit: these are equal
    args << rated_efficiency_factor

    flower_num_of_dh_units = OpenStudio::Measure::OSArgument.makeDoubleArgument('flower_num_of_dh_units', true)
    flower_num_of_dh_units.setDisplayName('How many dh units are installed in the flower zone?')
    flower_num_of_dh_units.setDefaultValue(0) #0 skips this measre in the run method
    args << flower_num_of_dh_units
    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    veg_space = runner.getOptionalWorkspaceObjectChoiceValue('veg_space', user_arguments, model)
    flower_space = runner.getOptionalWorkspaceObjectChoiceValue('flower_space', user_arguments, model)

    # assign the user inputs to variables
      #cast object from the model to_ObjectType within this workspace
    veg_space = veg_space.get.to_Space.get
    veg_thermal_zone = veg_space.thermalZone.get
    flower_space = flower_space.get.to_Space.get
    flower_thermal_zone = flower_space.thermalZone.get
    # veg_rated_efficiency_factor = runner.getDoubleArgumentValue('veg_rated_efficiency_factor', user_arguments)
    veg_num_of_dh_units = runner.getDoubleArgumentValue('veg_num_of_dh_units', user_arguments)
    rated_efficiency_factor = runner.getDoubleArgumentValue('rated_efficiency_factor', user_arguments)
    flower_num_of_dh_units = runner.getDoubleArgumentValue('flower_num_of_dh_units', user_arguments)

    if veg_num_of_dh_units == 0
      runner.registerInfo("0 units selected therefore measure skipped")
      return true
    end


    for i in 1..veg_num_of_dh_units
      new_dehumidifier = OpenStudio::Model::ZoneHVACDehumidifierDX.new(model)
      new_dehumidifier.setName("#{veg_thermal_zone.name}-Dehumidifier-##{i} with #{rated_efficiency_factor} rated_energy_factor")
      new_dehumidifier.setRatedEnergyFactor(rated_efficiency_factor)
      puts "******************************************************************"
      puts "new dehumidifer"
      puts new_dehumidifier
      # zone.addEquipment(new_dehumidifier) #this SWIG method does not work https://github.com/NREL/OpenStudio/commit/ae735b843af0329a8d43a55b1de1e661326fd1e8
      # use this addToThermalZone swig method instead
      new_dehumidifier.addToThermalZone(veg_thermal_zone)
      puts "********************************************************************"
      puts "zone with new_dehumidifier"
      puts veg_thermal_zone
    end

    for i in 1..flower_num_of_dh_units
      new_dehumidifier = OpenStudio::Model::ZoneHVACDehumidifierDX.new(model)
      new_dehumidifier.setName("#{flower_thermal_zone.name}-Dehumidifier-##{i} with #{rated_efficiency_factor} rated_energy_factor")
      new_dehumidifier.setRatedEnergyFactor(rated_efficiency_factor)
      puts "******************************************************************"
      puts "new dehumidifer"
      puts new_dehumidifier
      # zone.addEquipment(new_dehumidifier) #this SWIG method does not work https://github.com/NREL/OpenStudio/commit/ae735b843af0329a8d43a55b1de1e661326fd1e8
      # use this addToThermalZone swig method instead
      new_dehumidifier.addToThermalZone(flower_thermal_zone)
      puts "********************************************************************"
      puts "zone with new_dehumidifier"
      puts flower_thermal_zone
    end
    
    return true
  end
end

# register the measure to be used by the application
CeaIndoorZoneDxDehumidifier.new.registerWithApplication
