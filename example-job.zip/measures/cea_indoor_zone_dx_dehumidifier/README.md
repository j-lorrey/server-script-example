

###### (Automatically generated documentation)

# cea_indoor_zone_dx_dehumidifier

## Description
Adds a thermal zone level dehumidifiier 

## Modeler Description
Finds Thermal Zones withing the model - user selectable - add adds a zone dehumidifier with rated efficiency as a float.  Includes adding a ZoneHVAC:Dehumidifier:DX.



## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose a veg space

**Name:** veg_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose a flower space

**Name:** flower_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### How many dh units are installed in the veg zone?

**Name:** veg_num_of_dh_units,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Enter the Rated Efficiency Factor for DX Dehumidiier

**Name:** rated_efficiency_factor,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### How many dh units are installed in the flower zone?

**Name:** flower_num_of_dh_units,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




