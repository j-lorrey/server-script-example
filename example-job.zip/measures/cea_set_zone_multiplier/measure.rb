# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CEASetZoneMultiplier < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'CEA_set_zone_multiplier'
  end

  # human readable description
  def description
    return 'Use space name to access the zone and then adjust the multiplier'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Use case is for the indoor cea where we copy the culitvation zones over and over.'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # make a choice argument for model objects
    space_handles = OpenStudio::StringVector.new
    space_display_names = OpenStudio::StringVector.new

    # putting model object and names into hash
    space_args = model.getSpaces
    space_args_hash = {}
    space_args.each do |space_arg|
      space_args_hash[space_arg.name.to_s] = space_arg
    end

    # looping through sorted hash of model objects
    space_args_hash.sort.map do |key, value|
      space_handles << value.handle.to_s
      space_display_names << key
    end

    # make a choice argument for space type or entire building
    veg_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('veg_space', space_handles, space_display_names, true)
    veg_space.setDisplayName('Choose a veg space')
    args << veg_space
    # take input arguments for multipliers
    veg_mult = OpenStudio::Measure::OSArgument.makeDoubleArgument('veg_mult', true)
    veg_mult.setDisplayName("How many veg rooms?")
    veg_mult.setDefaultValue(1)
    args << veg_mult

    # make a choice argument for space type or entire building
    flower_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('flower_space', space_handles, space_display_names, true)
    flower_space.setDisplayName('Choose a flower space')
    args << flower_space
    # take input arguments for multipliers
    flower_mult = OpenStudio::Measure::OSArgument.makeDoubleArgument('flower_mult', true)
    flower_mult.setDisplayName("How many flower rooms?")
    flower_mult.setDefaultValue(1)
    args << flower_mult

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables
    veg_space = runner.getOptionalWorkspaceObjectChoiceValue('veg_space', user_arguments, model)
    veg_mult = runner.getDoubleArgumentValue('veg_mult', user_arguments)
    flower_space = runner.getOptionalWorkspaceObjectChoiceValue('flower_space', user_arguments, model)
    flower_mult = runner.getDoubleArgumentValue('flower_mult', user_arguments)

    #cast object from the model to_ObjectType within this workspace
    veg_space = veg_space.get.to_Space.get
    veg_thermal_zone = veg_space.thermalZone.get

    veg_thermal_zone.setMultiplier(veg_mult.to_i) #cast float to integer .to_i

    flower_space = flower_space.get.to_Space.get
    flower_thermal_zone = flower_space.thermalZone.get

    flower_thermal_zone.setMultiplier(flower_mult.to_i) #cast float to integer .to_i

    puts flower_thermal_zone

    puts veg_thermal_zone

    return true
  end
end

# register the measure to be used by the application
CEASetZoneMultiplier.new.registerWithApplication
