

###### (Automatically generated documentation)

# CEA_set_zone_multiplier

## Description
Use space name to access the zone and then adjust the multiplier

## Modeler Description
Use case is for the indoor cea where we copy the culitvation zones over and over.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose a veg space

**Name:** veg_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### How many veg rooms?

**Name:** veg_mult,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose a flower space

**Name:** flower_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### How many flower rooms?

**Name:** flower_mult,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




