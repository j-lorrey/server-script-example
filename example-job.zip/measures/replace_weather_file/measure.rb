# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/


require "#{File.dirname(__FILE__)}/resources/weather"
require "#{File.dirname(__FILE__)}/resources/constants"

# start the measure
class ReplaceWeatherFile < OpenStudio::Ruleset::ModelUserScript

  # human readable name
  def name
    return "ReplaceWeatherFile"
  end

  # human readable description
  def description
    return "Sets the EPW weather file (EPW), supplemental data specific to the location, and daylight saving time start/end dates."
  end

  # human readable description of modeling approach
  def modeler_description
    return "Sets the weather file, Building America climate zone, site information (e.g., latitude, longitude, elevation, timezone), design day information (from the DDY file), the mains water temperature using the correlation method, and the daylight saving time start/end dates."
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    weather_directory = OpenStudio::Measure::OSArgument.makeStringArgument("weather_directory", true)
    weather_directory.setDisplayName("Weather Directory")
    weather_directory.setDescription("Absolute (or relative) directory to weather files.")
    weather_directory.setDefaultValue("./resources")
    args << weather_directory

    weather_file_choices = OpenStudio::StringVector.new

    for file in Dir.entries("#{File.dirname(__FILE__)}/resources")
      if file.end_with?('.epw')
        weather_file_choices << file
      end
    end

  #auto-populate from resources directory
  # weather_file_choices = OpenStudio::StringVector.new
	# weather_file_choices << "USA_VT_Burlington.Intl.AP.726170_TMY3.epw"
	# weather_file_choices << "USA_VT_Montpelier.AP.726145_TMY3.epw"
  # weather_file_choices << "USA_VT_Rutland.State.AP.725165_TMY3.epw"
  # weather_file_choices << "USA_IA_Burlington.Muni.AP.725455_TMY3.epw"
  # weather_file_choices << "USA_IA_Des.Moines.Intl.AP.725460_TMY3.epw"
  # weather_file_choices << "USA_IA_Mason.City.Muni.AP.725485_TMY3.epw"
  # weather_file_choices << "USA_VT_Springfield-Hartnes.State.AP.726115_TMY3.epw"
  # weather_file_choices << "CO_ALAMOSA-SAN-LUIS-VAL-RGNL_724620_TY3A.epw"
  # weather_file_choices << "CO_DENVER-IAP_725650_TY3A.epw"
  # weather_file_choices << "CO_GRAND-JUNCTION-WALKER-FLD_724760_TY3A.epw"
  
	weather_file_name = OpenStudio::Ruleset::OSArgument::makeChoiceArgument("weather_file_name", weather_file_choices,true)
    weather_file_name.setDisplayName("Weather File")
	weather_file_name.setDefaultValue("VT_BURLINGTON-IAP_726170_TY3A.epw")
    args << weather_file_name	
	
    dst_start_date = OpenStudio::Measure::OSArgument.makeStringArgument("dst_start_date", true)
    dst_start_date.setDisplayName("Daylight Saving Start Date")
    dst_start_date.setDescription("Type 'NA' if no daylight saving.")
    dst_start_date.setDefaultValue("NA")
    args << dst_start_date
    
    dst_end_date = OpenStudio::Measure::OSArgument.makeStringArgument("dst_end_date", true)
    dst_end_date.setDisplayName("Daylight Saving End Date")
    dst_end_date.setDescription("Type 'NA' if no daylight saving.")
    dst_end_date.setDefaultValue("NA")
    args << dst_end_date
		
    return args

	end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables
    weather_directory = runner.getStringArgumentValue("weather_directory", user_arguments)
    weather_file_name = runner.getStringArgumentValue("weather_file_name", user_arguments)
    dst_start_date = runner.getStringArgumentValue("dst_start_date", user_arguments)
    dst_end_date = runner.getStringArgumentValue("dst_end_date", user_arguments)
  
    # Declare variables for proper scope
    initial_weather_file_city = []
    final_weather_file_city = []
    initial_dst_start_date = []
    final_dst_start_date = []
    initial_dst_end_date = []
    final_dst_end_date = []
    initial_design_days_count = 0
  
    # Set Weather File 
	unless (Pathname.new weather_directory).absolute?
      weather_directory = File.expand_path(File.join(File.dirname(__FILE__), weather_directory))
    end
    weather_file = File.join(weather_directory, weather_file_name)
    if File.exists?(weather_file) and weather_file_name.downcase.end_with? ".epw"
        epw_file = OpenStudio::EpwFile.new(weather_file)
    else
      runner.registerError("'#{weather_file}' does not exist or is not an .epw file.")
      return false
    end

    climate_zone = model.getClimateZones.getClimateZone("ASHRAE", 2006).value
    if climate_zone.empty? then
      runner.registerInitialCondition("No climate zone is set.")
    else
      runner.registerInitialCondition("The initial climate zone is #{climate_zone}.")
    end
    
    if model.getSite.weatherFile.is_initialized
      initial_weather_file_city = model.getSite.weatherFile.get.city
      runner.registerInfo("Found an existing weather file.")
    end
    OpenStudio::Model::WeatherFile.setWeatherFile(model, epw_file).get
    final_weather_file_city = epw_file.city
    runner.registerInfo("Setting weather file to #{weather_file_name}.")
    weather = WeatherProcess.new(model, runner, File.dirname(__FILE__))
    if weather.error?
      return false
    end

    wmo = epw_file.wmoNumber()

    count = 0
    csv_data = []
    CSV.foreach("#{File.dirname(__FILE__)}/resources/climate_zones.csv") do |row|
      if row[0] == wmo
        csv_data << row[6]
      end
    end
    climate_zone = csv_data[0]

    model.getClimateZones.setClimateZone("ASHRAE", climate_zone)
   
    # set model site data
    site = model.getSite
    site.setName("#{epw_file.city}_#{epw_file.stateProvinceRegion}_#{epw_file.country}")
    site.setLatitude(epw_file.latitude)
    site.setLongitude(epw_file.longitude)
    site.setTimeZone(epw_file.timeZone)
    site.setElevation(epw_file.elevation)
    runner.registerInfo("Setting site data.")

    # set Model design day info - Begin by removing all the Design Day objects that are in the file
    
    model.getDesignDays.each do |design_day|
      runner.registerInfo("Removing Design Day weather information record named #{design_day.name} from the model.")
      design_day.remove
      initial_design_days_count = initial_design_days_count + 1
    end
    
    # write out warning message if no DDY file available.
    ddy_file = "#{File.join(File.dirname(weather_file), File.basename(weather_file, '.*'))}.DDY"
    if not File.exist? ddy_file
      ddy_file = "#{File.join(File.dirname(weather_file), File.basename(weather_file, '.*'))}.ddy"
      if not File.exist? ddy_file
        runner.registerWarning("Could not find DDY file at #{ddy_file}. As a backup, design day information will be calculated from the EPW file.")
      end
    end
    
    # add selected .ddy types to the model
    ddy_model = OpenStudio::EnergyPlus.loadAndTranslateIdf(ddy_file).get
    ddy_model.getObjectsByType("OS:SizingPeriod:DesignDay".to_IddObjectType).each do |d|
    # grab only the ones that matter
    ddy_list = /(Htg 99.6. Condns DB)|(Clg .4. Condns WB=>MDB)|(Clg .4% Condns DB=>MWB)/
      if d.name.get =~ ddy_list
        runner.registerInfo("Adding object #{d.name}")

        # add the object to the existing model
        model.addObject(d.clone)
      end
    end
    final_design_days = model.getDesignDays
    
    # Set temperature of service water mains based on weather file using Correlation Method
    avgOAT = OpenStudio::convert(weather.data.AnnualAvgDrybulb,"F","C").get
    monthlyOAT = weather.data.MonthlyAvgDrybulbs
    
    min_temp = monthlyOAT.min
    max_temp = monthlyOAT.max
    
    maxDiffOAT = OpenStudio::convert(max_temp,"F","C").get - OpenStudio::convert(min_temp,"F","C").get
     
    #Calc annual average mains temperature to report to user 
    swmt = model.getSiteWaterMainsTemperature
    swmt.setCalculationMethod "Correlation"
    swmt.setAnnualAverageOutdoorAirTemperature(avgOAT)
    swmt.setMaximumDifferenceInMonthlyAverageOutdoorAirTemperatures(maxDiffOAT)
    runner.registerInfo("Setting mains water temperature profile with an average temperature of #{weather.data.MainsAvgTemp.round(1)} F.")
    
    # Retrieve initial DST start and end dates
    initial_dst_start_date = model.getRunPeriodControlDaylightSavingTime.startDate
    initial_dst_end_date = model.getRunPeriodControlDaylightSavingTime.endDate

    # Set daylight saving time
    if not (dst_start_date.downcase == 'na' and dst_end_date.downcase == 'na')
      begin
        dst_start_date_month = OpenStudio::monthOfYear(dst_start_date.split[0])
        dst_start_date_day = dst_start_date.split[1].to_i
        dst_end_date_month = OpenStudio::monthOfYear(dst_end_date.split[0])
        dst_end_date_day = dst_end_date.split[1].to_i    
            
        dst = model.getRunPeriodControlDaylightSavingTime
        dst.setStartDate(dst_start_date_month, dst_start_date_day)
        dst.setEndDate(dst_end_date_month, dst_end_date_day) 
        final_dst_start_date = dst.startDate.to_s
        final_dst_end_date = dst.endDate.to_s
        
        runner.registerInfo("Daylight saving time has been set to run from #{dst.startDate.to_s} to #{dst.endDate.to_s}.")
      rescue
        runner.registerError("Invalid daylight saving date specified.")
        return false
      end
    else
      initial_dst_start_date = 'Not Applicible'
      final_dst_start_date = 'Not Applicible'
      initial_dst_end_date = 'Not Applicible'
      final_dst_end_date = 'Not Applicible'
      runner.registerInfo("Measure arguments specifcy that no daylight saving time will be set.")
    end


    
    # Report initial condition to the user
    runner.registerInitialCondition("Measure began with an initial weather file city of #{initial_weather_file_city}, #{initial_design_days_count} Design Day weather definitions, and daylight savings time starting at #{initial_dst_start_date} and ending at #{initial_dst_end_date}.")
    
    # Report final condition to the user
    runner.registerFinalCondition("The final climate zone is #{climate_zone}.Measure completed with a final weather file city of #{final_weather_file_city}, #{model.getDesignDays.length} Design Day weather definitions, and daylight savings time starting at #{final_dst_start_date} and ending at #{final_dst_end_date}.")
    return true

  end # end run method
  
end # end class 

# register the measure to be used by the application
ReplaceWeatherFile.new.registerWithApplication
