# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class AlterSimulationSettingsCandidateModel < OpenStudio::Ruleset::ModelUserScript

  def neat_numbers(number, roundto = 2) #round to 0 or 2)
   if roundto == 2
     number = sprintf "%.2f", number
   else
     number = number.round
   end
   #regex to add commas
   number.to_s.reverse.gsub(%r{([0-9]{3}(?=([0-9])))}, "\\1,").reverse
  end #end def neat_numbers

  # human readable name
  def name
    return "A11_Alter_Simulation_Settings_Candidate_Model"
  end

   # human readable description of measure
  def description
    return "lorum"
  end

  # human readable description of modeling approach
  def modeler_description
    return "ipsum"
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Ruleset::OSArgumentVector.new

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)  
  
  # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end
    
    model_setting = model.getSimulationControl
   
    ##---------------------------------------------------------------##
    ## begin logic block for determining model timestep 
    desired_timestep = 6
    timestep = model.getTimestep
    initial_timestep = timestep.numberOfTimestepsPerHour
    if initial_timestep == desired_timestep
      runner.registerInfo("Model Timestep not changed from original value of 6 steps per hour.")
    else
      model_setting.timestep.get.setNumberOfTimestepsPerHour(desired_timestep) 
      runner.registerInfo("Model Timestep changed from original value of #{initial_timestep} to #{desired_timestep} steps per hour.") 
    end
    ## end logic block for determining model timestep      
    ##---------------------------------------------------------------##

    ##---------------------------------------------------------------##
    ## begin logic block for determining solar_distribution_algorithm

    desired_solar_distribution_algorithm = "FullExterior"
    init_solar_distribution_algorithm = model_setting.solarDistribution
    if init_solar_distribution_algorithm == desired_solar_distribution_algorithm
      runner.registerInfo("Model Solar Distribution Algorithm not changed from original value Full Exterior.")
    else
      model_setting.setSolarDistribution(desired_solar_distribution_algorithm) 
      runner.registerInfo("Model Solar Distribution Algorithm changed from original value of #{init_solar_distribution_algorithm} to #{desired_solar_distribution_algorithm}.") 
    end
    # end logic block for setting solar distribution algorithm
    ##---------------------------------------------------------------##

    ##---------------------------------------------------------------##
    # begin logic block for setting determining model run period settings
    desired_begin_month = 1
    desired_begin_day_of_month = 1
    desired_end_month = 12
    desired_end_day_of_month = 31
    
    run_period = model.getRunPeriod
    
    initial_begin_month = run_period.getBeginMonth
    initial_begin_day_of_month = run_period.getBeginDayOfMonth 
    initial_end_month = run_period.getEndMonth
    initial_end_day_of_month = run_period.getEndDayOfMonth
      
    if initial_begin_month == desired_begin_month && initial_begin_day_of_month == desired_begin_day_of_month && initial_end_month == desired_end_month && initial_end_day_of_month == desired_end_day_of_month
      runner.registerInfo("Model Run Period settings match required Run Period settings. No changes were made to Run Period Settings.")        
    else
      run_period.setBeginMonth(desired_begin_month)
      run_period.setBeginDayOfMonth(desired_begin_day_of_month)
      run_period.setEndMonth(desired_end_month)
      run_period.setEndDayOfMonth(desired_end_day_of_month)
          
      runner.registerInfo("Model Run Period Begin Month setting changed from #{initial_begin_month} to #{desired_begin_month}.")
      runner.registerInfo("Model Run Period Begin Day Of Month setting changed from #{initial_begin_day_of_month} to #{desired_begin_day_of_month}.")
      runner.registerInfo("Model Run Period End Month setting changed from #{initial_end_month} to #{desired_end_month}.")
      runner.registerInfo("Model Run Period End Day Of Month setting changed from #{initial_end_day_of_month} to #{desired_end_day_of_month}.")                
    end 
    # end of logic block for setting model run period attributes     
    ##---------------------------------------------------------------##
 
    ##---------------------------------------------------------------##
    # begin logic block for setting model shadow calculation frequency      
    desired_calculation_frequency = 30
       
    shadow_setting = model.getShadowCalculation

    initial_calculation_frequency = shadow_setting.shadingCalculationUpdateFrequency
       
    if initial_calculation_frequency == desired_calculation_frequency
      runner.registerInfo("Model Shadow Calculation Frequency setting matches required Calculation Frequency setting of #{desired_calculation_frequency} days. No changes made to Shadow Calculation Frequency setting.")
    else
      shadow_setting.setShadingCalculationUpdateFrequency(desired_calculation_frequency)
      runner.registerInfo("Model Shadow Calculation Frequency setting changed from #{initial_calculation_frequency} days to #{desired_calculation_frequency} days to match required settings.")
    end
    # end of logic block for setting shadow calculation frequency attribute     
    ##---------------------------------------------------------------##
    
    ##---------------------------------------------------------------##
    # begin logic block for setting model heating and cooling time for setpoint not met.
    desired_htg_tolerance_ip = 2.0 # note specificd units are degrees F
    desired_clg_tolerance_ip = 2.0 # note specified units are degrees F
    
    desired_htg_tolerance_si = 2.0 / 1.8 # note 1.8 Deg F per Deg C
    desired_clg_tolerance_si = 2.0 / 1.8 # note 1.8 Deg F per Deg C
    
    
    tolerance = model.getOutputControlReportingTolerances
    initial_htg_tolerance_si = tolerance.toleranceforTimeHeatingSetpointNotMet
    initial_htg_tolerance_ip = initial_htg_tolerance_si * 1.8
    
    initial_clg_tolerance_si = tolerance.toleranceforTimeCoolingSetpointNotMet
    initial_clg_tolerance_ip = initial_clg_tolerance_si * 1.8
    
    if initial_htg_tolerance_si == desired_htg_tolerance_si
      runner.registerInfo("Model tolerance for time heating setpoint not met of #{neat_numbers(initial_htg_tolerance_ip,2)} Deg F equal to required value of #{desired_htg_tolerance_ip} Deg F. No changes made to tolerance for time heating setpint not met.")
    else
      tolerance.setToleranceforTimeHeatingSetpointNotMet(desired_htg_tolerance_si)
      runner.registerInfo("Model tolerance for time heating setpoint not met changed from #{neat_numbers(initial_htg_tolerance_ip,2)} Deg F to required value of #{desired_htg_tolerance_ip} Deg F.")
    end
    
    if initial_clg_tolerance_si == desired_clg_tolerance_si
      runner.registerInfo("Model tolerance for time heating setpoint not met of #{neat_numbers(initial_clg_tolerance_ip,2)} Deg F equal to required value of #{desired_clg_tolerance_ip} Deg F. No changes made to tolerance for time heating setpint not met.")
    else
      tolerance.setToleranceforTimeCoolingSetpointNotMet(desired_clg_tolerance_si)
      runner.registerInfo("Model tolerance for time cooling setpoint not met changed from #{neat_numbers(initial_clg_tolerance_ip,2)} Deg F to required value of #{desired_clg_tolerance_ip} Deg F.")
    end
  
  end # end run method
  
end # end class 

# register the measure to be used by the application
AlterSimulationSettingsCandidateModel.new.registerWithApplication
