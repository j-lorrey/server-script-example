

###### (Automatically generated documentation)

# GhSetMonthlyThermostatSetpoint

## Description
This measure parameterizes the greenhouse heating thermostat into monthly user arguments.  This includes logic for multiple user argument configurations.

## Modeler Description
This measure will clone all of the schedules that are used as heating and cooling setpoints for thermal zones. The clones are hooked up to the thermostat in place of the original schedules. Then the schedules are adjusted by the specified values. There is a checkbox to determine if the thermostat for design days should be altered.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose the Thermostat to alter

**Name:** setpoint_schedule_selection,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Degrees Fahrenheit to Adjust Cooling Setpoint By

**Name:** cooling_adjustment,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Degrees Fahrenheit to Adjust heating Setpoint By

**Name:** heating_adjustment,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Jan SP deg F

**Name:** jan_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Feb SP deg F

**Name:** feb_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Mar SP deg F

**Name:** mar_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Apr SP deg F

**Name:** apr_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### May SP deg F

**Name:** may_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Summer SP deg F

**Name:** sum_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Sept SP deg F

**Name:** sep_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Oct SP deg F

**Name:** oct_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Nov SP deg F

**Name:** nov_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Dec SP deg F

**Name:** dec_sp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Alter Design Day Thermostats

**Name:** alter_design_days,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false




