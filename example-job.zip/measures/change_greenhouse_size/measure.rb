# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class ChangeGreenhouseSize < OpenStudio::Ruleset::ModelUserScript

  ## helper methods ##
  
    def neat_numbers(number, roundto = 2) #round to 2 decimals
      if roundto == 2
        number = sprintf "%.2f", number
      else
        number = number.round
      end
      #regex to add commas
      number.to_s.reverse.gsub(%r{([0-9]{3}(?=([0-9])))}, "\\1,").reverse
    end #end def neat_numbers
  
    
    def change_zone_multiplier(zone_name, zone_multiplier, model, runner)
      obj_type = OpenStudio::Model::ThermalZone::iddObjectType
    zone = model.getObjectByTypeAndName(obj_type, zone_name).get.to_ThermalZone.get
    init_mult = zone.multiplier
    zone.setMultiplier(zone_multiplier)
    
    # write info message describing change to thermal zone multiplier 
    runner.registerInfo("The Thermal Zone multiplier for the zone named #{zone.name} has been set from #{init_mult} to #{zone_multiplier}.")
    end 
  
    ## end of helper methods ##
    
    
    # human readable name
    def name
      return "ChangeGreenhouseSize"
    end
  
    # human readable description
    def description
      return "Uses the same A02 scale framework but assumes that start is with 30' x 96' GH.  Pass the input footage numbers on through to the ruby measure and then do the math."
    end
  
    # human readable description of modeling approach
    def modeler_description
      return "ipsum"
    end
  
    # define the arguments that the user will input
    def arguments(model)
      args = OpenStudio::Ruleset::OSArgumentVector.new
      

      gh_width = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("gh_width", true)
      gh_width.setDisplayName("Greenhouse Width (aka hoop diameter) [ft]")
      gh_width.setDefaultValue(30)
      args << gh_width

      gh_length = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("gh_length", true)
      gh_length.setDisplayName("Greenhouse Length (aka long dim) [ft]")
      gh_length.setDefaultValue(96)
      args << gh_length
  
      # get default value for number of stories based on model
      default_stories = 1
      if not model.getBuilding.standardsBuildingType.empty?
        building_type = model.getBuilding.standardsBuildingType.get
      else
        puts "To run correctly, this measure requires that the Model have the optional 'Standards Building Type' object set. Please correct and re-run."
      end
      
      if building_type == "MidriseApartment"
        default_stories = 2
      elsif building_type == "SmallOffice" || building_type == "MediumOffice"
        default_stories = 1
      else 
        puts "To run correctly, this measure requires that the Model have the optional 'Standards Building Type' object set to either MidriseApartment, SmallOffice or MediumOffice. Please correct and re-run."
      end
      
      int_flr_flr_multiplier = OpenStudio::Ruleset::OSArgument.makeIntegerArgument("int_flr_flr_multiplier", true)
      int_flr_flr_multiplier.setDisplayName("Interior Floor Multiplier .")
      int_flr_flr_multiplier.setDescription("Scales all thermal zones associated with the interior floors of the prototype model. Only applicible to Medium Office or Midrise Apartment Prototypes.")
      int_flr_flr_multiplier.setDefaultValue(default_stories)
      args << int_flr_flr_multiplier
  
      return args
    end
  
    # define what happens when the measure is run
    def run(model, runner, user_arguments)
      super(model, runner, user_arguments)
  
      # use the built-in error checking
      if !runner.validateUserArguments(arguments(model), user_arguments)
        return false
      end
  
      # assign the user inputs to variables
      gh_width = runner.getDoubleArgumentValue("gh_width", user_arguments)
      gh_length = runner.getDoubleArgumentValue("gh_length", user_arguments) 
      int_flr_flr_multiplier = runner.getIntegerArgumentValue("int_flr_flr_multiplier", user_arguments)
    
    # hard code z_scale_factor = 1.0
      z_scale_factor = 1.0

      building = model.getBuilding
      building_area = building.floorArea

      # building_area_ft2 = OpenStudio.convert(building_area, 'm^2', 'ft^2').get
      
      # x_scale_factor_inv = Math.sqrt(building_area_ft2/sqrFootage)
      # y_scale_factor_inv = Math.sqrt(building_area_ft2/sqrFootage)

      # x_scale_factor = 1 / x_scale_factor_inv
      # y_scale_factor = 1 / y_scale_factor_inv

      x_scale_factor = gh_width / 30 # default greenhouse in the Load OS Model measure is 30ft wide
      y_scale_factor = gh_length / 144 # default greenhouse in the Load OS Model measure is 144ft long

      puts(x_scale_factor)
      
    
      # arguments for triggering errors or warnings 
      if x_scale_factor <= 0.05
      runner.registerError("X Scale Factor of #{x_scale_factor} is less then the Error limit of 0.05.")
      return false
    end
  
      if x_scale_factor >= 2.0
      runner.registerError("X Scale Factor of #{x_scale_factor} is greater then the Error limit of 2.0.")
      return false
    end
    
      if x_scale_factor <= 0.25
      runner.registerWarning("X Scale Factor of #{x_scale_factor} is less then the suggested Warning limit of 0.25. This may result in intersecting geometry.")
    end
  
      if x_scale_factor >= 1.6
      runner.registerWarning("X Scale Factor of #{x_scale_factor} is greater then the suggested Warning limit of 1.6. This may result in intersecting geometry.")
    end
    
      if y_scale_factor <= 0.05
      runner.registerError("Y Scale Factor of #{y_scale_factor} is less then the Error limit of 0.05.")
      return false
    end
  
      if y_scale_factor >= 3.0
      runner.registerError("Y Scale Factor of #{y_scale_factor} is greater then the Error limit of 3.0.")
      return false
    end
    
      if y_scale_factor <= 0.25
      runner.registerWarning("Y Scale Factor of #{y_scale_factor} is less then the suggested Warning limit of 0.25. This may result in intersecting geometry.")
    end
  
      if y_scale_factor >= 2.6
      runner.registerWarning("Y Scale Factor of #{y_scale_factor} is greater then the suggested Warning limit of 2.6. This may result in intersecting geometry.")
    end
  
      if int_flr_flr_multiplier < 1
      runner.registerError("Internal Floor multipler argument value of #{int_flr_flr_multiplier} is less then the Error limit of 1.")
      return false
    end
  
      if int_flr_flr_multiplier >= 10
      runner.registerError("Y Scale Factor of #{int_flr_flr_multiplier} is greater then the Error limit of 10.")
      return false
    end
  
      building_type = model.getBuilding.standardsBuildingType.get	
      runner.registerInfo("The StandardsBuildingType attribute associated with this model = #{building_type}.")
      
      # report not applicable message if small office initial condition of model
    if building_type == "SmallOffice" 
      runner.registerAsNotApplicable("The current model has a standardsBuildingType attribute = #{building_type} which is not eligible for assigning thermal Zone multipliers to.")
    end 
      
      # report initial condition of model
    runner.registerInitialCondition("The #{building_type} building started with a floor area of #{neat_numbers(OpenStudio.convert(model.getBuilding.floorArea, "m^2", "ft^2").get,0)} ft^2.")
  
    # retrieves all (apaces, shading surface groups and interior partition surface groups) in the model and modifies the origin 
      model.getPlanarSurfaceGroups.each do |group|
        group.setXOrigin(x_scale_factor * group.xOrigin)
        group.setYOrigin(y_scale_factor * group.yOrigin)
        group.setZOrigin(z_scale_factor * group.zOrigin)
      end
    
    # retrieves all (Interior Partition Surfaces, Shading Surfaces, Subsurfaces ans Surfaces) in the model and modify the existing x,y,z verticies by the user-defined scale factor 
      model.getPlanarSurfaces.each do |surface|
        vertices = surface.vertices
        new_vertices = OpenStudio::Point3dVector.new
        vertices.each do |vertex|
          new_vertices << OpenStudio::Point3d.new(x_scale_factor * vertex.x, y_scale_factor * vertex.y, z_scale_factor * vertex.z)
        end
        surface.setVertices(new_vertices)
      end
  
    # retrieve all daylighting controls in the model and modify the existing x,y,z verticies by the user-defined scale factors
      model.getDaylightingControls.each do |control|
        control.setPositionXCoordinate(x_scale_factor * control.positionXCoordinate)
        control.setPositionYCoordinate(y_scale_factor * control.positionYCoordinate)
        control.setPositionZCoordinate(z_scale_factor * control.positionZCoordinate)
      end
    
    # retrieve all glare sensors in the model and modify the existing x,y,z sensor position by the user-defined scale factors
      model.getGlareSensors.each do |sensor|
        sensor.setPositionXCoordinate(x_scale_factor * sensor.positionXCoordinate)
        sensor.setPositionYCoordinate(y_scale_factor * sensor.positionYCoordinate)
        sensor.setPositionZCoordinate(z_scale_factor * sensor.positionZCoordinate)
      end
      
    # retrieve all glare sensors in the model and modify the existing x,y,z origin position by the user-defined scale factors
      model.getGlareSensors.each do |map|
        map.setOriginXCoordinate(x_scale_factor * map.originXCoordinate)
        map.setOriginYCoordinate(y_scale_factor * map.originYCoordinate)
        map.setXLength(x_scale_factor * map.xLength)
        map.setYLength(y_scale_factor * map.yLength)
      end
  
    # report changes made by measure
    runner.registerInfo("An X-scale factor of #{x_scale_factor} was applied to the model geometry, including modifying any daylight control and glare sensor locations.")
    runner.registerInfo("An Y-scale factor of #{y_scale_factor} was applied to the model geometry, including modifying any daylight control and glare sensor locations.")
    
    # check for specific cases to apply thermal zone multipliers to. Can be extended as additional prototype models are supported.
    building_story = []
    multi = "Building Story 2"
    spaces = model.getSpaces
    #Loop through each space and grab building story
    spaces.each do |space|
      building_story_temp = space.buildingStory
      if !building_story_temp.empty?
        building_story_temp = building_story_temp.get
        building_story << building_story_temp.name.to_s   
        #puts building_story_temp.name.to_s  
      end
    end
    
    building_story = building_story.uniq
  
    if building_story.size <= 2
      puts "Cannot multiply a building with only 2 stories"
    elsif building_story.size > 2
      spaces.each do |space|
        building_story_temp = space.buildingStory
        if !building_story_temp.empty?
          building_story_temp = building_story_temp.get
          if building_story_temp.name.to_s == "Building Story 2"
            zone_temp = space.thermalZone
            if !zone_temp.empty?
              zone_temp = zone_temp.get
            end
            zone_temp = zone_temp.name.to_s
            puts "Multiplying : "+zone_temp
            change_zone_multiplier(zone_temp, int_flr_flr_multiplier, model, runner)
          else
          end  
        end
      end 
      
    end  
    
    #previous logic to function call change zone multiplyer
    
      # if building_type == "MediumOffice" 
      # change_zone_multiplier("MidFloor_Plenum ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("Core_mid ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("Perimeter_mid_ZN_1 ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("Perimeter_mid_ZN_2 ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("Perimeter_mid_ZN_3 ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("Perimeter_mid_ZN_4 ZN", int_flr_flr_multiplier, model, runner)
      # elsif building_type == "MidriseApartment"  
      # change_zone_multiplier("M Corridor ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("M N1 Apartment ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("M N2 Apartment ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("M NE Apartment ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("M NW Apartment ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("M S1 Apartment ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("M S2 Apartment ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("M SE Apartment ZN", int_flr_flr_multiplier, model, runner)
      # change_zone_multiplier("M SW Apartment ZN", int_flr_flr_multiplier, model, runner)
      # elsif building_type == "Small Office"  
      #   if int_flr_flr_multiplier != 1
      #     runner.registerWarning("The single story building type of 'Small Office' does not contain any mid-level thermal zones. Therefore, this measure will not alter ANY thermal zone geometry by changing thermal zone multipliers.")
      #   end 
      # end 
        
      # report final condition of model
      runner.registerFinalCondition("The #{building_type} building finished with a floor area of #{neat_numbers(OpenStudio.convert(model.getBuilding.floorArea, "m^2", "ft^2").get,0)} ft^2.")
      return true
  
    end # end run method
    
  end # end class 
    
  # register the measure to be used by the application
  ChangeGreenhouseSize.new.registerWithApplication
  