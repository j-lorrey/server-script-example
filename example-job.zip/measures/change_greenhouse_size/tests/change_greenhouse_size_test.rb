require 'C:\openstudio-2.2.0\pat\ruby\lib\ruby\site_ruby\openstudio.rb'
require 'openstudio'
require 'openstudio/ruleset/ShowRunnerOutput'
require 'minitest/autorun'
require_relative '../measure.rb'
require 'fileutils'

class ChangeGreenhouseSize_Test < MiniTest::Unit::TestCase

  # def setup
  # end

  # def teardown
  # end

  def test_number_of_arguments_and_argument_names
    # create an instance of the measure
    measure = ChangeGreenhouseSize.new

    # create an instance of a runner
    runner = OpenStudio::Ruleset::OSRunner.new
    
    # make an empty model
    model = OpenStudio::Model::Model.new

    # get arguments and test that they are what we are expecting
    arguments = measure.arguments(model)
    
    assert_equal(3, arguments.size)
    assert_equal("x_scale_factor", arguments[0].name)
    assert_equal("y_scale_factor", arguments[1].name)
    assert_equal("int_flr_flr_multiplier", arguments[2].name)
    
    
    
  end

  def test_bad_argument_values
    # create an instance of the measure
    measure = ChangeGreenhouseSize.new

    # create an instance of a runner
    runner = OpenStudio::Ruleset::OSRunner.new

    # make an empty model
    model = OpenStudio::Model::Model.new

    # get arguments
    arguments = measure.arguments(model)
    argument_map = OpenStudio::Ruleset.convertOSArgumentVectorToMap(arguments)

    # create hash of argument values
    args_hash = {}
    args_hash["x_scale_factor"] = 2.2
    args_hash["y_scale_factor"] = 0.9
    args_hash["int_flr_flr_multiplier"] = 2

    # populate argument with specified hash value if specified
    arguments.each do |arg|
      temp_arg_var = arg.clone
      if args_hash.has_key?(arg.name)
        assert(temp_arg_var.setValue(args_hash[arg.name]))
      end
      argument_map[arg.name] = temp_arg_var
    end

    # run the measure
    measure.run(model, runner, argument_map)
    result = runner.result

    # show the output
    show_output(result)

    # assert that it ran correctly
    assert_equal("Fail", result.value.valueName)
  end

  def scale_positive_area_no_flr_multiplier
    # create an instance of the measure
    measure = ChangeGreenhouseSize.new

    # create an instance of a runner
    runner = OpenStudio::Ruleset::OSRunner.new

    # load the test model
    translator = OpenStudio::OSVersion::VersionTranslator.new
    path = OpenStudio::Path.new(File.dirname(__FILE__) + "/med_ofc_2013_6a.osm")
    model = translator.loadModel(path)
    assert((not model.empty?))
    model = model.get

    # store the original floor area
    original_floor_area = model.getBuilding.floorArea

    # get arguments
    arguments = measure.arguments(model)
    argument_map = OpenStudio::Ruleset.convertOSArgumentVectorToMap(arguments)

    # create hash of argument values.
    # If the argument has a default that you want to use, you don't need it in the hash
    args_hash = {}
    args_hash["x_scale_factor"] = 1.2
    args_hash["y_scale_factor"] = 1.2
    args_hash["int_flr_flr_multiplier"] = 1

    # populate argument with specified hash value if specified
    arguments.each do |arg|
      temp_arg_var = arg.clone
      if args_hash.has_key?(arg.name)
        assert(temp_arg_var.setValue(args_hash[arg.name]))
      end
      argument_map[arg.name] = temp_arg_var
    end

    # run the measure
    measure.run(model, runner, argument_map)
    result = runner.result

    # show the output
    show_output(result)

    # assert that it ran correctly
    assert_equal("Success", result.value.valueName)
    assert(result.info.size == 2)
    assert(result.warnings.size == 0)

    # check resulting floor area vs original floor area
    assert_in_epsilon(77224.0, original_floor_area, 0.1) 
   
    # save the model to test output directory
    output_file_path = OpenStudio::Path.new(File.dirname(__FILE__) + "/output/test_output.osm")
    model.save(output_file_path,true)
  end
  
  def no_scale_area_check_flr_multiplier
    # create an instance of the measure
    measure = ChangeGreenhouseSize.new

    # create an instance of a runner
    runner = OpenStudio::Ruleset::OSRunner.new

    # load the test model
    translator = OpenStudio::OSVersion::VersionTranslator.new
    path = OpenStudio::Path.new(File.dirname(__FILE__) + "/med_ofc_2013_6a.osm")
    model = translator.loadModel(path)
    assert((not model.empty?))
    model = model.get

    # store the original floor area
    original_floor_area = model.getBuilding.floorArea
    
    # check original floor area 
    assert_in_epsilon(53628, original_floor_area, 0.1) 
    
    # get arguments
    arguments = measure.arguments(model)
    argument_map = OpenStudio::Ruleset.convertOSArgumentVectorToMap(arguments)

    # create hash of argument values.
    # If the argument has a default that you want to use, you don't need it in the hash
    args_hash = {}
    args_hash["x_scale_factor"] = 1.0
    args_hash["y_scale_factor"] = 1.0
    args_hash["int_flr_flr_multiplier"] = 3

    # populate argument with specified hash value if specified
    arguments.each do |arg|
      temp_arg_var = arg.clone
      if args_hash.has_key?(arg.name)
        assert(temp_arg_var.setValue(args_hash[arg.name]))
      end
      argument_map[arg.name] = temp_arg_var
    end

    # run the measure
    measure.run(model, runner, argument_map)
    result = runner.result

    # store the new floor area
    new_floor_area = model.getBuilding.floorArea
    
    # show the output
    show_output(result)

    # assert that it ran correctly
    assert_equal("Success", result.value.valueName)
    assert(result.info.size == 2)
    assert(result.warnings.size == 0)

    # check resulting floor area vs original floor area
    assert_in_epsilon(89380, new_floor_area, 0.1) 
   
    # save the model to test output directory
    output_file_path = OpenStudio::Path.new(File.dirname(__FILE__) + "/output/test_output.osm")
    model.save(output_file_path,true)
  end
  
  
  
end
