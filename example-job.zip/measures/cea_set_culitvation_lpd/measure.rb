# *******************************************************************************
# OpenStudio(R), Copyright (c) 2008-2018, Alliance for Sustainable Energy, LLC.
# All rights reserved.
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# (1) Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# (2) Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# (3) Neither the name of the copyright holder nor the names of any contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission from the respective party.
#
# (4) Other than as required in clauses (1) and (2), distributions in any form
# of modifications or other derivative works may not use the "OpenStudio"
# trademark, "OS", "os", or any other confusingly similar designation without
# specific prior written permission from Alliance for Sustainable Energy, LLC.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER(S) AND ANY CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER(S), ANY CONTRIBUTORS, THE
# UNITED STATES GOVERNMENT, OR THE UNITED STATES DEPARTMENT OF ENERGY, NOR ANY OF
# THEIR EMPLOYEES, BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# *******************************************************************************

# start the measure
class CeaSetCulitvationLpd < OpenStudio::Measure::ModelMeasure
  # define the name that a user will see
  def name
    return "cea_set_culitvation_lpd"
  end

  # human readable description
  def description
    return "Set the lighting power density (W/ft^2) in the to a specified value for the space named cultivation"
  end

  # human readable description of modeling approach
  def modeler_description
    return "Adjusts the default space type LPDs that are set upstream by create typical and overlays a cultivation specific LPD in only the cultivation space."
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # make a choice argument for model objects
    space_handles = OpenStudio::StringVector.new
    space_display_names = OpenStudio::StringVector.new

    # putting model object and names into hash
    space_args = model.getSpaces
    space_args_hash = {}
    space_args.each do |space_arg|
      space_args_hash[space_arg.name.to_s] = space_arg
    end

    # looping through sorted hash of model objects
    space_args_hash.sort.map do |key, value|
      space_handles << value.handle.to_s
      space_display_names << key
    end

    # make a choice argument for space type or entire building
    veg_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('veg_space', space_handles, space_display_names, true)
    veg_space.setDisplayName('Choose a veg space')
    args << veg_space
    flower_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('flower_space', space_handles, space_display_names, true)
    flower_space.setDisplayName('Choose a flower space')
    args << flower_space


    # make an argument LPD
    veg_lpd = OpenStudio::Measure::OSArgument.makeDoubleArgument('veg_lpd', true)
    veg_lpd.setDisplayName('Veg Lighting Power Density (W/ft^2)')
    veg_lpd.setDefaultValue(1.0)
    args << veg_lpd
    flower_lpd = OpenStudio::Measure::OSArgument.makeDoubleArgument('flower_lpd', true)
    flower_lpd.setDisplayName('Flower Lighting Power Density (W/ft^2)')
    flower_lpd.setDefaultValue(1.0)
    args << flower_lpd

    # Adding in the septoint schedule selection criteria to streamline measure
    setpoint_schedules = OpenStudio::StringVector.new
    setpoint_schedules_handles = OpenStudio::StringVector.new

    setpoint_schedules_args = model.getScheduleRulesets
    setpoint_schedules_args_hash = {}
    setpoint_schedules_args.each do |setpoint_schedules_arg|
      setpoint_schedules_args_hash[setpoint_schedules_arg.name.to_s] = setpoint_schedules_arg
    end
    # Loop through the hash to pull out the hash and name value to align display name and hash value
    setpoint_schedules_args_hash.sort.map do |key, value|
      setpoint_schedules_handles << value.handle.to_s
      setpoint_schedules << key
    end

    veg_lighting_schedule = OpenStudio::Measure::OSArgument::makeChoiceArgument('veg_lighting_schedule',setpoint_schedules_handles,setpoint_schedules,true)
    veg_lighting_schedule.setDisplayName('Choose the Vegetative Cycle Lighting Schedule')
    args << veg_lighting_schedule
    flower_lighting_schedule = OpenStudio::Measure::OSArgument::makeChoiceArgument('flower_lighting_schedule',setpoint_schedules_handles,setpoint_schedules,true)
    flower_lighting_schedule.setDisplayName('Choose the Flower Cylce Lighting Schedule')
    args << flower_lighting_schedule

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    veg_space = runner.getOptionalWorkspaceObjectChoiceValue('veg_space', user_arguments, model)
    flower_space = runner.getOptionalWorkspaceObjectChoiceValue('flower_space', user_arguments, model)

    veg_space = veg_space.get.to_Space.get
    flower_space = flower_space.get.to_Space.get


    veg_lpd = runner.getDoubleArgumentValue('veg_lpd', user_arguments)
    flower_lpd = runner.getDoubleArgumentValue('flower_lpd', user_arguments)

    # setup OpenStudio units that we will need
    unit_lpd_ip = OpenStudio.createUnit('W/ft^2').get
    unit_lpd_si = OpenStudio.createUnit('W/m^2').get
    
    # define starting units
    veg_lpd_ip = OpenStudio::Quantity.new(veg_lpd, unit_lpd_ip)
    flower_lpd_ip = OpenStudio::Quantity.new(flower_lpd, unit_lpd_ip)
    
    # unit conversion of lpd from IP units (W/ft^2) to SI units (W/m^2)
    veg_lpd_si = OpenStudio.convert(veg_lpd_ip, unit_lpd_si).get
    flower_lpd_si = OpenStudio.convert(flower_lpd_ip, unit_lpd_si).get

    puts "user entered lpd"
    puts veg_lpd
    puts "assumed in Watts/sqft"

    puts "converted to:"
    puts veg_lpd_si
    puts "W/m^2"

    

    # passing the model object as well to the run method to pull the actual schedule object
    flower_lighting_schedule = runner.getOptionalWorkspaceObjectChoiceValue('flower_lighting_schedule',user_arguments, model)
    flower_lighting_schedule = flower_lighting_schedule.get.to_ScheduleRuleset.get

    veg_lighting_schedule = runner.getOptionalWorkspaceObjectChoiceValue('veg_lighting_schedule',user_arguments, model)
    veg_lighting_schedule = veg_lighting_schedule.get.to_ScheduleRuleset.get


    # TODO
    #remove old light defs
    # space_type_lights = space_type.lights
    # space_type_lights.each(&:remove)

    # Make a new light definition
    veg_light_def = OpenStudio::Model::LightsDefinition.new(model)
    veg_light_def.setName("Horticulture Lighting #{veg_lpd_ip} - LightsDef")
    veg_light_def.setWattsperSpaceFloorArea(veg_lpd_si.value)
    # with logic for radiant to space
    if veg_lpd < 50.0
      veg_light_def.setFractionRadiant(0.10)
    else
      veg_light_def.setFractionRadiant(0.40)
    end

    veg_light_inst = OpenStudio::Model::Lights.new(veg_light_def)
    veg_light_inst.setName("LPD #{veg_lpd_ip} - LightsInstance")
    veg_light_inst.setSchedule(veg_lighting_schedule)

    puts veg_light_inst

    space_type_light_new = veg_light_inst.clone(model)
    space_type_light_new = space_type_light_new.to_Lights.get
    space_type_light_new.setSpace(veg_space)
    space_type_light_new.setSchedule(veg_lighting_schedule)

    # Make a new light definition
    flower_light_def = OpenStudio::Model::LightsDefinition.new(model)
    flower_light_def.setName("Horticulture Lighting #{flower_lpd_ip} - LightsDef")
    flower_light_def.setWattsperSpaceFloorArea(flower_lpd_si.value)
    # with logic for radiant to space
    if flower_lpd < 50.0
      flower_light_def.setFractionRadiant(0.10)
    else
      flower_light_def.setFractionRadiant(0.4)
    end


    flower_light_inst = OpenStudio::Model::Lights.new(flower_light_def)
    flower_light_inst.setName("LPD #{flower_lpd_ip} - LightsInstance")
    flower_light_inst.setSchedule(flower_lighting_schedule)

    puts flower_light_inst

    space_type_light_new = flower_light_inst.clone(model)
    space_type_light_new = space_type_light_new.to_Lights.get
    space_type_light_new.setSpace(flower_space)
    space_type_light_new.setSchedule(flower_lighting_schedule)

    return true
  end
end

# this allows the measure to be used by the application
CeaSetCulitvationLpd.new.registerWithApplication
