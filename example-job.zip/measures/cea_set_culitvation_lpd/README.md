

###### (Automatically generated documentation)

# cea_set_culitvation_lpd

## Description
Set the lighting power density (W/ft^2) in the to a specified value for the space named cultivation

## Modeler Description
Adjusts the default space type LPDs that are set upstream by create typical and overlays a cultivation specific LPD in only the cultivation space.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose a veg space

**Name:** veg_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false


**Choice Display Names** []



### Choose a flower space

**Name:** flower_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false


**Choice Display Names** []



### Veg Lighting Power Density (W/ft^2)

**Name:** veg_lpd,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




### Flower Lighting Power Density (W/ft^2)

**Name:** flower_lpd,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




### Choose the Vegetative Cycle Lighting Schedule

**Name:** veg_lighting_schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false


**Choice Display Names** []



### Choose the Flower Cylce Lighting Schedule

**Name:** flower_lighting_schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false


**Choice Display Names** []






