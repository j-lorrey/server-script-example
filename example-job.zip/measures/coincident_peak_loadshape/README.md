

###### (Automatically generated documentation)

# Coincident Peak Loadshape

## Description


## Modeler Description


## Measure Type
EnergyPlusMeasure

## Taxonomy


## Arguments


### Select a Tariff for ElectricityPurchased:Facility.

**Name:** ElectricityPurchased:Facility,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false




