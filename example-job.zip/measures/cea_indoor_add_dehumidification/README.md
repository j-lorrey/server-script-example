

###### (Automatically generated documentation)

# cea_indoor_add_dehumidification

## Description
add humidifying/dehumidifying schedules and expose RH percent value for editing

## Modeler Description
Use resources loaded in the seed model and assign to ThermalZone.
Add new new Humidistat > assign schedules > edit schedules 

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose a veg space

**Name:** veg_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose a flower space

**Name:** flower_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose the dehumidity schedule

**Name:** dehumid_sched,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Enter the Dehumid %RH setpoint

**Name:** dehumid_rh_setpoint,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




