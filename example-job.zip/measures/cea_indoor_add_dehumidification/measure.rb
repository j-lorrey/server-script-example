# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CeaIndoorAddDehumidification < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'cea_indoor_add_dehumidification'
  end

  # human readable description
  def description
    return 'add humidifying/dehumidifying schedules and expose RH percent value for editing'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Use resources loaded in the seed model and assign to ThermalZone.
Add new new Humidistat > assign schedules > edit schedules '
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # make a choice argument for model objects
    space_handles = OpenStudio::StringVector.new
    space_display_names = OpenStudio::StringVector.new

    # putting model object and names into hash
    space_args = model.getSpaces
    space_args_hash = {}
    space_args.each do |space_arg|
      space_args_hash[space_arg.name.to_s] = space_arg
    end

    # looping through sorted hash of model objects
    space_args_hash.sort.map do |key, value|
      space_handles << value.handle.to_s
      space_display_names << key
    end

    # make a choice argument for veg_space type or entire building
    veg_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('veg_space', space_handles, space_display_names, true)
    veg_space.setDisplayName('Choose a veg space')
    args << veg_space
    flower_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('flower_space', space_handles, space_display_names, true)
    flower_space.setDisplayName('Choose a flower space')
    args << flower_space

    # loop to find the schedule names in the model
    sched_display_names = OpenStudio::StringVector.new
    sched_handles = OpenStudio::StringVector.new
    #get (loop) to find the exsiting schedule names
    sched_names_args = model.getScheduleRulesets
    sched_names_args_hash = {}
    sched_names_args.each do |sched_names_arg|
      sched_names_args_hash[sched_names_arg.name.to_s] = sched_names_arg
    end
    # Loop through the hash to pull out the hash and name value to align display name and hash value
    sched_names_args_hash.sort.map do |key, value|
      sched_handles << value.handle.to_s
      sched_display_names << key
    end

    dehumid_sched = OpenStudio::Ruleset::OSArgument::makeChoiceArgument('dehumid_sched', sched_handles, sched_display_names, true)
    dehumid_sched.setDisplayName('Choose the dehumidity schedule')
    args << dehumid_sched

    dehumid_rh_setpoint = OpenStudio::Measure::OSArgument.makeDoubleArgument('dehumid_rh_setpoint', true)
    dehumid_rh_setpoint.setDisplayName('Enter the Dehumid %RH setpoint')
    dehumid_rh_setpoint.setDefaultValue(50)
    args << dehumid_rh_setpoint

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    veg_space = runner.getOptionalWorkspaceObjectChoiceValue('veg_space', user_arguments, model)
    flower_space = runner.getOptionalWorkspaceObjectChoiceValue('flower_space', user_arguments, model)

    # assign the user inputs to variables
      #cast object from the model to_ObjectType within this workspace
    veg_space = veg_space.get.to_Space.get
    veg_thermal_zone = veg_space.thermalZone.get
    flower_space = flower_space.get.to_Space.get
    flower_thermal_zone = flower_space.thermalZone.get

    dehumid_sched = runner.getOptionalWorkspaceObjectChoiceValue('dehumid_sched', user_arguments, model)
    dehumid_rh_setpoint = runner.getDoubleArgumentValue('dehumid_rh_setpoint', user_arguments)
    dehumid_sched = dehumid_sched.get.to_ScheduleRuleset.get


    puts dehumid_sched

    day_sched = dehumid_sched.defaultDaySchedule

    puts day_sched

    day_value_vector = day_sched.values
    day_time_vector = day_sched.times

    for i in 0..(day_time_vector.size-1)
      day_sched.addValue(day_time_vector[i], dehumid_rh_setpoint)
    end

    puts "new day_sched"
    puts day_sched
    
    new_humidistat = OpenStudio::Model::ZoneControlHumidistat.new(model)
    new_humidistat.setName("Horticulture-Humidistat")
    new_humidistat.setDehumidifyingRelativeHumiditySetpointSchedule(dehumid_sched)

    scheds = model.getScheduleRulesets
    scheds.each do |sched|
      if sched.name.get.match("Horticulture_HumidSchedule_RHpercent")
        puts "hum_sched"
        puts sched
        new_humidistat.setHumidifyingRelativeHumiditySetpointSchedule(sched)
      end
    end



    puts new_humidistat

    puts "*************************************** zone *******************************"
    puts veg_thermal_zone
    puts flower_thermal_zone

    veg_thermal_zone.setZoneControlHumidistat(new_humidistat)
    flower_thermal_zone.setZoneControlHumidistat(new_humidistat)

    puts "after edit"
    puts veg_thermal_zone
    puts flower_thermal_zone

    return true
  end
end

# register the measure to be used by the application
CeaIndoorAddDehumidification.new.registerWithApplication
