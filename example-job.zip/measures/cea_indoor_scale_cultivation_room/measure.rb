# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CEAIndoorScaleCultivationRoom < OpenStudio::Ruleset::ModelUserScript

  ## helper methods ##
  
    def neat_numbers(number, roundto = 2) #round to 2 decimals
      if roundto == 2
        number = sprintf "%.2f", number
      else
        number = number.round
      end
      #regex to add commas
      number.to_s.reverse.gsub(%r{([0-9]{3}(?=([0-9])))}, "\\1,").reverse
    end #end def neat_numbers
  
    
    def change_zone_multiplier(zone_name, zone_multiplier, model, runner)
      obj_type = OpenStudio::Model::ThermalZone::iddObjectType
    zone = model.getObjectByTypeAndName(obj_type, zone_name).get.to_ThermalZone.get
    init_mult = zone.multiplier
    zone.setMultiplier(zone_multiplier)
    
    # write info message describing change to thermal zone multiplier 
    runner.registerInfo("The Thermal Zone multiplier for the zone named #{zone.name} has been set from #{init_mult} to #{zone_multiplier}.")
    end 
  
    ## end of helper methods ##
    
    
    # human readable name
    def name
      return "CEAIndoor_ScaleCultivationRoom"
    end
  
    # human readable description
    def description
      return "Measure uses a space name to scale the surfaces associate only with that space."
    end
  
    # human readable description of modeling approach
    def modeler_description
      return "Measure scales a user specified space exterior surfaces"
    end
  
    # define the arguments that the user will input
    def arguments(model)
      args = OpenStudio::Ruleset::OSArgumentVector.new
    
      # make a choice argument for model objects
      space_handles = OpenStudio::StringVector.new
      space_display_names = OpenStudio::StringVector.new

      # putting model object and names into hash
      space_args = model.getSpaces
      space_args_hash = {}
      space_args.each do |space_arg|
        space_args_hash[space_arg.name.to_s] = space_arg
      end

      # looping through sorted hash of model objects
      space_args_hash.sort.map do |key, value|
        space_handles << value.handle.to_s
        space_display_names << key
      end

      # make a choice argument for veg_space type or entire building
      veg_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('veg_space', space_handles, space_display_names, true)
      veg_space.setDisplayName('Choose a veg space')
      args << veg_space
      flower_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('flower_space', space_handles, space_display_names, true)
      flower_space.setDisplayName('Choose a flower space')
      args << flower_space

      veg_size_sqft = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("veg_size_sqft", true)
      veg_size_sqft.setDisplayName("veg room Size [sqft]")
      veg_size_sqft.setDefaultValue(1600)
      args << veg_size_sqft

      flower_size_sqft = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("flower_size_sqft", true)
      flower_size_sqft.setDisplayName("flower room Size [sqft]")
      flower_size_sqft.setDefaultValue(1600)
      args << flower_size_sqft

      return args
    end
  
    # define what happens when the measure is run
    def run(model, runner, user_arguments)
      super(model, runner, user_arguments)
  
      # use the built-in error checking
      if !runner.validateUserArguments(arguments(model), user_arguments)
        return false
      end
  
      # assign the user inputs to variables
      veg_size_sqft = runner.getDoubleArgumentValue("veg_size_sqft", user_arguments)
      flower_size_sqft = runner.getDoubleArgumentValue("flower_size_sqft", user_arguments)
      veg_space = runner.getOptionalWorkspaceObjectChoiceValue('veg_space', user_arguments, model)
      flower_space = runner.getOptionalWorkspaceObjectChoiceValue('flower_space', user_arguments, model)

      # cast the object from a hash to a extensible SpaceType object within this model (to_SpaceType.get)
      # once this is complete the object can be acted upon or referenced and connected by other objects within this working model space
      veg_space = veg_space.get.to_Space.get
      flower_space = flower_space.get.to_Space.get
    
    # hard code z_scale_factor = 1.0
      z_scale_factor = 1.0

      # building = model.getBuilding
      # building_area = building.floorArea

      veg_orig_cultivation_size = veg_space.floorArea

      puts "veg_orig_cultivation_size"
      puts veg_orig_cultivation_size


      unit_area_si = OpenStudio.createUnit('m^2').get
      unit_area_ip = OpenStudio.createUnit('ft^2').get

      veg_orig_area_si = OpenStudio::Quantity.new(veg_orig_cultivation_size, unit_area_si)
      veg_orig_area_ip = OpenStudio.convert(veg_orig_area_si, unit_area_ip).get

      puts "in IP"
      puts veg_orig_area_ip

      percentage_adjustment = veg_size_sqft / veg_orig_area_ip.value

      x_scale_factor = Math.sqrt(percentage_adjustment)
      y_scale_factor = Math.sqrt(percentage_adjustment)

      puts(x_scale_factor)
      puts(y_scale_factor)

      # building_area_ft2 = OpenStudio.convert(building_area, 'm^2', 'ft^2').get
      
      # x_scale_factor_inv = Math.sqrt(building_area_ft2/sqrFootage)
      # y_scale_factor_inv = Math.sqrt(building_area_ft2/sqrFootage)

      # x_scale_factor = 1 / x_scale_factor_inv
      # y_scale_factor = 1 / y_scale_factor_inv

    # # retrieves all (apaces, shading surface groups and interior partition surface groups) in the model and modifies the origin 
    #   model.getPlanarSurfaceGroups.each do |group|
    #     group.setXOrigin(x_scale_factor * group.xOrigin)
    #     group.setYOrigin(y_scale_factor * group.yOrigin)
    #     group.setZOrigin(z_scale_factor * group.zOrigin)
    #   end
    
    # retrieves all (Interior Partition Surfaces, Shading Surfaces, Subsurfaces ans Surfaces) in the user_specified_space and modifies the existing x,y,z verticies by the user-defined scale factor 
      veg_space.surfaces.each do |surface|
        vertices = surface.vertices
        new_vertices = OpenStudio::Point3dVector.new
        vertices.each do |vertex|
          new_vertices << OpenStudio::Point3d.new(x_scale_factor * vertex.x, y_scale_factor * vertex.y, z_scale_factor * vertex.z)
        end
        surface.setVertices(new_vertices)
      end
  
      veg_new_floor_area = veg_space.floorArea

      puts "veg_new_floor_area"
      puts veg_new_floor_area

      flower_orig_cultivation_size = flower_space.floorArea

      puts "flower_orig_cultivation_size"
      puts flower_orig_cultivation_size


      unit_area_si = OpenStudio.createUnit('m^2').get
      unit_area_ip = OpenStudio.createUnit('ft^2').get

      flower_orig_area_si = OpenStudio::Quantity.new(flower_orig_cultivation_size, unit_area_si)
      flower_orig_area_ip = OpenStudio.convert(flower_orig_area_si, unit_area_ip).get

      puts "in IP"
      puts flower_orig_area_ip

      percentage_adjustment = flower_size_sqft / flower_orig_area_ip.value

      x_scale_factor = Math.sqrt(percentage_adjustment)
      y_scale_factor = Math.sqrt(percentage_adjustment)

      puts(x_scale_factor)
      puts(y_scale_factor)

      # building_area_ft2 = OpenStudio.convert(building_area, 'm^2', 'ft^2').get
      
      # x_scale_factor_inv = Math.sqrt(building_area_ft2/sqrFootage)
      # y_scale_factor_inv = Math.sqrt(building_area_ft2/sqrFootage)

      # x_scale_factor = 1 / x_scale_factor_inv
      # y_scale_factor = 1 / y_scale_factor_inv

    # # retrieves all (apaces, shading surface groups and interior partition surface groups) in the model and modifies the origin 
    #   model.getPlanarSurfaceGroups.each do |group|
    #     group.setXOrigin(x_scale_factor * group.xOrigin)
    #     group.setYOrigin(y_scale_factor * group.yOrigin)
    #     group.setZOrigin(z_scale_factor * group.zOrigin)
    #   end
    
    # retrieves all (Interior Partition Surfaces, Shading Surfaces, Subsurfaces ans Surfaces) in the user_specified_space and modifies the existing x,y,z verticies by the user-defined scale factor 
      flower_space.surfaces.each do |surface|
        vertices = surface.vertices
        new_vertices = OpenStudio::Point3dVector.new
        vertices.each do |vertex|
          new_vertices << OpenStudio::Point3d.new(x_scale_factor * vertex.x, y_scale_factor * vertex.y, z_scale_factor * vertex.z)
        end
        surface.setVertices(new_vertices)
      end
  
      flower_new_floor_area = flower_space.floorArea

      puts "flower_new_floor_area"
      puts flower_new_floor_area

    # # retrieve all daylighting controls in the model and modify the existing x,y,z verticies by the user-defined scale factors
    #   model.getDaylightingControls.each do |control|
    #     control.setPositionXCoordinate(x_scale_factor * control.positionXCoordinate)
    #     control.setPositionYCoordinate(y_scale_factor * control.positionYCoordinate)
    #     control.setPositionZCoordinate(z_scale_factor * control.positionZCoordinate)
    #   end
    
    # # retrieve all glare sensors in the model and modify the existing x,y,z sensor position by the user-defined scale factors
    #   model.getGlareSensors.each do |sensor|
    #     sensor.setPositionXCoordinate(x_scale_factor * sensor.positionXCoordinate)
    #     sensor.setPositionYCoordinate(y_scale_factor * sensor.positionYCoordinate)
    #     sensor.setPositionZCoordinate(z_scale_factor * sensor.positionZCoordinate)
    #   end
      
    # # retrieve all glare sensors in the model and modify the existing x,y,z origin position by the user-defined scale factors
    #   model.getGlareSensors.each do |map|
    #     map.setOriginXCoordinate(x_scale_factor * map.originXCoordinate)
    #     map.setOriginYCoordinate(y_scale_factor * map.originYCoordinate)
    #     map.setXLength(x_scale_factor * map.xLength)
    #     map.setYLength(y_scale_factor * map.yLength)
    #   end
  
    # report changes made by measure
    runner.registerInfo("An X-scale factor of #{x_scale_factor} was applied to the model geometry, including modifying any daylight control and glare sensor locations.")
    runner.registerInfo("An Y-scale factor of #{y_scale_factor} was applied to the model geometry, including modifying any daylight control and glare sensor locations.")
    
      return true
  
    end # end run method
    
  end # end class 
    
  # register the measure to be used by the application
  CEAIndoorScaleCultivationRoom.new.registerWithApplication
  