

###### (Automatically generated documentation)

# customize_prototypical_vrf_and_doas_configurations

## Description
Intended to work down stream of Create_Typical and standards-gem workflows to allow some configuration edits to the VRF and VRF with DOAS system types.



## Modeler Description
Use the system_type argument to validate eligibility of the measure application

Then edits the prototyipcal built VFR and DOAS configuration for UI control of 

ERV/HRV
Sens and Latent
Pressure
DOAS Source
NG, Elec, HP, none

VRF

H COP
C COP
Heat Recovery / Heat Pump
Back up heat (ie the no fan power Unit heating within the spaces)

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### system_type

**Name:** system_type,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["DOAS with VRF", "VRF", "PTHP", "PTAC with gas coil", "PSZ-HP", "PSZ-AC with gas coil", "PVAV with PFP boxes", "PVAV with gas boiler reheat", "VAV chiller with PFP boxes", "VAV chiller with gas boiler reheat"]


### doas_htg_coil_type

**Name:** doas_htg_coil_type,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Natural Gas", "Electric Resistance", "Heat Pump", "No Heating Coil"]


### energy_recovery_device_type

**Name:** energy_recovery_device_type,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["HRV", "ERV", "None"]


### Enter the Airside Pressure Drop [inH2O]

**Name:** erv_hrv_airside_pressure_drop_ip,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Sensible Effectiveness at 100% Airflow

**Name:** erv_hrv_sens_eff_100,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Latent Effectiveness at 100%

**Name:** erv_hrv_lat_eff_100,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### DOAS Rated EER

**Name:** rated_eer_at_design_capacity,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### DOAS Rated EER

**Name:** rated_eer_at_low_capacity,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### What is the VRF back up heat

**Name:** tz_secondary_htg_fuel,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Electric Resistance", "Natural Gas", "None"]


### Cooling COP

**Name:** vrf_outdoor_unit_rated_clg_cop,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Heating COP

**Name:** vrf_outdoor_unit_rated_htg_cop,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Choose the VRF Operation Mode

**Name:** vrf_system_mode,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** ["Heat Pump", "Heat Recovery"]


### What is the standard for this building
This argument is intended to be populated by the upstream Create Typical/Bar measure and written automatically by our forms
**Name:** template,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false






