# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CustomizePrototypicalVrfAndDoasConfigurations < OpenStudio::Measure::ModelMeasure

  # use for helper methods with the HP coils
  require 'openstudio-standards'


  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'customize_prototypical_vrf_and_doas_configurations'
  end

  # human readable description
  def description
    return 'Intended to work down stream of Create_Typical and standards-gem workflows to allow some configuration edits to the VRF and VRF with DOAS system types.

'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Use the system_type argument to validate eligibility of the measure application

Then edits the prototyipcal built VFR and DOAS configuration for UI control of 

ERV/HRV
Sens and Latent
Pressure
DOAS Source
NG, Elec, HP, none

VRF

H COP
C COP
Heat Recovery / Heat Pump
Back up heat (ie the no fan power Unit heating within the spaces)'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # valid system type choice list
    valid_system_type_list = OpenStudio::StringVector.new
    valid_system_type_list << "DOAS with VRF"
    valid_system_type_list << "VRF"
    valid_system_type_list << "PTHP"
    valid_system_type_list << "PTAC with gas coil"
    valid_system_type_list << "PSZ-HP"
    valid_system_type_list << "PSZ-AC with gas coil"
    valid_system_type_list << "PVAV with PFP boxes"
    valid_system_type_list << "PVAV with gas boiler reheat"
    valid_system_type_list << "VAV chiller with PFP boxes"
    valid_system_type_list << "VAV chiller with gas boiler reheat"
    system_type = OpenStudio::Measure::OSArgument::makeChoiceArgument('system_type', valid_system_type_list, true)
    system_type.setDefaultValue("DOAS with VRF")
    args << system_type

    #lots more args
    # "doas_htg_coil_type" : "Natural Gas",
    coil_type_list = OpenStudio::StringVector.new
    coil_type_list << "Natural Gas"
    coil_type_list << "Electric Resistance"
    coil_type_list << "Heat Pump"
    coil_type_list << "No Heating Coil"
    doas_htg_coil_type = OpenStudio::Measure::OSArgument::makeChoiceArgument('doas_htg_coil_type', coil_type_list, true)
    doas_htg_coil_type.setDefaultValue("Natural Gas")
    args << doas_htg_coil_type

    # "energy_recovery_device_type" : "ERV",
    erv_device_typ_list = OpenStudio::StringVector.new
    erv_device_typ_list << "HRV"
    erv_device_typ_list << "ERV"
    erv_device_typ_list << "None"
    energy_recovery_device_type = OpenStudio::Measure::OSArgument::makeChoiceArgument('energy_recovery_device_type', erv_device_typ_list, true)
    energy_recovery_device_type.setDefaultValue("ERV")
    args << energy_recovery_device_type
    # "erv_hrv_airside_pressure_drop_ip" : 0.75,
    erv_hrv_airside_pressure_drop_ip = OpenStudio::Measure::OSArgument::makeDoubleArgument('erv_hrv_airside_pressure_drop_ip', true)
    erv_hrv_airside_pressure_drop_ip.setDisplayName("Enter the Airside Pressure Drop [inH2O]")
    erv_hrv_airside_pressure_drop_ip.setDefaultValue(0.25)
    args << erv_hrv_airside_pressure_drop_ip

    # "erv_hrv_sens_eff_100" : 0.75
    erv_hrv_sens_eff_100 = OpenStudio::Measure::OSArgument::makeDoubleArgument('erv_hrv_sens_eff_100', true)
    erv_hrv_sens_eff_100.setDisplayName("Sensible Effectiveness at 100% Airflow")
    erv_hrv_sens_eff_100.setDefaultValue(0.75)
    args << erv_hrv_sens_eff_100
    # "erv_hrv_lat_eff_100" : 0.75,
    erv_hrv_lat_eff_100 = OpenStudio::Measure::OSArgument::makeDoubleArgument('erv_hrv_lat_eff_100', true)
    erv_hrv_lat_eff_100.setDisplayName("Latent Effectiveness at 100%")
    erv_hrv_lat_eff_100.setDefaultValue(0.50)
    args << erv_hrv_lat_eff_100

    # "rated_eer_at_design_capacity" : 12,
    rated_eer_at_design_capacity = OpenStudio::Measure::OSArgument::makeDoubleArgument('rated_eer_at_design_capacity', true)
    rated_eer_at_design_capacity.setDisplayName("DOAS Rated EER")
    rated_eer_at_design_capacity.setDefaultValue(12)
    args << rated_eer_at_design_capacity
    # "rated_eer_at_low_capacity" : 12
    rated_eer_at_low_capacity = OpenStudio::Measure::OSArgument::makeDoubleArgument('rated_eer_at_low_capacity', true)
    rated_eer_at_low_capacity.setDisplayName("DOAS Rated EER")
    rated_eer_at_low_capacity.setDefaultValue(12)
    args << rated_eer_at_low_capacity

    # "tz_secondary_htg_fuel" : "Electric",
    backup_heat_options_list = OpenStudio::StringVector.new
    backup_heat_options_list << "Electric Resistance"
    backup_heat_options_list << "Natural Gas"
    backup_heat_options_list << "None"
    tz_secondary_htg_fuel = OpenStudio::Measure::OSArgument::makeChoiceArgument('tz_secondary_htg_fuel', backup_heat_options_list, true)
    tz_secondary_htg_fuel.setDisplayName("What is the VRF back up heat")
    tz_secondary_htg_fuel.setDefaultValue("Natural Gas")
    args << tz_secondary_htg_fuel

    # "vrf_outdoor_unit_rated_clg_cop" : 3.7000000000000002,
    vrf_outdoor_unit_rated_clg_cop = OpenStudio::Measure::OSArgument::makeDoubleArgument('vrf_outdoor_unit_rated_clg_cop',true)
    vrf_outdoor_unit_rated_clg_cop.setDisplayName("Cooling COP")
    vrf_outdoor_unit_rated_clg_cop.setDefaultValue(3.32)
    args << vrf_outdoor_unit_rated_clg_cop
    # "vrf_outdoor_unit_rated_htg_cop" : 3.5299999999999998,
    vrf_outdoor_unit_rated_htg_cop = OpenStudio::Measure::OSArgument::makeDoubleArgument('vrf_outdoor_unit_rated_htg_cop',true)
    vrf_outdoor_unit_rated_htg_cop.setDisplayName("Heating COP")
    vrf_outdoor_unit_rated_htg_cop.setDefaultValue(3.32)
    args << vrf_outdoor_unit_rated_htg_cop
    # "vrf_system_mode" : "Heat Recovery"
    vrf_mode_list = OpenStudio::StringVector.new
    vrf_mode_list << "Heat Pump"
    vrf_mode_list << "Heat Recovery"
    vrf_system_mode = OpenStudio::Measure::OSArgument::makeChoiceArgument('vrf_system_mode', vrf_mode_list, true)
    vrf_system_mode.setDisplayName("Choose the VRF Operation Mode")
    vrf_system_mode.setDefaultValue("Heat Recovery")
    args << vrf_system_mode

    # need template argument for standard building
    template = OpenStudio::Measure::OSArgument::makeStringArgument('template', true)
    template.setDisplayName('What is the standard for this building')
    template.setDescription('This argument is intended to be populated by the upstream Create Typical/Bar measure and written automatically by our forms')
    template.setDefaultValue('90.1-2019')
    args << template

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables

    # argument used to determine eligibility of this measure
    system_type = runner.getStringArgumentValue('system_type', user_arguments)
    template = runner.getStringArgumentValue('template', user_arguments)

    standard = Standard.build(template)

    # puts "*********************** Standard ************************"
    # puts standard
    # puts "template"
    # puts template

    # arguments for VRF system configuration
    vrf_system_mode = runner.getStringArgumentValue('vrf_system_mode', user_arguments)
    tz_secondary_htg_fuel = runner.getStringArgumentValue('tz_secondary_htg_fuel', user_arguments)
    vrf_outdoor_unit_rated_clg_cop = runner.getDoubleArgumentValue('vrf_outdoor_unit_rated_clg_cop', user_arguments)
    vrf_outdoor_unit_rated_htg_cop = runner.getDoubleArgumentValue('vrf_outdoor_unit_rated_htg_cop', user_arguments)


    
    # arguments for the DOAS configuration
    energy_recovery_device_type = runner.getStringArgumentValue('energy_recovery_device_type', user_arguments)
    doas_htg_coil_type = runner.getStringArgumentValue('doas_htg_coil_type', user_arguments)
    erv_hrv_airside_pressure_drop_ip = runner.getDoubleArgumentValue('erv_hrv_airside_pressure_drop_ip', user_arguments)
    erv_hrv_lat_eff_100 = runner.getDoubleArgumentValue('erv_hrv_lat_eff_100', user_arguments)
    erv_hrv_sens_eff_100 = runner.getDoubleArgumentValue('erv_hrv_sens_eff_100', user_arguments)
    #these inputs are currently unused.
    rated_eer_at_design_capacity = runner.getDoubleArgumentValue('rated_eer_at_design_capacity', user_arguments)
    rated_eer_at_low_capacity = runner.getDoubleArgumentValue('rated_eer_at_low_capacity', user_arguments)

    # hold space for initial and final logs
    initial_condition = ""
    info = ""
    final_condition = ""
    # counts for logs
    coil_removed_count = 0

    # begin editing the heat exchanger details based on type to get the Supply Fan pressure correct.
    if energy_recovery_device_type == "ERV" || energy_recovery_device_type == "HRV"
      supply_fan_design_pressure_drop_ip = 2.045  # this has been reset down based on our earlier experiences with DOAS
      # the supply fan pressure drop should equal the 2.045 TSP plus the user spec'd ERV/HRV pressure drop in "H20.
      supply_fan_design_pressure_drop_ip = supply_fan_design_pressure_drop_ip + erv_hrv_airside_pressure_drop_ip
      supply_fan_design_pressure_drop_si = OpenStudio::convert(supply_fan_design_pressure_drop_ip,"inH_{2}O","Pa").get
    else
      # don't add in the ERV/HRV device pressure drop
      supply_fan_design_pressure_drop_ip = 2.045
      supply_fan_design_pressure_drop_si = OpenStudio::convert(supply_fan_design_pressure_drop_ip,"inH_{2}O","Pa").get
    end

 

    if system_type == "DOAS with VRF"
      # section for both DOAS and VRF Edits

      # obtain the DOAS, this assumes that the only AirLoopHVAC objects within the model are for DOAS
      doases = model.getAirLoopHVACs
      doas_count = doases.size
      initial_condition << "\n and #{doas_count} Dedicated Outdoor Air Systems (DOAS)s"
      doases.each do |doas|
        coil_removed_count = 0
        coil_added_count = 0
        doas_supply_components = doas.supplyComponents
        new_coil_components = []
        # for loop through all of the supply components on this "DOAS" AirLoopHVAC and check them for type to be removed.
        # we want to remove them all so that we can rebuild using the logial pathways from the user arguments choice list for
        # doas_htg_coil_type string argument.
        for i in 0..doas_supply_components.size-1
          # remove if electric heating coil is in the DOAS                          # TODO this could be more elegant and with less if statements if your us the the cast to_IddObjectType instead of calling the object directly
          if !doas_supply_components[i].to_CoilHeatingElectric.empty?
            elec_heat_coil = doas_supply_components[i].to_CoilHeatingElectric.get
            info << "\nPrototypical #{elec_heat_coil.name} was removed from the DOAS"
            elec_heat_coil.remove
            coil_removed_count = coil_removed_count + 1

          end # if
          # remove if gas heating coil
          if !doas_supply_components[i].to_CoilHeatingGas.empty?
            gas_heat_coil = doas_supply_components[i].to_CoilHeatingGas.get
            info << "\nPrototypical #{gas_heat_coil.name} was removed from the DOAS"
            gas_heat_coil.remove
            coil_removed_count = coil_removed_count + 1
          end # if
          # remove if heatpump coil
          if !doas_supply_components[i].to_CoilHeatingDXSingleSpeed.empty?
            hp_heat_coil = doas_supply_components[i].to_CoilHeatingDXSingleSpeed.get
            info << "\nPrototypical #{hp_heat_coil.name} was removed from the DOAS"
            hp_heat_coil.remove
            coil_removed_count = coil_removed_count + 1
          end # if
          # all of the heating coils have been removed
        end # for
        
        # begin logic path for user selection of doas_htg_coil_type
        # TODO Do I have to add to a specific spot or can I just add to the supply side

        if doas_htg_coil_type == "Natural Gas"
          user_added_hc = OpenStudio::Model::CoilHeatingGas.new(model, model.alwaysOnDiscreteSchedule())
          user_added_hc.setName("VEIC User Configuration Gas Coil")
          user_added_hc.setFuelType("NaturalGas")
          new_coil_components << user_added_hc
          coil_added_count = coil_added_count + 1
        end

        if doas_htg_coil_type == "Heat Pump"
          # user_added_hc = OpenStudio::Model::CoilHeatingDXSingleSpeed.new(model, model.alwaysOnDiscreteSchedule())
          user_added_hc = OpenStudio::Model::CoilHeatingDXSingleSpeed.new(model)
          user_added_hc.setName("VEIC User Configuration Heat Pump Coil")
          new_coil_components << user_added_hc
          user_added_elec_backup = OpenStudio::Model::CoilHeatingElectric.new(model, model.alwaysOnDiscreteSchedule())
          user_added_elec_backup.setName("Back up Elec for the HP")
          new_coil_components << user_added_elec_backup
          coil_added_count = coil_added_count + 2
        end

        if doas_htg_coil_type == "Electric Resistance"
          user_added_hc = OpenStudio::Model::CoilHeatingElectric.new(model, model.alwaysOnDiscreteSchedule())
          user_added_hc.setName("VEIC User Configuration Electric Coil")
          new_coil_components << user_added_hc
          coil_added_count = coil_added_count + 1
        end
        #just need to register an info because all of the prototypical coils have been removed.
        if doas_htg_coil_type == "No Heating Coil"
          info << "\n The DOAS named: #{doas.name} had the prototypical configuration reset to #{doas_htg_coil_type}"
        end

        #remove the existing supply fan from the DOAS, clone and added to the new_components vector
        supply_fan = doas.supplyFan.get
        supply_fan = supply_fan.to_FanConstantVolume.get
        # clone
        new_supply_fan = supply_fan.clone(model)
        new_supply_fan.setName("Fan 32_")
        # new_supply_fan.setPressureRise(supply_fan_design_pressure_drop_si)

        # remove
        supply_fan.remove
        # cast
        new_supply_fan = new_supply_fan.to_FanConstantVolume.get
        new_supply_fan.setPressureRise(supply_fan_design_pressure_drop_si.to_f)
        # add to new comonents
        new_coil_components << new_supply_fan
        # establish the loop outlet to add the new components (cloned SF)
        supply_outlet_node = doas.supplyOutletNode
        # add the new heating coil components to the existing doas unit by way of the supplyOutletNode
        new_coil_components.each do |new_coil|
          new_coil.addToNode(supply_outlet_node)
          info << "\n The DOAS named: #{doas.name}, had a new HVAC object named #{new_coil.name} added to it. "
        end


        final_condition << "#{doas.name} had #{coil_removed_count} AHU coils removed from the prototyipcal configuration"

        # get the Air to Air Heatexchangers
        a_to_a_hxs = model.getHeatExchangerAirToAirSensibleAndLatents
        
        # begin editing the heat exchanger details
        if energy_recovery_device_type == "ERV"
          #then latent =/= 0
          # these 75% values are copied from our previous VEIC measure
          sensible_eff_75 = 0.75
          latent_eff_75 = 0.69
          a_to_a_hxs.each do |hx|
            hx.setName("VEIC User Selected ERV")
            hx.setSensibleEffectivenessat100CoolingAirFlow(erv_hrv_sens_eff_100)
            hx.setSensibleEffectivenessat100HeatingAirFlow(erv_hrv_sens_eff_100)
            hx.setSensibleEffectivenessat75CoolingAirFlow(sensible_eff_75)
            hx.setSensibleEffectivenessat75HeatingAirFlow(sensible_eff_75)
            hx.setLatentEffectivenessat100CoolingAirFlow(erv_hrv_lat_eff_100)
            hx.setLatentEffectivenessat100HeatingAirFlow(erv_hrv_lat_eff_100)
            hx.setLatentEffectivenessat75CoolingAirFlow(latent_eff_75)
            hx.setLatentEffectivenessat75HeatingAirFlow(latent_eff_75)

            puts hx
          end
        elsif energy_recovery_device_type == "HRV"
          # latent = 0
          sensible_eff_75 = 0.75
          latent_eff_75 = 0   # no moisture exchange in Heat Recovery
          erv_hrv_lat_eff_100 = 0
          a_to_a_hxs.each do |hx|
            hx.setName("VEIC User Selected HRV")
            hx.setSensibleEffectivenessat100CoolingAirFlow(erv_hrv_sens_eff_100)
            hx.setSensibleEffectivenessat100HeatingAirFlow(erv_hrv_sens_eff_100)
            hx.setSensibleEffectivenessat75CoolingAirFlow(sensible_eff_75)
            hx.setSensibleEffectivenessat75HeatingAirFlow(sensible_eff_75)
            hx.setLatentEffectivenessat100CoolingAirFlow(erv_hrv_lat_eff_100)
            hx.setLatentEffectivenessat100HeatingAirFlow(erv_hrv_lat_eff_100)
            hx.setLatentEffectivenessat75CoolingAirFlow(latent_eff_75)
            hx.setLatentEffectivenessat75HeatingAirFlow(latent_eff_75)

            puts hx
          end            
        else
          # remove the hx
          a_to_a_hxs.each do |hx|
            hx.remove
          end
        end
        # now do the VRF edits within the 


      end # do for the doas edits

      #begin the VRF edits
      vrf_systems = model.getAirConditionerVariableRefrigerantFlows
      vrf_count = vrf_systems.size
      initial_condition << "\n The prototypical system build includes #{vrf_count} VRF systems"

      # vrf_system_mode
      # tz_secondary_htg_fuel
      # vrf_outdoor_unit_rated_clg_cop
      # vrf_outdoor_unit_rated_htg_cop
      vrf_systems.each do |vrf|
        if vrf_system_mode == "Heat Recovery"
          vrf.setHeatPumpWasteHeatRecovery(true)
        elsif vrf_system_mode == "Heat Pump"
          vrf.setHeatPumpWasteHeatRecovery(false)
        end
        if vrf_outdoor_unit_rated_clg_cop == 0
          info << "The user specificed the Smart Default of #{vrf_outdoor_unit_rated_clg_cop} and the prototypical cooling efficiency is applied"
        else #set COP
          vrf.setGrossRatedCoolingCOP(vrf_outdoor_unit_rated_clg_cop)
          final_condition << "The #{vrf.name} had the user set the Cooling COP #{vrf_outdoor_unit_rated_clg_cop}"
        end
        if vrf_outdoor_unit_rated_htg_cop == 0
          info << "The user specificed the Smart Default of #{vrf_outdoor_unit_rated_htg_cop} and the prototypical heating efficiency is applied"
        else #set COP
          vrf.setRatedHeatingCOP(vrf_outdoor_unit_rated_htg_cop)
          final_condition << "The #{vrf.name} had the user set the Heating COP #{vrf_outdoor_unit_rated_clg_cop}"
        end
      end # editing the out door units
      
      # now address the indoor unit back up heat configurations
      model.getThermalZones.each do |thermal_zone|

        if tz_secondary_htg_fuel == "Natural Gas"
          secondary_htg_coil = OpenStudio::Model::CoilHeatingGas.new(model)
          secondary_htg_coil.setAvailabilitySchedule(model.alwaysOnDiscreteSchedule())
          secondary_htg_coil.setFuelType("NaturalGas")
          secondary_htg_coil.setName("VEIC User identified NG Back up heat #{thermal_zone.name}")
          secondary_htg_coil.setGasBurnerEfficiency(0.80)
        elsif tz_secondary_htg_fuel == "Electric Resistance"
          secondary_htg_coil = OpenStudio::Model::CoilHeatingElectric.new(model)
          secondary_htg_coil.setAvailabilitySchedule(model.alwaysOnDiscreteSchedule())
          secondary_htg_coil.setName("VEIC User identified elec heat #{thermal_zone.name}")
          secondary_htg_coil.setEfficiency(1.0)
        else
          info << "No back up heat added to the thermal zone #{thermal_zone.name}"
        end # end the secondary coil type checks and coil builds

        if not tz_secondary_htg_fuel == "None"
          # create thermal zone secondary heating source dummy supply fan (fan energy = 0)
          tz_secondary_heat_source_fan = OpenStudio::Model::FanConstantVolume.new(model, model.alwaysOnDiscreteSchedule())
          tz_secondary_heat_source_fan.setFanEfficiency(99.99) # results in near zero fan energy usage, may create false warnings in eplusout.err file
          tz_secondary_heat_source_fan.setPressureRise(0.001) # results in near zero fan energy usage, may create false warnings in eplusout.err file
          tz_secondary_heat_source_fan.setMotorEfficiency(99.99) # results in near zero fan energy usage, may create false warnings in eplusout.err file
          tz_secondary_heat_source_fan.setMotorInAirstreamFraction(0.0) # results in no fan motor heat to zone 
          tz_secondary_heat_source_fan.setEndUseSubcategory("Dummy Fan Energy Usage")
          tz_secondary_heat_source = OpenStudio::Model::ZoneHVACUnitHeater.new(model, model.alwaysOnDiscreteSchedule(),tz_secondary_heat_source_fan, secondary_htg_coil)
          tz_secondary_heat_source.setName("#{tz_secondary_htg_fuel} heat serving #{thermal_zone.name}.")
          tz_secondary_heat_source.addToThermalZone(thermal_zone)
          runner.registerInfo("Created a #{tz_secondary_htg_fuel} unit heater and assigned it to thermal zone #{thermal_zone.name}.")
        end
      end # the do loop for editing the thermal zones
        
      


      








    elsif system_type == "VRF"
      #begin the VRF edits
      vrf_systems = model.getAirConditionerVariableRefrigerantFlows
      vrf_count = vrf_systems.size
      initial_condition << "\n The prototypical system build includes #{vrf_count} VRF systems"

      # vrf_system_mode
      # tz_secondary_htg_fuel
      # vrf_outdoor_unit_rated_clg_cop
      # vrf_outdoor_unit_rated_htg_cop
      vrf_systems.each do |vrf|
        if vrf_system_mode == "Heat Recovery"
          vrf.setHeatPumpWasteHeatRecovery(true)
        elsif vrf_system_mode == "Heat Pump"
          vrf.setHeatPumpWasteHeatRecovery(false)
        end
        if vrf_outdoor_unit_rated_clg_cop == 0
          info << "The user specificed the Smart Default of #{vrf_outdoor_unit_rated_clg_cop} and the prototypical cooling efficiency is applied"
        else #set COP
          vrf.setGrossRatedCoolingCOP(vrf_outdoor_unit_rated_clg_cop)
          final_condition << "The #{vrf.name} had the user set the Cooling COP #{vrf_outdoor_unit_rated_clg_cop}"
        end
        if vrf_outdoor_unit_rated_htg_cop == 0
          info << "The user specificed the Smart Default of #{vrf_outdoor_unit_rated_htg_cop} and the prototypical heating efficiency is applied"
        else #set COP
          vrf.setRatedHeatingCOP(vrf_outdoor_unit_rated_htg_cop)
          final_condition << "The #{vrf.name} had the user set the Heating COP #{vrf_outdoor_unit_rated_clg_cop}"
        end
      end # editing the out door units
      
      # now address the indoor unit back up heat configurations
      model.getThermalZones.each do |thermal_zone|

        if tz_secondary_htg_fuel == "Natural Gas"
          secondary_htg_coil = OpenStudio::Model::CoilHeatingGas.new(model)
          secondary_htg_coil.setAvailabilitySchedule(model.alwaysOnDiscreteSchedule())
          secondary_htg_coil.setFuelType("NaturalGas")
          secondary_htg_coil.setName("VEIC User identified NG Back up heat #{thermal_zone.name}")
          secondary_htg_coil.setGasBurnerEfficiency(0.80)
        elsif tz_secondary_htg_fuel == "Electric Resistance"
          secondary_htg_coil = OpenStudio::Model::CoilHeatingElectric.new(model)
          secondary_htg_coil.setAvailabilitySchedule(model.alwaysOnDiscreteSchedule())
          secondary_htg_coil.setName("VEIC User identified elec heat #{thermal_zone.name}")
          secondary_htg_coil.setEfficiency(1.0)
        else
          info << "No back up heat added to the thermal zone #{thermal_zone.name}"
        end # end the secondary coil type checks and coil builds

        if not tz_secondary_htg_fuel == "None"
          # create thermal zone secondary heating source dummy supply fan (fan energy = 0)
          tz_secondary_heat_source_fan = OpenStudio::Model::FanConstantVolume.new(model, model.alwaysOnDiscreteSchedule())
          tz_secondary_heat_source_fan.setFanEfficiency(99.99) # results in near zero fan energy usage, may create false warnings in eplusout.err file
          tz_secondary_heat_source_fan.setPressureRise(0.001) # results in near zero fan energy usage, may create false warnings in eplusout.err file
          tz_secondary_heat_source_fan.setMotorEfficiency(99.99) # results in near zero fan energy usage, may create false warnings in eplusout.err file
          tz_secondary_heat_source_fan.setMotorInAirstreamFraction(0.0) # results in no fan motor heat to zone 
          tz_secondary_heat_source_fan.setEndUseSubcategory("Dummy Fan Energy Usage")
          tz_secondary_heat_source = OpenStudio::Model::ZoneHVACUnitHeater.new(model, model.alwaysOnDiscreteSchedule(),tz_secondary_heat_source_fan, secondary_htg_coil)
          tz_secondary_heat_source.setName("#{tz_secondary_htg_fuel} heat serving #{thermal_zone.name}.")
          tz_secondary_heat_source.addToThermalZone(thermal_zone)
          runner.registerInfo("Created a #{tz_secondary_htg_fuel} unit heater and assigned it to thermal zone #{thermal_zone.name}.")
        end
      end # the do loop for editing the thermal zones
    else
      puts "system type"
      puts system_type
      puts "not appropriate for this measure return false"
      return false
    end

    runner.registerInitialCondition(initial_condition)
    runner.registerInfo(info)
    runner.registerFinalCondition(final_condition)

    return true
  end
end

# register the measure to be used by the application
CustomizePrototypicalVrfAndDoasConfigurations.new.registerWithApplication
