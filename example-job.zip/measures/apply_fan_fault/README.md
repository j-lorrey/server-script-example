

###### (Automatically generated documentation)

# apply_fan_fault

## Description
A measure to apply fans as always running where previously there was an occupancy based shut off

## Modeler Description
Look at subing in the always on discrete schedule where an occupancy one had been.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Apply a Fan Fault?
This will ingore occupancy schedule based controls and run fans 24/7
**Name:** fan_fault,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false






