# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class ApplyFanFault < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'apply_fan_fault'
  end

  # human readable description
  def description
    return 'A measure to apply fans as always running where previously there was an occupancy based shut off'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Look at subing in the always on discrete schedule where an occupancy one had been.'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # the name of the space to add to the model
    fan_fault = OpenStudio::Measure::OSArgument.makeBoolArgument('fan_fault', true)
    fan_fault.setDisplayName('Apply a Fan Fault?')
    fan_fault.setDescription('This will ingore occupancy schedule based controls and run fans 24/7')
    args << fan_fault

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    fan_fault = runner.getBoolArgumentValue('fan_fault', user_arguments)

    runner.registerInitialCondition("fan fault was set to #{fan_fault}")

    if fan_fault == true
      # find the AirLoopHVAC, AirLoopHVAC:UnitarySystem, and ControllerOutdoorAir objects and reset the schedule to the always on discrete
      air_loops = model.getAirLoopHVACs
      air_loops_unitary = model.getAirLoopHVACUnitarySystems
      oa_controllers = model.getControllerOutdoorAirs
      
      always_on_schedule = []
      # get the always on discrete schedule
      constant_schedules = model.getScheduleConstants
      constant_schedules.each do |always_on|
        if always_on.name.get == "Always On Discrete"
          always_on_schedule = always_on  
        end
      end

      air_loop_edit_count = 0
      # loop through the required objects and sub in the Always On Discrete schedule
      air_loops.each do |al|
        runner.registerInfo("The AirLoopHVAC #{al.name} orginally had an Availability Schedule of #{al.availabilitySchedule.name}")
        # add one to the Loop counter
        al.setAvailabilitySchedule(always_on_schedule)
        air_loop_edit_count += 1
        runner.registerInfo("The AirLoopHVAC #{al.name} has a new schedule of #{al.availabilitySchedule.name}")
      end

      air_loop_unitary_count = 0
      air_loops_unitary.each do |alu|
        # runner.registerInfo("The AirLoopHVACUnitary #{alu.name} orginally had an Availability Schedule of #{alu.availabilitySchedule.name}")
        # add one to the Loop counter
        alu.setAvailabilitySchedule(always_on_schedule)
        alu.setSupplyAirFanOperatingModeSchedule(always_on_schedule)
        air_loop_unitary_count += 1
        # runner.registerInfo("The AirLoopHVACUnitary #{alu.name} has a new schedule of #{alu.availabilitySchedule.name}")
      end

      # During testing across available system types it appears that the OA Controller and the Availability Manager Night Cycle 
      # are the key elements for getting the other non-AirLoopHVACUnitarySystem components to refelect the fan overages.
      oa_controller_count = 0
      oa_controllers.each do |oac|
        # runner.registerInfo("The ControllerOA #{oac.name} orginally had an Mimimum Outdoor Air Schedule of #{oac.minimumOutdoorAirSchedule.name}")
        # add one to the Loop counter
        oac.setMinimumOutdoorAirSchedule(always_on_schedule)
        oa_controller_count += 1
        # runner.registerInfo("The Controller:OutdoorAir #{oac.name} has a new schedule of #{oac.minimumOutdoorAirSchedule.name}")
      end
      # AvailabilityManager:NightCycleControl in testing appears to tbe the key element to getting the fan fault measure to work.
      avmngr_nightcycle = model.getAvailabilityManagerNightCycles
      avmngr_count = 0
      avmngr_nightcycle.each do |avm_nightcycle|
        avm_nightcycle.setControlType("StayOff")
        avmngr_count +=1
      end




      runner.registerFinalCondition("#{oa_controller_count} ControllerOutdoorAir, 
        #{air_loop_unitary_count} AirLoopHVACUnitarySystem objects, 
        #{air_loop_edit_count} AirLoopHVAC objects all had their schedules reset to Always On Discrete,
        and #{avmngr_count} AvailabilityManager:NightCylce objects had Control Type set to 'Stay Off' so that fan schedule controls the fan
        ")
      
    end


    return true
  end
end

# register the measure to be used by the application
ApplyFanFault.new.registerWithApplication
