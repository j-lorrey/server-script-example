

###### (Automatically generated documentation)

# AssignConstructionSetToBuilding

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Set the Default Construction Set for the Building.

**Name:** construction_set,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false




