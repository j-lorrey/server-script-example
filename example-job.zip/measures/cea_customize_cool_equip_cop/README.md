

###### (Automatically generated documentation)

# cea_customize_cool_equip_cop

## Description
A cea measure for editing the EER by way of a conversion to COP of PTHP, Chiller, PTAC, PSZ-AC, WSHP

The measure will rely on the WTForm sharing the system_type variable assignment across all the workflow steps.  This knowledge makes a simple routine for using the system_type to guide the set COP methods.

## Modeler Description
Use the system_variable for if and ifels statments to access the appropriate model.object methods

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose a veg space

**Name:** veg_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** []


### Choose a flower space

**Name:** flower_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** []


### System Type string agrument
designed to follow the assignment from earlier in the create_typical measure portion of the workflow
**Name:** system_type,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### template string agrument
designed to follow the assignment from earlier in the create_typical measure portion of the workflow
**Name:** template,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### UI input for selecting desired rating condition
String agrument here, will be locked to a choices within the WTForms validator
**Name:** rating_category,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Numerical Entry for either SEER or EER, 0 smart defatult will follow the standards-gem
Will use the rating_category input for an IF statment on converting EER/SEER into model req COP (without Fan)
**Name:** rating_input,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false






