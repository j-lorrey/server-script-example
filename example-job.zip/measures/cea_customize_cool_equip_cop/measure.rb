# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CeaCustomizeCoolEquipCop < OpenStudio::Measure::ModelMeasure

  # connect to the NREL gems for helper methods
  require 'openstudio-standards'

  # load OpenStudio measure libraries from openstudio-extension gem
  require 'openstudio-extension'
  require 'openstudio/extension/core/os_lib_helper_methods'
  require 'openstudio/extension/core/os_lib_model_generation.rb'

  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'cea_customize_cool_equip_cop'
  end

  # human readable description
  def description
    return 'A cea measure for editing the EER by way of a conversion to COP of PTHP, Chiller, PTAC, PSZ-AC, WSHP

The measure will rely on the WTForm sharing the system_type variable assignment across all the workflow steps.  This knowledge makes a simple routine for using the system_type to guide the set COP methods.'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Use the system_variable for if and ifels statments to access the appropriate model.object methods'
  end
  
  
  # Ported from the standards gem using herein: TODO: leverage the standards gem directly".
  # def cop_to_eer(cop, capacity_w = nil)
  #   if capacity_w.nil?
  #     # The PNNL Method.
  #     # r is the ratio of supply fan power to total equipment power at the rating condition,
  #     # assumed to be 0.12 for the reference buildngs per PNNL.
  #     r = 0.12
  #     eer = 3.413 * (cop * (1 - r) - r)
  #   else
  #     # The 90.1-2013 method
  #     # Convert the capacity to Btu/hr
  #     capacity_btu_per_hr = OpenStudio.convert(capacity_w, 'W', 'Btu/hr').get
  #     eer = cop / (7.84E-8 * capacity_btu_per_hr + 0.338)
  #   end

  #   return eer
  # end
  # def eer_to_cop(eer, capacity_w = nil)
  #   if capacity_w.nil?
  #     # The PNNL Method.
  #     # r is the ratio of supply fan power to total equipment power at the rating condition,
  #     # assumed to be 0.12 for the reference buildings per PNNL.
  #     r = 0.12
  #     cop = (eer / 3.413 + r) / (1 - r)
  #   else
  #     # The 90.1-2013 method
  #     # Convert the capacity to Btu/hr
  #     capacity_btu_per_hr = OpenStudio.convert(capacity_w, 'W', 'Btu/hr').get
  #     cop = 7.84E-8 * eer * capacity_btu_per_hr + 0.338 * eer
  #   end

  #   return cop
  # end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # make a choice argument for model objects
    space_handles = OpenStudio::StringVector.new
    space_display_names = OpenStudio::StringVector.new

    # putting model object and names into hash
    space_args = model.getSpaces
    space_args_hash = {}
    space_args.each do |space_arg|
      space_args_hash[space_arg.name.to_s] = space_arg
    end

    # looping through sorted hash of model objects
    space_args_hash.sort.map do |key, value|
      space_handles << value.handle.to_s
      space_display_names << key
    end

    # make a choice argument for veg_space type or entire building
    veg_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('veg_space', space_handles, space_display_names, true)
    veg_space.setDisplayName('Choose a veg space')
    args << veg_space
    flower_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('flower_space', space_handles, space_display_names, true)
    flower_space.setDisplayName('Choose a flower space')
    args << flower_space

    # the name of the space to add to the model
    system_type = OpenStudio::Measure::OSArgument.makeStringArgument('system_type', true)
    system_type.setDisplayName('System Type string agrument')
    system_type.setDescription('designed to follow the assignment from earlier in the create_typical measure portion of the workflow')
    system_type.setDefaultValue('Residential heat pump')
    args << system_type

    #allowable system types
    # PTHP
    # Residential heat pump
    # Water source heat pumps fluid cooler with boiler
    # PTAC with gas unit heaters
    # VRF - not currently supported but in the base tool
    # Fan coil air-cooled chiller with boiler
    # Fan coil chiller with boile
    # PSZ-AC with gas coil




    # the name of the space to add to the model
    template = OpenStudio::Measure::OSArgument.makeStringArgument('template', true)
    template.setDisplayName('template string agrument')
    template.setDescription('designed to follow the assignment from earlier in the create_typical measure portion of the workflow')
    template.setDefaultValue('90.1-2016')
    args << template

    rating_category = OpenStudio::Measure::OSArgument.makeStringArgument('rating_category', true)
    rating_category.setDisplayName('UI input for selecting desired rating condition')
    rating_category.setDescription('String agrument here, will be locked to a choices within the WTForms validator')
    rating_category.setDefaultValue('EER')
    args << rating_category

    rating_input = OpenStudio::Measure::OSArgument.makeDoubleArgument('rating_input', true)
    rating_input.setDisplayName('Numerical Entry for either SEER or EER, 0 smart defatult will follow the standards-gem')
    rating_input.setDescription('Will use the rating_category input for an IF statment on converting EER/SEER into model req COP (without Fan)')
    rating_input.setDefaultValue(12.32)
    args << rating_input

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables
    system_type = runner.getStringArgumentValue('system_type', user_arguments)
    rating_category = runner.getStringArgumentValue('rating_category', user_arguments)
    rating_input = runner.getDoubleArgumentValue('rating_input', user_arguments)
    veg_space = runner.getOptionalWorkspaceObjectChoiceValue('veg_space', user_arguments, model)
    flower_space = runner.getOptionalWorkspaceObjectChoiceValue('flower_space', user_arguments, model)
    template = runner.getStringArgumentValue('template',user_arguments)

    standard = Standard.build(template)
    
    #cast object from the model to_ObjectType within this workspace
    veg_space = veg_space.get.to_Space.get
    flower_space = flower_space.get.to_Space.get
    #access the space's thermal zone
    veg_thermal_zone = veg_space.thermalZone.get
    flower_thermal_zone = flower_space.thermalZone.get

    # check to that rating_category is not an empty argumen
    if system_type.empty?
      runner.registerError('Empty system_type name was entered.')
      return false
    end
    # check to that rating_category is not an empty argument
    if rating_category.empty?
      runner.registerError('Empty rating_category was entered')
      return false
    end
    # Register Infor to the log file
    runner.registerInfo("User argument system_type set as #{system_type}")
    runner.registerInfo("User argument rating_category as #{rating_category}")

    if rating_input == 0
      runner.registerInfo("User entered #{rating_input} which triggerd the Smart Default to apply the relevant code standard")
      # since this assumed to run after Create_Typical this will return false to skip the remainder of the measure and
      # stick with what the previous setting was from Create_Typical
      return false
    else
      runner.registerInfo("User enetered a rating_input value of #{rating_input}")
    end
    #This next section is copied again below for a veg space
    # TDOD: add option for space name array input and the ability to choose a space, groups of space etc...
    
    # for PTHP, WSHP, VRF use the zone to access the Cooling coil objects for editing
    zone_cool_equips = flower_thermal_zone.equipmentInCoolingOrder
    # zone_cool_equips = []
    # the .equipmentInCoolingOrder is a SDK method for getting the cooling equipment from a specified zone
    # https://openstudio-sdk-documentation.s3.amazonaws.com/cpp/OpenStudio-3.3.0-doc/model/html/classopenstudio_1_1model_1_1_thermal_zone.html#ad7737f66d8d1a1f761a3c18fc1bdd835
    # it returns an array in the case that multiple objects to exsit

    if system_type == "PTHP"
      #this loops through the zone_cool_equips array and objectType cast checks for whether the object exists
      zone_cool_equips.each do |pthp|
        if !pthp.to_ZoneHVACPackagedTerminalHeatPump.empty?
          puts "made it here on passing the not empty check"
          pthp_flower = pthp.to_ZoneHVACPackagedTerminalHeatPump.get
          # once the zone_pthp is discovered and cast then the related cooling coil is obtained
          coil_cooling_dx_single_speed_flower = pthp_flower.coolingCoil
          # use and .empty? check before acting upon the model.objectType
          if !coil_cooling_dx_single_speed_flower.to_CoilCoolingDXSingleSpeed.empty?
            #cast into a useable using the to_ObjectType.get 
            coil_cooling_dx_single_speed_flower=coil_cooling_dx_single_speed_flower.to_CoilCoolingDXSingleSpeed.get
            og_cop = coil_cooling_dx_single_speed_flower.ratedCOP.to_f         
            og_eer = standard.cop_to_eer(og_cop.to_f)
            # puts "og_eer"
            # puts og_eer
            # report initial condition of model
            runner.registerInitialCondition("The #{flower_space.name} started with an #{og_eer} rated EER")
            # check the user input for rating category to define the conversion to cooling coil COP
            if rating_category == "EER"
              puts "converted user_input_cop"
              user_input_cop = standard.eer_to_cop(rating_input)
              puts user_input_cop
              coil_cooling_dx_single_speed_flower.setRatedCOP(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_dx_single_speed_flower
              runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated EER")
            elsif rating_category == "SEER"
              puts "converted user_input_cop"
              user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
              puts user_input_cop
              coil_cooling_dx_single_speed_flower.setRatedCOP(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_dx_single_speed_flower
              runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated SEER")
            end
          end

        

        else
          puts "array looping check is not working"
        end
      end
    elsif system_type == "Residential heat pump"
      # zone_cool_equips.each do |res_hp|
      # instead of the zone_cool_equips based off of the ThermalZone.equipmentInCoolingOrder method
      # thermal zone > airloop > AirLoopUnitarySytem
      res_hp_airloop = flower_thermal_zone.airLoopHVACs
      # puts "*********************  this is thermal zone > airLoopHVACs"
      # puts "res_hp_airloop"
      # puts res_hp_airloop
      # puts " **********************"
      # puts "us = model.AirLoopHVACUnitarySystems.get"
      us = model.getAirLoopHVACUnitarySystems
      # puts us
      puts "***********************************"
      puts "tzs = s.each do |u|
      tz = u.controllingZoneorThermostatLocation.get"
      # tzs = []
      us.each do |u|
        tz = u.controllingZoneorThermostatLocation.get
        puts tz.name.get
        if tz.name.get.match(flower_thermal_zone.name.to_s)
          coil_cooling_dx_single_speed_flower = u.coolingCoil.get
          puts coil_cooling_dx_single_speed_flower
          if !coil_cooling_dx_single_speed_flower.to_CoilCoolingDXSingleSpeed.empty?
            coil_cooling_dx_single_speed_flower=coil_cooling_dx_single_speed_flower.to_CoilCoolingDXSingleSpeed.get
            puts "***********************************************"
            puts "after the empty check on coil_cooling...." 
            puts coil_cooling_dx_single_speed_flower
                og_cop = coil_cooling_dx_single_speed_flower.ratedCOP.to_f         
                og_eer = standard.cop_to_eer(og_cop.to_f)
            # puts tzs
            runner.registerInitialCondition("The #{flower_space.name} started with an #{og_eer} rated EER")
              if rating_category == "EER"
                puts "converted user_input_cop"
                user_input_cop = standard.eer_to_cop(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_flower.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_flower
                runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated EER")
              elsif rating_category == "SEER"
                puts "converted user_input_cop"
                user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_flower.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_flower
                runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated SEER")
              end
          end     # tzs << tz
        end
      end

     
    elsif system_type == "Water source heat pumps fluid cooler with boiler"
      #this loops through the zone_cool_equips array and objectType cast checks for whether the object exists
      zone_cool_equips.each do |wshp|
        if !wshp.to_ZoneHVACWaterToAirHeatPump.empty?
          puts "made it here on passing the not empty check"
          wshp_flower = wshp.to_ZoneHVACWaterToAirHeatPump.get
          # obtain the CoilCoolingWaterToAirHeatPumpEquationFit
          coil_cooling_water_to_air_heat_pump_equation_fit = wshp_flower.coolingCoil
          if !coil_cooling_water_to_air_heat_pump_equation_fit.to_CoilCoolingWaterToAirHeatPumpEquationFit.empty?
            coil_cooling_water_to_air_heat_pump_equation_fit=coil_cooling_water_to_air_heat_pump_equation_fit.to_CoilCoolingWaterToAirHeatPumpEquationFit.get
            og_cop = coil_cooling_water_to_air_heat_pump_equation_fit.ratedCoolingCoefficientofPerformance.to_f
            og_eer = standard.cop_to_eer(og_cop.to_f)
            runner.registerInitialCondition("The #{flower_space.name} started with an #{og_eer} rated EER")
            if rating_category == "EER"
              puts "converted user_input_cop"
              user_input_cop = standard.eer_to_cop(rating_input)
              puts user_input_cop
              coil_cooling_water_to_air_heat_pump_equation_fit.setRatedCoolingCoefficientofPerformance(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_water_to_air_heat_pump_equation_fit
              runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated EER")
            elsif rating_category == "SEER"
              puts "converted user_input_cop"
              user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
              puts user_input_cop
              coil_cooling_water_to_air_heat_pump_equation_fit.setRatedCoolingCoefficientofPerformance(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_dx_single_speed_flower
              runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated SEER")
            end
          end
          else
          puts "array looping check is not working"
        end
      end
    elsif system_type == "PTAC with gas unit heaters"
      zone_cool_equips.each do |ptac|
        if !ptac.to_ZoneHVACPackagedTerminalAirConditioner.empty?
          puts "made it here on passing the not empty check"
          ptac_flower = ptac.to_ZoneHVACPackagedTerminalAirConditioner.get
           # once the zone_pthp is discovered and cast then the related cooling coil is obtained
           coil_cooling_dx_single_speed_flower = ptac_flower.coolingCoil
           # use and .empty? check before acting upon the model.objectType
           if !coil_cooling_dx_single_speed_flower.to_CoilCoolingDXSingleSpeed.empty?
             #cast into a useable using the to_ObjectType.get 
             coil_cooling_dx_single_speed_flower=coil_cooling_dx_single_speed_flower.to_CoilCoolingDXSingleSpeed.get
             og_cop = coil_cooling_dx_single_speed_flower.ratedCOP.to_f         
             og_eer = standard.cop_to_eer(og_cop.to_f)
             # puts "og_eer"
             # puts og_eer
             # report initial condition of model
             runner.registerInitialCondition("The #{flower_space.name} started with an #{og_eer} rated EER")
             # check the user input for rating category to define the conversion to cooling coil COP
             if rating_category == "EER"
               puts "converted user_input_cop"
               user_input_cop = standard.eer_to_cop(rating_input)
               puts user_input_cop
               coil_cooling_dx_single_speed_flower.setRatedCOP(user_input_cop)
               puts "coil after assignment"
               puts coil_cooling_dx_single_speed_flower
               runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated EER")
              elsif rating_category == "SEER"
                puts "converted user_input_cop"
                user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_flower.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_flower
                runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated SEER")
             end
           end
 
         
 
         else
           puts "array looping check is not working"
         end
       end
    elsif system_type == "VRF"
      runner.registerInfo("VRF not supported for COP/EER adjustment currently: curves are complex and remain default")
      return false

    # for the chiller systems use the getChiller method directly - this assumes only one chiller comes from Create_Typical
    # if the use case changes to multiple runs of Create_Typical then this measure will have to as well.
    elsif system_type == "Fan coil air-cooled chiller with boiler"
      all_chillers = model.getChillerElectricEIRs
        all_chillers.each do |chiller|
          og_cop = chiller.referenceCOP.to_f
          og_eer = standard.cop_to_eer(og_cop.to_f)
          runner.registerInitialCondition("The #{flower_space.name} started with an #{og_eer} rated EER")
          if rating_category == "EER"
            puts "converted user_input_cop"
            user_input_cop = standard.eer_to_cop(rating_input)
            puts user_input_cop
            chiller.setReferenceCOP(user_input_cop)
            puts "chiller after assignment"
            puts chiller
            runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated EER")
          elsif rating_category == "SEER"
            puts "converted user_input_cop"
            user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
            puts user_input_cop
            chiller.setReferenceCOP(user_input_cop)
            puts "chiller after assignment"
            puts chiller
            runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated SEER")
          end
        end
      # this is the second of the two chiller options
    elsif system_type == "Fan coil chiller with boiler"
      all_chillers = model.getChillerElectricEIRs
        all_chillers.each do |chiller|
          og_cop = chiller.referenceCOP.to_f
          og_eer = standard.cop_to_eer(og_cop.to_f)
          runner.registerInitialCondition("The #{flower_space.name} started with an #{og_eer} rated EER")
          if rating_category == "EER"
            puts "converted user_input_cop"
            user_input_cop = standard.eer_to_cop(rating_input)
            puts user_input_cop
            chiller.setReferenceCOP(user_input_cop)
            puts "chiller after assignment"
            puts chiller
            runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated EER")
          elsif rating_category == "SEER"
            puts "converted user_input_cop"
            user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
            puts user_input_cop
            chiller.setReferenceCOP(user_input_cop)
            puts "chiller after assignment"
            puts chiller
            runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated SEER")
          end
        end
    # for the PSZ-AC system this will access the Air Loop Unitary system directly
    # uses a name.get.match check to verify that the "space_name" is used to choose only a specific PSZ
    elsif system_type == "PSZ-AC with gas coil"
      # i = 1
      zone_air_loops_unitary_system = model.getAirLoopHVACUnitarySystems
      zone_air_loops_unitary_system.each do |psz_ac|
        if psz_ac.name.get.match("Zone - #{flower_space.name} PSZ-AC Unitary AC")
          if !psz_ac.to_AirLoopHVACUnitarySystem.empty?
            flower_psz_ac = psz_ac.to_AirLoopHVACUnitarySystem.get
            # puts flower_psz_ac
            coil_cooling_dx_single_speed_flower = flower_psz_ac.coolingCoil.get
            # puts coil_cooling_dx_single_speed_flower
            if !coil_cooling_dx_single_speed_flower.to_CoilCoolingDXSingleSpeed.empty?
              coil_cooling_dx_single_speed_flower=coil_cooling_dx_single_speed_flower.to_CoilCoolingDXSingleSpeed.get
              og_cop = coil_cooling_dx_single_speed_flower.ratedCOP.to_f         
              og_eer = standard.cop_to_eer(og_cop.to_f)
              # puts "og_eer"
              # puts og_eer
              # report initial condition of model
              runner.registerInitialCondition("The #{flower_space.name} started with an #{og_eer} rated EER")
              # check the user input rating category to define the conversion to cooling coil COP
              if rating_category == "EER"
                puts "converted user_input_cop"
                user_input_cop = standard.eer_to_cop(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_flower.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_flower
                runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated EER")
              elsif rating_category == "SEER"
                puts "converted user_input_cop"
                user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_flower.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_flower
                runner.registerFinalCondition("the #{flower_space.name} got assigned an #{rating_input} rated SEER")
              end
            end
            # puts "this one is flower_psz_ac"
            # puts flower_psz_ac

          end
        # else
        #   # i=1
        #   puts i
        #   puts "name did not match"
        #   puts psz_ac.name.get
        #   i=i+1
        end
      end

    end #ends the system type if / elsif combos

    # begin copy for veg space
    # for PTHP, WSHP, VRF use the zone to access the Cooling coil objects for editing
    zone_cool_equips = veg_thermal_zone.equipmentInCoolingOrder
    # zone_cool_equips = []
    # the .equipmentInCoolingOrder is a SDK method for getting the cooling equipment from a specified zone
    # https://openstudio-sdk-documentation.s3.amazonaws.com/cpp/OpenStudio-3.3.0-doc/model/html/classopenstudio_1_1model_1_1_thermal_zone.html#ad7737f66d8d1a1f761a3c18fc1bdd835
    # it returns an array in the case that multiple objects to exsit

    if system_type == "PTHP"
      #this loops through the zone_cool_equips array and objectType cast checks for whether the object exists
      zone_cool_equips.each do |pthp|
        if !pthp.to_ZoneHVACPackagedTerminalHeatPump.empty?
          puts "made it here on passing the not empty check"
          pthp_veg = pthp.to_ZoneHVACPackagedTerminalHeatPump.get
          # once the zone_pthp is discovered and cast then the related cooling coil is obtained
          coil_cooling_dx_single_speed_veg = pthp_veg.coolingCoil
          # use and .empty? check before acting upon the model.objectType
          if !coil_cooling_dx_single_speed_veg.to_CoilCoolingDXSingleSpeed.empty?
            #cast into a useable using the to_ObjectType.get 
            coil_cooling_dx_single_speed_veg=coil_cooling_dx_single_speed_veg.to_CoilCoolingDXSingleSpeed.get
            og_cop = coil_cooling_dx_single_speed_veg.ratedCOP.to_f         
            og_eer = standard.cop_to_eer(og_cop.to_f)
            # puts "og_eer"
            # puts og_eer
            # report initial condition of model
            runner.registerInitialCondition("The #{veg_space.name} started with an #{og_eer} rated EER")
            # check the user input for rating category to define the conversion to cooling coil COP
            if rating_category == "EER"
              puts "converted user_input_cop"
              user_input_cop = standard.eer_to_cop(rating_input)
              puts user_input_cop
              coil_cooling_dx_single_speed_veg.setRatedCOP(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_dx_single_speed_veg
              runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated EER")
            elsif rating_category == "SEER"
              puts "converted user_input_cop"
              user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
              puts user_input_cop
              coil_cooling_dx_single_speed_veg.setRatedCOP(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_dx_single_speed_veg
              runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated SEER")
            end
          end

        

        else
          puts "array looping check is not working"
        end
      end
    elsif system_type == "Residential heat pump"
      # zone_cool_equips.each do |res_hp|
      # instead of the zone_cool_equips based off of the ThermalZone.equipmentInCoolingOrder method
      # thermal zone > airloop > AirLoopUnitarySytem
      res_hp_airloop = veg_thermal_zone.airLoopHVACs
      # puts "*********************  this is thermal zone > airLoopHVACs"
      # puts "res_hp_airloop"
      # puts res_hp_airloop
      # puts " **********************"
      # puts "us = model.AirLoopHVACUnitarySystems.get"
      us = model.getAirLoopHVACUnitarySystems
      # puts us
      puts "***********************************"
      puts "tzs = s.each do |u|
      tz = u.controllingZoneorThermostatLocation.get"
      # tzs = []
      us.each do |u|
        tz = u.controllingZoneorThermostatLocation.get
        puts tz.name.get
        if tz.name.get.match(veg_thermal_zone.name.to_s)
          coil_cooling_dx_single_speed_veg = u.coolingCoil.get
          puts coil_cooling_dx_single_speed_veg
          if !coil_cooling_dx_single_speed_veg.to_CoilCoolingDXSingleSpeed.empty?
            coil_cooling_dx_single_speed_veg=coil_cooling_dx_single_speed_veg.to_CoilCoolingDXSingleSpeed.get
            puts "***********************************************"
            puts "after the empty check on coil_cooling...." 
            puts coil_cooling_dx_single_speed_veg
                og_cop = coil_cooling_dx_single_speed_veg.ratedCOP.to_f         
                og_eer = standard.cop_to_eer(og_cop.to_f)
            # puts tzs
            runner.registerInitialCondition("The #{veg_space.name} started with an #{og_eer} rated EER")
              if rating_category == "EER"
                puts "converted user_input_cop"
                user_input_cop = standard.eer_to_cop(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_veg.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_veg
                runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated EER")
              elsif rating_category == "SEER"
                puts "converted user_input_cop"
                user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_veg.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_veg
                runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated SEER")
              end
          end     # tzs << tz
        end
      end

     
    elsif system_type == "Water source heat pumps fluid cooler with boiler"
      #this loops through the zone_cool_equips array and objectType cast checks for whether the object exists
      zone_cool_equips.each do |wshp|
        if !wshp.to_ZoneHVACWaterToAirHeatPump.empty?
          puts "made it here on passing the not empty check"
          wshp_veg = wshp.to_ZoneHVACWaterToAirHeatPump.get
          # obtain the CoilCoolingWaterToAirHeatPumpEquationFit
          coil_cooling_water_to_air_heat_pump_equation_fit = wshp_veg.coolingCoil
          if !coil_cooling_water_to_air_heat_pump_equation_fit.to_CoilCoolingWaterToAirHeatPumpEquationFit.empty?
            coil_cooling_water_to_air_heat_pump_equation_fit=coil_cooling_water_to_air_heat_pump_equation_fit.to_CoilCoolingWaterToAirHeatPumpEquationFit.get
            og_cop = coil_cooling_water_to_air_heat_pump_equation_fit.ratedCoolingCoefficientofPerformance.to_f
            og_eer = standard.cop_to_eer(og_cop.to_f)
            runner.registerInitialCondition("The #{veg_space.name} started with an #{og_eer} rated EER")
            if rating_category == "EER"
              puts "converted user_input_cop"
              user_input_cop = standard.eer_to_cop(rating_input)
              puts user_input_cop
              coil_cooling_water_to_air_heat_pump_equation_fit.setRatedCoolingCoefficientofPerformance(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_water_to_air_heat_pump_equation_fit
              runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated EER")
            elsif rating_category == "SEER"
              puts "converted user_input_cop"
              user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
              puts user_input_cop
              coil_cooling_water_to_air_heat_pump_equation_fit.setRatedCoolingCoefficientofPerformance(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_dx_single_speed_veg
              runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated SEER")
            end
          end
          else
          puts "array looping check is not working"
        end
      end
    elsif system_type == "Water source heat pumps fluid cooler with boiler"
      #this loops through the zone_cool_equips array and objectType cast checks for whether the object exists
      zone_cool_equips.each do |wshp|
        if !wshp.to_ZoneHVACWaterToAirHeatPump.empty?
          puts "made it here on passing the not empty check"
          wshp_veg = wshp.to_ZoneHVACWaterToAirHeatPump.get
          # obtain the CoilCoolingWaterToAirHeatPumpEquationFit
          coil_cooling_water_to_air_heat_pump_equation_fit = wshp_veg.coolingCoil
          if !coil_cooling_water_to_air_heat_pump_equation_fit.to_CoilCoolingWaterToAirHeatPumpEquationFit.empty?
            coil_cooling_water_to_air_heat_pump_equation_fit=coil_cooling_water_to_air_heat_pump_equation_fit.to_CoilCoolingWaterToAirHeatPumpEquationFit.get
            og_cop = coil_cooling_water_to_air_heat_pump_equation_fit.ratedCoolingCoefficientofPerformance.to_f
            og_eer = standard.cop_to_eer(og_cop.to_f)
            runner.registerInitialCondition("The #{veg_space.name} started with an #{og_eer} rated EER")
            if rating_category == "EER"
              puts "converted user_input_cop"
              user_input_cop = standard.eer_to_cop(rating_input)
              puts user_input_cop
              coil_cooling_water_to_air_heat_pump_equation_fit.setRatedCoolingCoefficientofPerformance(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_water_to_air_heat_pump_equation_fit
              runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated EER")
            elsif rating_category == "SEER"
              puts "converted user_input_cop"
              user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
              puts user_input_cop
              coil_cooling_water_to_air_heat_pump_equation_fit.setRatedCoolingCoefficientofPerformance(user_input_cop)
              puts "coil after assignment"
              puts coil_cooling_dx_single_speed_veg
              runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated SEER")
            end
          end
          else
          puts "array looping check is not working"
        end
      end
    elsif system_type == "PTAC with gas unit heaters"
      zone_cool_equips.each do |ptac|
        if !ptac.to_ZoneHVACPackagedTerminalAirConditioner.empty?
          puts "made it here on passing the not empty check"
          ptac_veg = ptac.to_ZoneHVACPackagedTerminalAirConditioner.get
           # once the zone_pthp is discovered and cast then the related cooling coil is obtained
           coil_cooling_dx_single_speed_veg = ptac_veg.coolingCoil
           # use and .empty? check before acting upon the model.objectType
           if !coil_cooling_dx_single_speed_veg.to_CoilCoolingDXSingleSpeed.empty?
             #cast into a useable using the to_ObjectType.get 
             coil_cooling_dx_single_speed_veg=coil_cooling_dx_single_speed_veg.to_CoilCoolingDXSingleSpeed.get
             og_cop = coil_cooling_dx_single_speed_veg.ratedCOP.to_f         
             og_eer = standard.cop_to_eer(og_cop.to_f)
             # puts "og_eer"
             # puts og_eer
             # report initial condition of model
             runner.registerInitialCondition("The #{veg_space.name} started with an #{og_eer} rated EER")
             # check the user input for rating category to define the conversion to cooling coil COP
             if rating_category == "EER"
               puts "converted user_input_cop"
               user_input_cop = standard.eer_to_cop(rating_input)
               puts user_input_cop
               coil_cooling_dx_single_speed_veg.setRatedCOP(user_input_cop)
               puts "coil after assignment"
               puts coil_cooling_dx_single_speed_veg
               runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated EER")
              elsif rating_category == "SEER"
                puts "converted user_input_cop"
                user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_veg.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_veg
                runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated SEER")
             end
           end
 
         
 
         else
           puts "array looping check is not working"
         end
       end
    elsif system_type == "VRF"
      runner.registerInfo("VRF not supported for COP/EER adjustment currently: curves are complex and remain default")
      return false

    # for the chiller systems use the getChiller method directly - this assumes only one chiller comes from Create_Typical
    # if the use case changes to multiple runs of Create_Typical then this measure will have to as well.
    elsif system_type == "Fan coil air-cooled chiller with boiler"
      all_chillers = model.getChillerElectricEIRs
        all_chillers.each do |chiller|
          og_cop = chiller.referenceCOP.to_f
          og_eer = standard.cop_to_eer(og_cop.to_f)
          runner.registerInitialCondition("The #{veg_space.name} started with an #{og_eer} rated EER")
          if rating_category == "EER"
            puts "converted user_input_cop"
            user_input_cop = standard.eer_to_cop(rating_input)
            puts user_input_cop
            chiller.setReferenceCOP(user_input_cop)
            puts "chiller after assignment"
            puts chiller
            runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated EER")
          elsif rating_category == "SEER"
            puts "converted user_input_cop"
            user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
            puts user_input_cop
            chiller.setReferenceCOP(user_input_cop)
            puts "chiller after assignment"
            puts chiller
            runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated SEER")
          end
        end
      # this is the second of the two chiller options
    elsif system_type == "Fan coil chiller with boiler"
      all_chillers = model.getChillerElectricEIRs
        all_chillers.each do |chiller|
          og_cop = chiller.referenceCOP.to_f
          og_eer = standard.cop_to_eer(og_cop.to_f)
          runner.registerInitialCondition("The #{veg_space.name} started with an #{og_eer} rated EER")
          if rating_category == "EER"
            puts "converted user_input_cop"
            user_input_cop = standard.eer_to_cop(rating_input)
            puts user_input_cop
            chiller.setReferenceCOP(user_input_cop)
            puts "chiller after assignment"
            puts chiller
            runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated EER")
          elsif rating_category == "SEER"
            puts "converted user_input_cop"
            user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
            puts user_input_cop
            chiller.setReferenceCOP(user_input_cop)
            puts "chiller after assignment"
            puts chiller
            runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated SEER")
          end
        end
    # for the PSZ-AC system this will access the Air Loop Unitary system directly
    # uses a name.get.match check to verify that the "space_name" is used to choose only a specific PSZ
    elsif system_type == "PSZ-AC with gas coil"
      # i = 1
      zone_air_loops_unitary_system = model.getAirLoopHVACUnitarySystems
      zone_air_loops_unitary_system.each do |psz_ac|
        if psz_ac.name.get.match("Zone - #{veg_space.name} PSZ-AC Unitary AC")
          if !psz_ac.to_AirLoopHVACUnitarySystem.empty?
            veg_psz_ac = psz_ac.to_AirLoopHVACUnitarySystem.get
            # puts veg_psz_ac
            coil_cooling_dx_single_speed_veg = veg_psz_ac.coolingCoil.get
            # puts coil_cooling_dx_single_speed_veg
            if !coil_cooling_dx_single_speed_veg.to_CoilCoolingDXSingleSpeed.empty?
              coil_cooling_dx_single_speed_veg=coil_cooling_dx_single_speed_veg.to_CoilCoolingDXSingleSpeed.get
              og_cop = coil_cooling_dx_single_speed_veg.ratedCOP.to_f         
              og_eer = standard.cop_to_eer(og_cop.to_f)
              # puts "og_eer"
              # puts og_eer
              # report initial condition of model
              runner.registerInitialCondition("The #{veg_space.name} started with an #{og_eer} rated EER")
              # check the user input rating category to define the conversion to cooling coil COP
              if rating_category == "EER"
                puts "converted user_input_cop"
                user_input_cop = standard.eer_to_cop(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_veg.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_veg
                runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated EER")
              elsif rating_category == "SEER"
                puts "converted user_input_cop"
                user_input_cop = standard.seer_to_cop_cooling_with_fan(rating_input)
                puts user_input_cop
                coil_cooling_dx_single_speed_veg.setRatedCOP(user_input_cop)
                puts "coil after assignment"
                puts coil_cooling_dx_single_speed_veg
                runner.registerFinalCondition("the #{veg_space.name} got assigned an #{rating_input} rated SEER")


              end
            end
            # puts "this one is veg_psz_ac"
            # puts veg_psz_ac

          end
        # else
        #   # i=1
        #   puts i
        #   puts "name did not match"
        #   puts psz_ac.name.get
        #   i=i+1
        end
      end

    end #ends the system type if / elsif combos
    # end
    # report final condition of model
    # runner.registerFinalCondition("The building finished with #{model.getCoilCoolingDXSingleSpeeds.size} Coil:CoolingDX:SingleSpeed objects.")

    return true
  end
end

# register the measure to be used by the application
CeaCustomizeCoolEquipCop.new.registerWithApplication
