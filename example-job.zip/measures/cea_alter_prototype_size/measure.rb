# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CeaAlterPrototypeSize < OpenStudio::Ruleset::ModelUserScript

  ## helper methods ##
  
    def neat_numbers(number, roundto = 2) #round to 2 decimals
      if roundto == 2
        number = sprintf "%.2f", number
      else
        number = number.round
      end
      #regex to add commas
      number.to_s.reverse.gsub(%r{([0-9]{3}(?=([0-9])))}, "\\1,").reverse
    end #end def neat_numbers
  
    
    def change_zone_multiplier(zone_name, zone_multiplier, model, runner)
      obj_type = OpenStudio::Model::ThermalZone::iddObjectType
    zone = model.getObjectByTypeAndName(obj_type, zone_name).get.to_ThermalZone.get
    init_mult = zone.multiplier
    zone.setMultiplier(zone_multiplier)
    
    # write info message describing change to thermal zone multiplier 
    runner.registerInfo("The Thermal Zone multiplier for the zone named #{zone.name} has been set from #{init_mult} to #{zone_multiplier}.")
    end 
  
    ## end of helper methods ##
    
    
    # human readable name
    def name
      return "CeaAlterPrototypeSize"
    end
  
    # human readable description
    def description
      return "Used the scale building surfaces approach, but does some accounting for the original buildling the template was based off of and then switch to account for Zone mulitipliers on the culitvation rooms."
    end
  
    # human readable description of modeling approach
    def modeler_description
      return "ipsum"
    end
  
    # define the arguments that the user will input
    def arguments(model)
      args = OpenStudio::Ruleset::OSArgumentVector.new
      

      desired_total_sqft = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("desired_total_sqft", true)
      desired_total_sqft.setDisplayName("Total Building size ")
      desired_total_sqft.setDefaultValue(32000)
      args << desired_total_sqft
  

      return args
    end
  
    # define what happens when the measure is run
    def run(model, runner, user_arguments)
      super(model, runner, user_arguments)
  
      # use the built-in error checking
      if !runner.validateUserArguments(arguments(model), user_arguments)
        return false
      end
  
      # assign the user inputs to variables
      desired_total_sqft = runner.getDoubleArgumentValue("desired_total_sqft", user_arguments)

    
    # hard code z_scale_factor = 1.0
      z_scale_factor = 1.0

      building = model.getBuilding
      building_area = building.floorArea

      # building_area_ft2 = OpenStudio.convert(building_area, 'm^2', 'ft^2').get

      unit_area_si = OpenStudio.createUnit('m^2').get
      unit_area_ip = OpenStudio.createUnit('ft^2').get

      orig_area_si = OpenStudio::Quantity.new(building_area, unit_area_si)
      building_area_ft2 = OpenStudio.convert(orig_area_si, unit_area_ip).get

      puts "original building_area_ft2"
      puts building_area_ft2

      total_prototypical_area = building_area_ft2.value + 20000 # This additional 20,000 sqft is added to represent the space in the original building that becomes accounted for by a zone multiplier on the flower and veg areas
      
      puts "total_prototypical_area"
      puts total_prototypical_area

      puts "desired_total_sqft"
      puts desired_total_sqft

      x_scale_factor_inv = Math.sqrt(total_prototypical_area/desired_total_sqft)
      y_scale_factor_inv = Math.sqrt(total_prototypical_area/desired_total_sqft)

      x_scale_factor = 1 / x_scale_factor_inv
      y_scale_factor = 1 / y_scale_factor_inv

      puts(x_scale_factor)
      puts(y_scale_factor)
      
  
      
      # report initial condition of model
    runner.registerInitialCondition("The non-zone multiplier portion of the building started with a floor area of #{neat_numbers(OpenStudio.convert(model.getBuilding.floorArea, "m^2", "ft^2").get,0)} ft^2.")
  
    # retrieves all (apaces, shading surface groups and interior partition surface groups) in the model and modifies the origin 
      model.getPlanarSurfaceGroups.each do |group|
        group.setXOrigin(x_scale_factor * group.xOrigin)
        group.setYOrigin(y_scale_factor * group.yOrigin)
        group.setZOrigin(z_scale_factor * group.zOrigin)
      end
    
    # retrieves all (Interior Partition Surfaces, Shading Surfaces, Subsurfaces ans Surfaces) in the model and modify the existing x,y,z verticies by the user-defined scale factor 
      model.getPlanarSurfaces.each do |surface|
        vertices = surface.vertices
        new_vertices = OpenStudio::Point3dVector.new
        vertices.each do |vertex|
          new_vertices << OpenStudio::Point3d.new(x_scale_factor * vertex.x, y_scale_factor * vertex.y, z_scale_factor * vertex.z)
        end
        surface.setVertices(new_vertices)
      end
  
    # retrieve all daylighting controls in the model and modify the existing x,y,z verticies by the user-defined scale factors
      model.getDaylightingControls.each do |control|
        control.setPositionXCoordinate(x_scale_factor * control.positionXCoordinate)
        control.setPositionYCoordinate(y_scale_factor * control.positionYCoordinate)
        control.setPositionZCoordinate(z_scale_factor * control.positionZCoordinate)
      end
    
    # retrieve all glare sensors in the model and modify the existing x,y,z sensor position by the user-defined scale factors
      model.getGlareSensors.each do |sensor|
        sensor.setPositionXCoordinate(x_scale_factor * sensor.positionXCoordinate)
        sensor.setPositionYCoordinate(y_scale_factor * sensor.positionYCoordinate)
        sensor.setPositionZCoordinate(z_scale_factor * sensor.positionZCoordinate)
      end
      
    # retrieve all glare sensors in the model and modify the existing x,y,z origin position by the user-defined scale factors
      model.getGlareSensors.each do |map|
        map.setOriginXCoordinate(x_scale_factor * map.originXCoordinate)
        map.setOriginYCoordinate(y_scale_factor * map.originYCoordinate)
        map.setXLength(x_scale_factor * map.xLength)
        map.setYLength(y_scale_factor * map.yLength)
      end
  
    # report changes made by measure
    runner.registerInfo("An X-scale factor of #{x_scale_factor} was applied to the model geometry, including modifying any daylight control and glare sensor locations.")
    runner.registerInfo("An Y-scale factor of #{y_scale_factor} was applied to the model geometry, including modifying any daylight control and glare sensor locations.")
    
      
      # report final condition of model
      runner.registerFinalCondition("The non-zone multiplier portion of the building finished with a floor area of #{neat_numbers(OpenStudio.convert(model.getBuilding.floorArea, "m^2", "ft^2").get,0)} ft^2.")
      return true
  
    end # end run method
    
  end # end class 
    
  # register the measure to be used by the application
  CeaAlterPrototypeSize.new.registerWithApplication
  