# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CeaIndoorAddWatering < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'cea_indoor_add_watering'
  end

  # human readable description
  def description
    return 'Represents a horticultural watering rate added to the Cultivation Space'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'add Wateruse:Equipment:Definition, WaterUse:Equpiment, Schedule:Ruleset (plus days), Target Temp Schedule, Sensible Fraction Schedule, Latent Fraction Schedules, '
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # make a choice argument for model objects
    space_handles = OpenStudio::StringVector.new
    space_display_names = OpenStudio::StringVector.new

    # putting model object and names into hash
    space_args = model.getSpaces
    space_args_hash = {}
    space_args.each do |space_arg|
      space_args_hash[space_arg.name.to_s] = space_arg
    end

    # looping through sorted hash of model objects
    space_args_hash.sort.map do |key, value|
      space_handles << value.handle.to_s
      space_display_names << key
    end


    # make a choice argument for space type or entire building
    veg_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('veg_space', space_handles, space_display_names, true)
    veg_space.setDisplayName('Choose a veg space')
    args << veg_space
    flower_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('flower_space', space_handles, space_display_names, true)
    flower_space.setDisplayName('Choose a flower space')
    args << flower_space

    veg_size_sqft = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("veg_size_sqft", true)
    veg_size_sqft.setDisplayName("veg room Size [sqft]")
    veg_size_sqft.setDefaultValue(1600)
    args << veg_size_sqft

    flower_size_sqft = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("flower_size_sqft", true)
    flower_size_sqft.setDisplayName("flower room Size [sqft]")
    flower_size_sqft.setDefaultValue(1600)
    args << flower_size_sqft

    veg_gph = OpenStudio::Measure::OSArgument.makeDoubleArgument('veg_gph', true)
    veg_gph.setDisplayName("Veg Watering Rate")
    veg_gph.setDefaultValue(0)
    args << veg_gph
    flower_gph = OpenStudio::Measure::OSArgument.makeDoubleArgument('flower_gph', true)
    flower_gph.setDisplayName("Flower Watering Rate")
    flower_gph.setDefaultValue(0)
    args << flower_gph
    # Adding in the septoint schedule selection criteria to streamline measure
    setpoint_schedules = OpenStudio::StringVector.new
    setpoint_schedules_handles = OpenStudio::StringVector.new

    setpoint_schedules_args = model.getScheduleRulesets
    setpoint_schedules_args_hash = {}
    setpoint_schedules_args.each do |setpoint_schedules_arg|
      setpoint_schedules_args_hash[setpoint_schedules_arg.name.to_s] = setpoint_schedules_arg
    end
    # Loop through the hash to pull out the hash and name value to align display name and hash value
    setpoint_schedules_args_hash.sort.map do |key, value|
      setpoint_schedules_handles << value.handle.to_s
      setpoint_schedules << key
    end

    horticulture_watering_schedule = OpenStudio::Measure::OSArgument::makeChoiceArgument('horticulture_watering_schedule',setpoint_schedules_handles,setpoint_schedules,true)
    horticulture_watering_schedule.setDisplayName('Choose the Watering Schedule')
    args << horticulture_watering_schedule

    horticulture_watering_temperature_schedule = OpenStudio::Measure::OSArgument::makeChoiceArgument('horticulture_watering_temperature_schedule',setpoint_schedules_handles,setpoint_schedules,true)
    horticulture_watering_temperature_schedule.setDisplayName('Choose the watering temperature schedule')
    args << horticulture_watering_temperature_schedule
    
    horticulture_watering_fractionlatent_schedule = OpenStudio::Measure::OSArgument::makeChoiceArgument('horticulture_watering_fractionlatent_schedule',setpoint_schedules_handles,setpoint_schedules,true)
    horticulture_watering_fractionlatent_schedule.setDisplayName('choose the watering fraction latent schedule')
    args << horticulture_watering_fractionlatent_schedule

    horticulture_watering_fractionsensible_schedule = OpenStudio::Measure::OSArgument::makeChoiceArgument('horticulture_watering_fractionsensible_schedule',setpoint_schedules_handles,setpoint_schedules,true)
    horticulture_watering_fractionsensible_schedule.setDisplayName('choose the watering fraction sensible schedule')
    args << horticulture_watering_fractionsensible_schedule

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    veg_space = runner.getOptionalWorkspaceObjectChoiceValue('veg_space', user_arguments, model)
    veg_size_sqft = runner.getDoubleArgumentValue('veg_size_sqft', user_arguments)
    veg_gph = runner.getDoubleArgumentValue('veg_gph', user_arguments)

    flower_space = runner.getOptionalWorkspaceObjectChoiceValue('flower_space', user_arguments, model)
    flower_size_sqft = runner.getDoubleArgumentValue('flower_size_sqft', user_arguments)
    flower_gph = runner.getDoubleArgumentValue('flower_gph', user_arguments)
    
    #get the user selected watering schedule names and then cast to type
    horticulture_watering_schedule = runner.getOptionalWorkspaceObjectChoiceValue('horticulture_watering_schedule',user_arguments, model)
    horticulture_watering_temperature_schedule = runner.getOptionalWorkspaceObjectChoiceValue('horticulture_watering_temperature_schedule',user_arguments, model)
    horticulture_watering_fractionlatent_schedule = runner.getOptionalWorkspaceObjectChoiceValue('horticulture_watering_fractionlatent_schedule',user_arguments, model)
    horticulture_watering_fractionsensible_schedule = runner.getOptionalWorkspaceObjectChoiceValue('horticulture_watering_fractionsensible_schedule',user_arguments, model)
        
    #casting (to_ObjectType) is super important!
    horticulture_watering_temperature_schedule = horticulture_watering_temperature_schedule.get.to_ScheduleRuleset.get
    horticulture_watering_fractionlatent_schedule = horticulture_watering_fractionlatent_schedule.get.to_ScheduleRuleset.get
    horticulture_watering_fractionsensible_schedule = horticulture_watering_fractionsensible_schedule.get.to_ScheduleRuleset.get



    # Edit gph based on smart default of 0
    # uses a sample of ~260gallons per day total and a EFLH watering schedule of 4.25 hours for 1900 square feet
    # therefore:
    # gph = 61.1 / 1900 sqft
    
    if veg_gph == 0
      puts "Smart Watering Defaults"
      veg_gph = 61.1 * (veg_size_sqft/ 1900)
      puts veg_gph
    else 
      puts "user entered veg_gph"
      puts veg_gph
    end
    if flower_gph == 0
      puts "Smart Watering Defaults"
      flower_gph = 61.1 * (flower_size_sqft/ 1900)
      puts flower_gph
    else 
      puts "user entered flower_gph"
      puts flower_gph
    end

    #unit conversions
    unit_gph_ip = OpenStudio.createUnit('gal/hr').get
    unit_gph_si = OpenStudio.createUnit('m^3/s').get

    veg_gph_ip = OpenStudio::Quantity.new(veg_gph, unit_gph_ip)
    veg_gph_si = OpenStudio.convert(veg_gph_ip, unit_gph_si).get

    flower_gph_ip = OpenStudio::Quantity.new(flower_gph, unit_gph_ip)
    flower_gph_si = OpenStudio.convert(flower_gph_ip, unit_gph_si).get

    puts "veg converted to:"
    puts veg_gph_si
    puts "m^3/s"

    puts "flower converted to:"
    puts flower_gph_si
    puts "m^3/s"

    if horticulture_watering_schedule.empty?
      handle = runner.getStringArgumentValue("horticulture_watering_schedule", user_arguments)
      if handle.empty?
        runner.registerError("No schedule selected")
      else
        runner.registerError("the selected schedule '#{handle}' was not found")
      end
      return false
    else
      if not horticulture_watering_schedule.get.to_ScheduleRuleset.empty?
        horticulture_watering_schedule = horticulture_watering_schedule.get.to_ScheduleRuleset.get
        # puts "horticulture_watering_schedule after the casting"
        # puts horticulture_watering_schedule
      else
        runner.registerError("Script Error - argument not showing up as a ScheduleRuleset object")
        return false
        
      end
    end

    # cast the object from a hash to a extensible SpaceType object within this model (to_SpaceType.get)
    # once this is complete the object can be acted upon or referenced and connected by other objects within this working model space
    veg_space = veg_space.get.to_Space.get

    #new hot water loop to get the flow
    new_hort_dhw_loop = OpenStudio::Model::PlantLoop.new(model)
    new_hort_dhw_loop.setName("#{veg_space.name} Hort Watering Loop")

    #new plant sizing component
    new_hort_dhw_loop_sizing = OpenStudio::Model::SizingPlant.new(model, new_hort_dhw_loop)
    new_hort_dhw_loop_sizing.setLoopType("Heating")
    new_hort_dhw_loop_sizing.setDesignLoopExitTemperature(23.8889)

    # new_hort_dhw_loop.sizingPlant(new_hort_dhw_loop_sizing)

    puts new_hort_dhw_loop

    puts "*****************************"
    puts new_hort_dhw_loop_sizing

    # new wateruse:connection
    new_hort_wateruse_connections = OpenStudio::Model::WaterUseConnections.new(model)
    new_hort_wateruse_connections.setName("#{veg_space.name} Hort_WateringUseConnection")

    puts "******************************"
    puts new_hort_wateruse_connections


    new_hort_wateruse_equipment_definition = OpenStudio::Model::WaterUseEquipmentDefinition.new(model)
    new_hort_wateruse_equipment_definition.setName("#{veg_space.name} Hort_WaterUEDef")
    new_hort_wateruse_equipment_definition.setPeakFlowRate(veg_gph_si.value)
    new_hort_wateruse_equipment_definition.setTargetTemperatureSchedule(horticulture_watering_temperature_schedule)
    new_hort_wateruse_equipment_definition.setSensibleFractionSchedule(horticulture_watering_fractionsensible_schedule)
    new_hort_wateruse_equipment_definition.setLatentFractionSchedule(horticulture_watering_fractionlatent_schedule)
    new_hort_wateruse_equipment_definition.setEndUseSubcategory("Horticulture Watering")

    puts "******************************"
    puts new_hort_wateruse_equipment_definition
    
    # wuedefs = model.getWaterUseEquipmentDefinitions

    # puts wuedefs

    # puts "**************************"
    # puts gph_si

    # wuedefs.each do |wuedef|
    #   if wuedef.name.get.match("HorticulturalWUDef")
    #     wuedef.setPeakFlowRate(gph_si.value)
    #     puts "***************************** wuedef *******************"
    #     puts wuedef
    #   end
    # end

    new_hort_wateruse_equipment = OpenStudio::Model::WaterUseEquipment.new(new_hort_wateruse_equipment_definition)
    new_hort_wateruse_equipment.setFlowRateFractionSchedule(horticulture_watering_schedule)
    new_hort_wateruse_equipment.setName("#{veg_space.name} Hort_WaterUseEquipment")
    new_hort_wateruse_equipment.setSpace(veg_space)


    puts "*********************************"
    puts new_hort_wateruse_equipment

    # wues = model.getWaterUseEquipments
    # wues.each do |wue|
    #   if wue.name.get.match("HorticulturalWatering")
    #     wue.setFlowRateFractionSchedule(horticulture_watering_schedule)
    #     wue.setSpace(space)
    #     puts "****************************** wue **********************"
    #     puts wue
    #   end
    # end

    
    # connect wateruse equipment to wateruse connections
    new_hort_wateruse_connections.addWaterUseEquipment(new_hort_wateruse_equipment)

    puts "************************************"
    puts new_hort_wateruse_connections

    # connect the wateruse connections to the plant loop
    new_hort_dhw_loop.addDemandBranchForComponent(new_hort_wateruse_connections)

    # add a waterheater to the plant loop
    new_hort_dhw = OpenStudio::Model::WaterHeaterMixed.new(model)
    new_hort_dhw.setName("#{veg_space.name} Hort_WaterHeaterMixed")
    new_hort_dhw.setSetpointTemperatureSchedule(horticulture_watering_temperature_schedule)
    new_hort_dhw.setHeaterMaximumCapacity(1) #value to zero out any water heating associated
    new_hort_dhw.setTankVolume(0.454249414076382) #set to approx 120 gal for no good reason

    puts "***************************************"
    puts new_hort_dhw

    # connect the waterheater to the plant loop

    new_hort_dhw_loop.addSupplyBranchForComponent(new_hort_dhw)



    # add a pump

    new_hort_dhw_loop_pump = OpenStudio::Model::PumpConstantSpeed.new(model)
    new_hort_dhw_loop_pump.setName("#{veg_space.name} Hort_Pump")
    new_hort_dhw_loop_pump.setRatedPumpHead(32) #Pascals a super small number to near zero the pump power



    # add a setpoint manager with the temperature schedule
    new_hort_dhw_loop_spmngr = OpenStudio::Model::SetpointManagerScheduled.new(model, horticulture_watering_temperature_schedule)
    new_hort_dhw_loop_spmngr.setName("#{veg_space.name} Hort_WateringLoop_SetpointManager")
    new_hort_dhw_loop_spmngr.setControlVariable('Temperature')
    # new_hort_dhw_loop_spmngr.setSchedule(horticulture_watering_temperature_schedule)

    new_hort_dhw_loop_spmngr.addToNode(new_hort_dhw_loop.supplyOutletNode)

    new_hort_dhw_loop_pump.addToNode(new_hort_dhw_loop.supplyInletNode)


    puts "************************************"
    puts new_hort_dhw_loop

    # Copy from above for Flower

    # cast the object from a hash to a extensible SpaceType object within this model (to_SpaceType.get)
    # once this is complete the object can be acted upon or referenced and connected by other objects within this working model space
    flower_space = flower_space.get.to_Space.get

    #new hot water loop to get the flow
    new_hort_dhw_loop = OpenStudio::Model::PlantLoop.new(model)
    new_hort_dhw_loop.setName("#{flower_space.name} Hort Watering Loop")

    #new plant sizing component
    new_hort_dhw_loop_sizing = OpenStudio::Model::SizingPlant.new(model, new_hort_dhw_loop)
    new_hort_dhw_loop_sizing.setLoopType("Heating")
    new_hort_dhw_loop_sizing.setDesignLoopExitTemperature(23.8889)

    # new_hort_dhw_loop.sizingPlant(new_hort_dhw_loop_sizing)

    puts new_hort_dhw_loop

    puts "*****************************"
    puts new_hort_dhw_loop_sizing

    # new wateruse:connection
    new_hort_wateruse_connections = OpenStudio::Model::WaterUseConnections.new(model)
    new_hort_wateruse_connections.setName("#{flower_space.name} Hort_WateringUseConnection")

    puts "******************************"
    puts new_hort_wateruse_connections


    new_hort_wateruse_equipment_definition = OpenStudio::Model::WaterUseEquipmentDefinition.new(model)
    new_hort_wateruse_equipment_definition.setName("#{flower_space.name} Hort_WaterUEDef")
    new_hort_wateruse_equipment_definition.setPeakFlowRate(flower_gph_si.value)
    new_hort_wateruse_equipment_definition.setTargetTemperatureSchedule(horticulture_watering_temperature_schedule)
    new_hort_wateruse_equipment_definition.setSensibleFractionSchedule(horticulture_watering_fractionsensible_schedule)
    new_hort_wateruse_equipment_definition.setLatentFractionSchedule(horticulture_watering_fractionlatent_schedule)
    new_hort_wateruse_equipment_definition.setEndUseSubcategory("Horticulture Watering")

    puts "******************************"
    puts new_hort_wateruse_equipment_definition
    
    # wuedefs = model.getWaterUseEquipmentDefinitions

    # puts wuedefs

    # puts "**************************"
    # puts gph_si

    # wuedefs.each do |wuedef|
    #   if wuedef.name.get.match("HorticulturalWUDef")
    #     wuedef.setPeakFlowRate(gph_si.value)
    #     puts "***************************** wuedef *******************"
    #     puts wuedef
    #   end
    # end

    new_hort_wateruse_equipment = OpenStudio::Model::WaterUseEquipment.new(new_hort_wateruse_equipment_definition)
    new_hort_wateruse_equipment.setFlowRateFractionSchedule(horticulture_watering_schedule)
    new_hort_wateruse_equipment.setName("#{flower_space.name} Hort_WaterUseEquipment")
    new_hort_wateruse_equipment.setSpace(flower_space)


    puts "*********************************"
    puts new_hort_wateruse_equipment

    # wues = model.getWaterUseEquipments
    # wues.each do |wue|
    #   if wue.name.get.match("HorticulturalWatering")
    #     wue.setFlowRateFractionSchedule(horticulture_watering_schedule)
    #     wue.setSpace(space)
    #     puts "****************************** wue **********************"
    #     puts wue
    #   end
    # end

    
    # connect wateruse equipment to wateruse connections
    new_hort_wateruse_connections.addWaterUseEquipment(new_hort_wateruse_equipment)

    puts "************************************"
    puts new_hort_wateruse_connections

    # connect the wateruse connections to the plant loop
    new_hort_dhw_loop.addDemandBranchForComponent(new_hort_wateruse_connections)

    # add a waterheater to the plant loop
    new_hort_dhw = OpenStudio::Model::WaterHeaterMixed.new(model)
    new_hort_dhw.setName("#{flower_space.name} Hort_WaterHeaterMixed")
    new_hort_dhw.setSetpointTemperatureSchedule(horticulture_watering_temperature_schedule)
    new_hort_dhw.setHeaterMaximumCapacity(1) #value to zero out any water heating associated
    new_hort_dhw.setTankVolume(0.454249414076382) #set to approx 120 gal for no good reason

    puts "***************************************"
    puts new_hort_dhw

    # connect the waterheater to the plant loop

    new_hort_dhw_loop.addSupplyBranchForComponent(new_hort_dhw)



    # add a pump

    new_hort_dhw_loop_pump = OpenStudio::Model::PumpConstantSpeed.new(model)
    new_hort_dhw_loop_pump.setName("#{flower_space.name} Hort_Pump")
    new_hort_dhw_loop_pump.setRatedPumpHead(32) #Pascals a super small number to near zero the pump power



    # add a setpoint manager with the temperature schedule
    new_hort_dhw_loop_spmngr = OpenStudio::Model::SetpointManagerScheduled.new(model, horticulture_watering_temperature_schedule)
    new_hort_dhw_loop_spmngr.setName("#{flower_space.name} Hort_WateringLoop_SetpointManager")
    new_hort_dhw_loop_spmngr.setControlVariable('Temperature')
    # new_hort_dhw_loop_spmngr.setSchedule(horticulture_watering_temperature_schedule)

    new_hort_dhw_loop_spmngr.addToNode(new_hort_dhw_loop.supplyOutletNode)

    new_hort_dhw_loop_pump.addToNode(new_hort_dhw_loop.supplyInletNode)


    puts "************************************"
    puts new_hort_dhw_loop




    

    return true
  end
end

# register the measure to be used by the application
CeaIndoorAddWatering.new.registerWithApplication
