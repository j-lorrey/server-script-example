

###### (Automatically generated documentation)

# cea_indoor_add_watering

## Description
Represents a horticultural watering rate added to the Cultivation Space

## Modeler Description
add Wateruse:Equipment:Definition, WaterUse:Equpiment, Schedule:Ruleset (plus days), Target Temp Schedule, Sensible Fraction Schedule, Latent Fraction Schedules, 

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose a veg space

**Name:** veg_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose a flower space

**Name:** flower_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### veg room Size [sqft]

**Name:** veg_size_sqft,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### flower room Size [sqft]

**Name:** flower_size_sqft,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Veg Watering Rate

**Name:** veg_gph,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Flower Watering Rate

**Name:** flower_gph,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose the Watering Schedule

**Name:** horticulture_watering_schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose the watering temperature schedule

**Name:** horticulture_watering_temperature_schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### choose the watering fraction latent schedule

**Name:** horticulture_watering_fractionlatent_schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### choose the watering fraction sensible schedule

**Name:** horticulture_watering_fractionsensible_schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false




