

###### (Automatically generated documentation)

# Enable Economizer Control_withDiffs

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Economizer Control Type

**Name:** economizer_type,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Economizer Maximum Limit Dry-Bulb Temperature (F).

**Name:** econoMaxDryBulbTemp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Economizer Minimum Limit Dry-Bulb Temperature (F).

**Name:** econoMinDryBulbTemp,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




