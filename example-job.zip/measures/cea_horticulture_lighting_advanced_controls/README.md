

###### (Automatically generated documentation)

# cea_horticulture_lighting_advanced_controls

## Description
Sometime cultivators will used lighting controls to either trim down the full output percentage of the installed lighting, or institute a ramping on and off of the fixtures, called bedding cycles.  This measures has arguments that will allow entry of either a dimming percentage or a yes or no argument for bedding cycles.  Bedding cycles will only be applied to the flower room at this point.  Currently bedding cylce ramp is a 30% decrease in output that takes two hours.  

TODO: expand to any of the cultivation chambers.   

## Modeler Description
UI arguments will just be an integer for the full trim option - with a 0 smart default that just skips the feature - and a yes/no choice for whether or not to apply bedding cycles.   An additional argument will be included in the workflow for space assignment and schedule assignment.  A new schedule resources -with bedding cycle- is added to sedd model.  When yes the schedule will be swapped in the space type assignment for the flower spaces.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose a veg space

**Name:** veg_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** []


### Choose a flower space

**Name:** flower_space,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** []


### Choose the bedding Lighting Schedule

**Name:** flower_lighting_schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

**Choice Display Names** []


### Enter a multiplier for Full Power Trim
This value represents a mulitiplier eg 80% = 0.80 of full power for the Lighting Power within that space.  It works by trimming a specific lighting day schedule
**Name:** trim_value,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false


### Yes/No string argument for applying bedding cyle

**Name:** bedding_cycle_input,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false






