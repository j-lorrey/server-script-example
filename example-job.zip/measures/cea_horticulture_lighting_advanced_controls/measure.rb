# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class CeaHorticultureLightingAdvancedControls < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'cea_horticulture_lighting_advanced_controls'
  end

  # human readable description
  def description
    return 'Sometime cultivators will used lighting controls to either trim down the full output percentage of the installed lighting, or institute a ramping on and off of the fixtures, called bedding cycles.  This measures has arguments that will allow entry of either a dimming percentage or a yes or no argument for bedding cycles.  Bedding cycles will only be applied to the flower room at this point.  Currently bedding cylce ramp is a 30% decrease in output that takes two hours.  

TODO: expand to any of the cultivation chambers.   '
  end

  # human readable description of modeling approach
  def modeler_description
    return 'UI arguments will just be an integer for the full trim option - with a 0 smart default that just skips the feature - and a yes/no choice for whether or not to apply bedding cycles.   An additional argument will be included in the workflow for space assignment and schedule assignment.  A new schedule resources -with bedding cycle- is added to sedd model.  When yes the schedule will be swapped in the space type assignment for the flower spaces.'
  end

  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

      # make a choice argument for model objects
      space_handles = OpenStudio::StringVector.new
      space_display_names = OpenStudio::StringVector.new
  
      # putting model object and names into hash
      space_args = model.getSpaces
      space_args_hash = {}
      space_args.each do |space_arg|
        space_args_hash[space_arg.name.to_s] = space_arg
      end
  
      # looping through sorted hash of model objects
      space_args_hash.sort.map do |key, value|
        space_handles << value.handle.to_s
        space_display_names << key
      end
  
      # make a choice argument for space type or entire building
      veg_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('veg_space', space_handles, space_display_names, true)
      veg_space.setDisplayName('Choose a veg space')
      args << veg_space
      flower_space = OpenStudio::Measure::OSArgument.makeChoiceArgument('flower_space', space_handles, space_display_names, true)
      flower_space.setDisplayName('Choose a flower space')
      args << flower_space
      # Adding in the septoint schedule selection criteria to streamline measure
      setpoint_schedules = OpenStudio::StringVector.new
      setpoint_schedules_handles = OpenStudio::StringVector.new

      setpoint_schedules_args = model.getScheduleRulesets
      setpoint_schedules_args_hash = {}
      setpoint_schedules_args.each do |setpoint_schedules_arg|
        setpoint_schedules_args_hash[setpoint_schedules_arg.name.to_s] = setpoint_schedules_arg
      end
      # Loop through the hash to pull out the hash and name value to align display name and hash value
      setpoint_schedules_args_hash.sort.map do |key, value|
        setpoint_schedules_handles << value.handle.to_s
        setpoint_schedules << key
      end
      bedding_lighting_schedule = OpenStudio::Measure::OSArgument::makeChoiceArgument('flower_lighting_schedule',setpoint_schedules_handles,setpoint_schedules,true)
      bedding_lighting_schedule.setDisplayName('Choose the bedding Lighting Schedule')
      args << bedding_lighting_schedule

      # #pull the OS:Schedule:Day that corresponds to 12hr oon
      # day_schedules = OpenStudio::StringVector.new
      # day_schedules_handles = OpenStudio::StringVector.new
      # day_schedules_args = model.getScheduleDays
      # day_schedules_args_hash = {}
      # day_schedules_args.each do |day_schedules_arg|
      #   day_schedules_args_hash[day_schedules_arg.name.to_s] = day_schedules_arg
      # end
      # day_schedules_args_hash.sort.map do |key,value|
      #   day_schedules_handles << value.handle.to_s
      #   day_schedules << key
      # end
      # day_sched = OpenStudio::Measure::OSArgument::makeChoiceArgument('day_sched',day_schedules_handles,day_schedules,true)
      # day_sched.setDisplayName('Choose the day schedule for which the multiplier gets applied')
      # args << day_sched

      trim_value = OpenStudio::Measure::OSArgument.makeDoubleArgument('trim_value',true)
      trim_value.setDisplayName('Enter a multiplier for Full Power Trim')
      trim_value.setDescription('This value represents a mulitiplier eg 80% = 0.80 of full power for the Lighting Power within that space.  It works by trimming a specific lighting day schedule')
      args << trim_value

      bedding_cycle_input = OpenStudio::Measure::OSArgument.makeStringArgument('bedding_cycle_input',true)
      bedding_cycle_input.setDisplayName('Yes/No string argument for applying bedding cyle')
      args << bedding_cycle_input
    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    veg_space = runner.getOptionalWorkspaceObjectChoiceValue('veg_space', user_arguments, model)
    flower_space = runner.getOptionalWorkspaceObjectChoiceValue('flower_space', user_arguments, model)
    veg_space = veg_space.get.to_Space.get
    flower_space = flower_space.get.to_Space.get

    # passing the model object as well to the run method to pull the actual schedule object
    bedding_lighting_schedule = runner.getOptionalWorkspaceObjectChoiceValue('flower_lighting_schedule',user_arguments, model)
    bedding_lighting_schedule = bedding_lighting_schedule.get.to_ScheduleRuleset.get

    bedding_cycle_input = runner.getStringArgumentValue('bedding_cycle_input',user_arguments)
    trim_value = runner.getDoubleArgumentValue('trim_value',user_arguments)



    #  "yes/no on bedding"
    # this will work by taking space getting lights getting schedule and assigning new schedule

    if bedding_cycle_input == "Yes"
      flower_space.lights.each do |light|
        light.setSchedule(bedding_lighting_schedule)
        end
    else
      # do nothing
    end

    
    # Begin the full power trim portion
    #gets the schedule from the flower_space

    puts flower_space
    
    flower_lights = flower_space.lights

    puts "flower_lights"
    puts flower_lights

    flower_lighting_schedule = flower_lights[0].schedule
    
    flower_lighting_schedule = flower_lighting_schedule.get.to_ScheduleRuleset.get


    # day_sched = runner.getOptionalWorkspaceObjectChoiceValue('day_sched',user_arguments, model)
    # day_sched = day_sched.get.to_ScheduleDay.get


    # instead of using the direc ChoiceObject argument obtain the day_sched from the assigned lighting schedule
    day_sched = flower_lighting_schedule.defaultDaySchedule

    new_values = []
    if trim_value != 0
      puts "trim does not equal zero"
      
      puts "day_sched"
      puts day_sched
      values = day_sched.values
      puts "values"
      puts values
      times = day_sched.times
      puts "times"
      puts times

      values.each do |value|
        new_values << value*trim_value
      end
      
      puts new_values

      day_sched.clearValues

      for i in 0..(new_values.size-1)
        day_sched.addValue(times[i],new_values[i])
      end

      old_day_sched_name = day_sched.name
      day_sched.setName("#{old_day_sched_name} - edited by dimming multiplier #{trim_value}")

      puts day_sched


    end

    # report final condition of model
    runner.registerFinalCondition("The building finished with #{model.getSpaces.size} spaces.")

    return true
  end
end

# register the measure to be used by the application
CeaHorticultureLightingAdvancedControls.new.registerWithApplication
