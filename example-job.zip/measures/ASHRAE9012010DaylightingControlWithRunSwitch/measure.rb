#start the measure
class ASHRAE9012010DaylightingControlWithRunSwitch < OpenStudio::Ruleset::ModelUserScript

  #define the name that a user will see
  def name
    return "ASHRAE 90.1-2010 Daylighting Control with run switch"
  end
  #define the arguments that the user will input
  def arguments(model)
		args = OpenStudio::Ruleset::OSArgumentVector.new
		
		# Make integer arg to run measure [1 is run, 0 is no run]
		run_lightingcontrol = OpenStudio::Measure::OSArgument::makeBoolArgument("run_lightingcontrol",true)
		run_lightingcontrol.setDisplayName("Run Measure")
		# run_lightingcontrol.setDescription("integer argument to run measure [1 is run, 0 is no run]")
		run_lightingcontrol.setDefaultValue(true)
		args << run_lightingcontrol    
		 
		return args

  end #end the arguments method

  #define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

		
		#use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end
	# Return N/A if not selected to run
	run_lightingcontrol = runner.getBoolArgumentValue("run_lightingcontrol",user_arguments)
	if run_lightingcontrol == false
		runner.registerAsNotApplicable("Run Measure set to #{run_lightingcontrol}.")
		return true
	end
	
    #short def to make numbers pretty (converts 4125001.25641 to 4,125,001.26 or 4,125,001). The definition be called through this measure
    def neat_numbers(number, roundto = 2) #round to 0 or 2)
      if roundto == 2
        number = sprintf "%.2f", number
      else
        number = number.round
      end
      #regex to add commas
      number.to_s.reverse.gsub(%r{([0-9]{3}(?=([0-9])))}, "\\1,").reverse
    end #end def neat_numbers
	
	#create a floor area hash to use later
	floor_area_hash = {}
	model.getSpaces.each do |space|
	#create an empty array of all of the final window widths
	  space.surfaces.each do |surface|
	    #grab floor area to use for the depth calc 
		if surface.surfaceType == "Floor"
		  floor_area = surface.grossArea
		  floor_area_hash [space.name.to_s] = floor_area
		end
	  end
	end
	
	
	#find out if the spaces need daylighting because of windows
	#assign hash to use later
	primary_sidelighted_area_hash = {}
	daylighting_percent_hash = {}
	sidelighting_effective_aperture_hash = {}
	space_depth_hash = {}
	space_wall_hash = {}
	model.getSpaces.each do |space|
	#create an empty array of all of the final window widths
	window_widths = []
	depths = []
	#define a window area variable to use later
	window_area_vt = 0
	window_VTs = []
	#create a window area array to use later
	window_areas = []
	  space.surfaces.each do |surface|
	    #only grab walls with outdoor boundary condition
			if surface.outsideBoundaryCondition == "Outdoors" && surface.surfaceType == "Wall"
			#grab the surface vertices to use in the calc later
			wall_vertices = surface.vertices
			#get the wall area
			wall_area = surface.grossArea
			#grab the windows
				surface.subSurfaces.each do |sub_surface|
					if sub_surface.subSurfaceType == "FixedWindow" || "OperableWindow"
					window_vertices = sub_surface.vertices
					#check and see if there are not 4 vertices, if so this window will NOT count towards the primary sidelighted area
					count = 0
					window_vertices.each do |window_vertex|
						count = count + 1
					end
						if count != 4
						runner.registerWarning("#{sub_surface.name} does not have 4 vertices and will not be included in the Primary Sidelighted Area Calculation.")
						else
						#find the window width and the head height
						#use "%.3f" % right now in OS 1.4.1 Andrew said that the round(x) method will work, update then
						window_pair = [] #will use array later
							if "%.3f" % window_vertices[0].z == "%.3f" % window_vertices[1].z
							window_width = ((window_vertices[0].x - window_vertices[1].x)**2 + (window_vertices[0].y - window_vertices[1].y)**2)**0.5
						window_pair << window_vertices[0]
						window_pair << window_vertices[1]
						else 
							window_width = ((window_vertices[1].x - window_vertices[2].x)**2 + (window_vertices[1].y - window_vertices[2].y)**2)**0.5
						window_pair << window_vertices[1]
						window_pair << window_vertices[2]
							end
						#find the bottom wall points
						bottom_wall_points = []
						wall_vertices.each do |wall_vertex|
						if "%.3f" % wall_vertex.z == "0.000"
							bottom_wall_points << wall_vertex
							end
						end
						#find the x or y distance between the bottom wall points and the window points
						w2w_mins = []
						bottom_wall_points.each do |bottom_wall_point|
							w2w_distances = []
							window_pair.each do |window_point|
							w2w_distance = ((window_point.x - bottom_wall_point.x)**2 + (window_point.y - bottom_wall_point.y)**2)**0.5   
							w2w_distances << w2w_distance
						end
						w2w_mins << w2w_distances.min
							end
						#take the two w2w points, if they are >= 2ft then change then to 2 feet, otherwise do nothing
						final_w2w_mins = []
						w2w_mins.each do |w2w_min|
							if w2w_min >= 0.6096
							w2w_min = 0.6096
							final_w2w_mins << w2w_min
						else
							final_w2w_mins << w2w_min
						end
						end
						#now finally add the final w2w distances to the window widths
						sum_w2w = 0
						final_w2w_mins.each do |final_w2w_min|
							sum_w2w += final_w2w_min
						end
						final_window_width = window_width + sum_w2w
						window_widths << final_window_width
						#find the head height which is the greatest value for z for the window
						z_array = [window_vertices[0].z, window_vertices[1].z, window_vertices[2].z, window_vertices[3].z]
						headheight = z_array.max
						#get the distance from the exterior wall to the interior wall by using the area - not perfect but good enough
						wall_length = ((bottom_wall_points[0].x - bottom_wall_points[1].x)**2 + (bottom_wall_points[0].y - bottom_wall_points[1].y)**2)**0.5   
						floorarea = floor_area_hash [space.name.to_s]
						space_width = floorarea / wall_length
						#compare the headheight to the width and use the smallest value
						headheight_vs_space_width = []
						headheight_vs_space_width << headheight
						headheight_vs_space_width << space_width
						depths << headheight_vs_space_width.min
						#grab the window area
						window_area = sub_surface.grossArea
						window_areas << window_area
						window_VT = sub_surface.visibleTransmittance
						if window_VT.is_initialized
							window_VT = window_VT.get
						else
              assumed_vt = 0.6
              runner.registerWarning("Cannot determine the VLT from layer-by-layer glazing constructions, assuming #{assumed_vt}.")
              window_VT = assumed_vt
            end
						window_VTs << window_VT
						#add the walls to the hash
						space_wall_hash [space.name.to_s] = surface
						end #if count != 4
					end #if sub_surface.subSurfaceType ==
				end #surface.subSurfaces.each do |sub_surface|
			end #if surface.outsideBoundaryCondition == "Outdoors"
	  end #space.surfaces.each do |surface|
	#sum all of the window widths for the space
	width = 0
	  window_widths.each do |window_width|
		width += window_width
	  end
	depth = depths.min
	space_depth_hash [space.name.to_s] = depth
	  if depth == nil
	primary_sidelighted_area = 0
	  else
	#need to make a fix for is the width or depth is nil
	primary_sidelighted_area = width * depth
	  end
	primary_sidelighted_area_hash [space] = primary_sidelighted_area
	#calc the sidelighting_effective_aperture for exception 9.4.1.4.b
	total_window_area = 0
	window_areas.each do |area|
	  total_window_area += area
	end
	sum_window_vt = 0
	window_VTs.each do |vt|
      sum_window_vt += vt
	end
	if window_VTs.size == 0
	  avg_window_VT = 0
	elsif avg_window_VT = sum_window_vt / window_VTs.size
	end
	window_area_vt = avg_window_VT * total_window_area
	#get the sidelighting_effective_aperture and put into hash
	if primary_sidelighted_area == 0
	  sidelighting_effective_aperture = 0
	else sidelighting_effective_aperture = window_area_vt / primary_sidelighted_area
	end
	sidelighting_effective_aperture_hash [space.name.to_s] = sidelighting_effective_aperture
	end #model.getSpaces.each do |space|
	
	
	#create an array of all the spaces that have a primary sidelighted area of more then 250 ft2
	daylight_spaces = []
	primary_sidelighted_area_hash.each do |key, value|
	  #add a if statement for exception c, retail spaces
	  if key.name.to_s.include? "Retail" || "retail"
	    runner.registerInfo("#{key.name.to_s} has retail in its name and will not have daylighting controls due to ASHRAE 90.1 2010 exception 9.4.1.4.c")
	  #add a if statement for exception b, sidelighting effective aperture of less than 10%
	  elsif value >= 23.2258 #250 ft2 in m2
	    daylight_spaces << key
	  end
	end
	
	#add the spaces to an array that have a sidelighting effective aperture of less than 10%
	exception_b_spaces = []
	sidelighting_effective_aperture_hash.each do |k, v|
	  if v <= 0.1
	    exception_b_spaces << k
	  end
	end
	
	#loop through the daylight spaces and remove the spaces that are in the exception_b_spaces array
	daylight_spaces.each do |dl_space|
	  exception_b_spaces.each do |exception_b_space|
	    if exception_b_space == dl_space.name.to_s
		  daylight_spaces.delete(dl_space)
		  runner.registerInfo("#{exception_b_space} has a sidelighting effective aperture of less than 10% and will not have daylighting controls due to ASHRAE 90.1 2010 exception 9.4.1.4.b")
		end
	  end
	end


	#find the spaces that need daylighting because of toplighting
	skylight_area_hash = {}
	toplighting_ea_hash = {}
	model.getSpaces.each do |space|
	toplighted_areas = []
	skylight_area_VTs = []
	skylight_daylight_areas = []
	  space.surfaces.each do |surface|
	    if surface.outsideBoundaryCondition == "Outdoors" && surface.surfaceType == "RoofCeiling"
		  roof_area = surface.grossArea
			roof_vertices = surface.vertices
				surface.subSurfaces.each do |sub_surface|
					if sub_surface.subSurfaceType == "Skylight"
					skylight_vertices = sub_surface.vertices
					#check and see if there are not 4 vertices, if so this window will NOT count towards the primary sidelighted area
					count = 0
						skylight_vertices.each do |skylight_vertex|
						count = count + 1
						end
						if count != 4
						runner.registerWarning("#{sub_surface.name} does not have 4 vertices and will not be included in the Primary Toplighted Area Calculation.")
						else
						#get the skylight width and height
						skylight_width = ((skylight_vertices [0].x - skylight_vertices [1].x)**2 + (skylight_vertices [0].y - skylight_vertices [1].y)**2)**0.5
						skylight_length = ((skylight_vertices [0].x - skylight_vertices [3].x)**2 + (skylight_vertices [0].y - skylight_vertices [3].y)**2)**0.5
						#get the ceiling height
						ceiling_height = skylight_vertices [0].z
						ch_70 = 0.7 * ceiling_height
						#find the distance from the skylight to the edge of the wall 
						#get the distances between the points on the roof
						roof_length_1 = ((roof_vertices [0].x - roof_vertices [1].x)**2 + (roof_vertices [0].y - roof_vertices [1].y)**2)**0.5
						roof_length_2 = ((roof_vertices [1].x - roof_vertices [2].x)**2 + (roof_vertices [1].y - roof_vertices [2].y)**2)**0.5
						roof_length_3 = ((roof_vertices [2].x - roof_vertices [3].x)**2 + (roof_vertices [2].y - roof_vertices [3].y)**2)**0.5
						roof_length_4 = ((roof_vertices [3].x - roof_vertices [0].x)**2 + (roof_vertices [3].y - roof_vertices [0].y)**2)**0.5
						#find the skylight point that is closest to the roof points 0
						roof_vertex_0_skylight_vertex_0 = ((roof_vertices [0].x - skylight_vertices [0].x)**2 + (roof_vertices [0].y - skylight_vertices [0].y)**2)**0.5
						roof_vertex_0_skylight_vertex_1 = ((roof_vertices [0].x - skylight_vertices [1].x)**2 + (roof_vertices [0].y - skylight_vertices [1].y)**2)**0.5
						roof_vertex_0_skylight_vertex_2 = ((roof_vertices [0].x - skylight_vertices [2].x)**2 + (roof_vertices [0].y - skylight_vertices [2].y)**2)**0.5
						roof_vertex_0_skylight_vertex_3 = ((roof_vertices [0].x - skylight_vertices [3].x)**2 + (roof_vertices [0].y - skylight_vertices [3].y)**2)**0.5
						roof_vertex_0_array = [roof_vertex_0_skylight_vertex_0, roof_vertex_0_skylight_vertex_1, roof_vertex_0_skylight_vertex_2, roof_vertex_0_skylight_vertex_3]
						roof_vertex_0_closest_distance = roof_vertex_0_array.min
						if roof_vertex_0_skylight_vertex_0 == roof_vertex_0_closest_distance
						  roof_vertex_0_closest_point = skylight_vertices [0]
						elsif roof_vertex_0_skylight_vertex_1 == roof_vertex_0_closest_distance
						  roof_vertex_0_closest_point = skylight_vertices [1]
						elsif roof_vertex_0_skylight_vertex_2 == roof_vertex_0_closest_distance
						  roof_vertex_0_closest_point = skylight_vertices [2]
						elsif roof_vertex_0_skylight_vertex_3 == roof_vertex_0_closest_distance
						  roof_vertex_0_closest_point = skylight_vertices [3]
						end
						#find the skylight point that is closest to the roof points 2
						roof_vertex_2_skylight_vertex_0 = ((roof_vertices [2].x - skylight_vertices [0].x)**2 + (roof_vertices [2].y - skylight_vertices [0].y)**2)**0.5
						roof_vertex_2_skylight_vertex_1 = ((roof_vertices [2].x - skylight_vertices [1].x)**2 + (roof_vertices [2].y - skylight_vertices [1].y)**2)**0.5
						roof_vertex_2_skylight_vertex_2 = ((roof_vertices [2].x - skylight_vertices [2].x)**2 + (roof_vertices [2].y - skylight_vertices [2].y)**2)**0.5
						roof_vertex_2_skylight_vertex_3 = ((roof_vertices [2].x - skylight_vertices [3].x)**2 + (roof_vertices [2].y - skylight_vertices [3].y)**2)**0.5
						roof_vertex_2_array = [roof_vertex_2_skylight_vertex_0, roof_vertex_2_skylight_vertex_1, roof_vertex_2_skylight_vertex_2, roof_vertex_2_skylight_vertex_3]
						roof_vertex_2_closest_distance = roof_vertex_2_array.min
						if roof_vertex_2_skylight_vertex_0 == roof_vertex_2_closest_distance
						  roof_vertex_2_closest_point = skylight_vertices [0]
						elsif roof_vertex_2_skylight_vertex_1 == roof_vertex_2_closest_distance
						  roof_vertex_2_closest_point = skylight_vertices [1]
						elsif roof_vertex_2_skylight_vertex_2 == roof_vertex_2_closest_distance
						  roof_vertex_2_closest_point = skylight_vertices [2]
						elsif roof_vertex_2_skylight_vertex_3 == roof_vertex_2_closest_distance
						  roof_vertex_2_closest_point = skylight_vertices [3]
						end
						#now find the distance from the closest point to the wall for each of the points
						rv_0_triangle_1_area = 0.5 * (((roof_vertex_0_closest_point.x - roof_vertices [1].x) * (roof_vertices [0].y - roof_vertex_0_closest_point.y)) - ((roof_vertex_0_closest_point.x - roof_vertices [0].x) * (roof_vertices [1].y - roof_vertex_0_closest_point.y))).abs
						rv_0_distance_1 = (2 * rv_0_triangle_1_area) / roof_length_1
						rv_0_triangle_3_area = 0.5 * (((roof_vertex_0_closest_point.x - roof_vertices [3].x) * (roof_vertices [0].y - roof_vertex_0_closest_point.y)) - ((roof_vertex_0_closest_point.x - roof_vertices [0].x) * (roof_vertices [3].y - roof_vertex_0_closest_point.y))).abs
						rv_0_distance_3 = (2 * rv_0_triangle_3_area) / roof_length_4
						
						rv_2_triangle_1_area = 0.5 * (((roof_vertex_2_closest_point.x - roof_vertices [1].x) * (roof_vertices [2].y - roof_vertex_2_closest_point.y)) - ((roof_vertex_2_closest_point.x - roof_vertices [2].x) * (roof_vertices [1].y - roof_vertex_2_closest_point.y))).abs
						rv_2_distance_1 = (2 * rv_2_triangle_1_area) / roof_length_2
						rv_2_triangle_3_area = 0.5 * (((roof_vertex_2_closest_point.x - roof_vertices [3].x) * (roof_vertices [2].y - roof_vertex_2_closest_point.y)) - ((roof_vertex_2_closest_point.x - roof_vertices [2].x) * (roof_vertices [3].y - roof_vertex_2_closest_point.y))).abs
						rv_2_distance_3 = (2 * rv_2_triangle_3_area) / roof_length_3
						
						#now compare the ch_70 to the rv distance and get the smallest value
						distance_1 = [ch_70, rv_0_distance_1].min
						distance_2 = [ch_70, rv_0_distance_3].min
						distance_3 = [ch_70, rv_2_distance_1].min
						distance_4 = [ch_70, rv_2_distance_3].min
						
						#get the total skylight area
						toplighted_area = (skylight_width + distance_1 + distance_3) * (skylight_length + distance_2 + distance_4)
						toplighted_areas << toplighted_area
						
						#get the skylight VT
						skylight_VT = sub_surface.visibleTransmittance
							if skylight_VT.is_initialized
							skylight_VT = skylight_VT.get
							skylight_area = skylight_width * skylight_length
								skylight_area_VT = 0.85 * skylight_area * skylight_VT * 0.9
								skylight_area_VTs << skylight_area_VT
							else
                assumed_vt = 0.6
                runner.registerWarning("Cannot determine the VLT from layer-by-layer glazing constructions, assuming #{assumed_vt}.")
                skylight_VT = assumed_vt
								skylight_area_VT = 0.85 * skylight_area * skylight_VT * 0.9
								skylight_area_VTs << skylight_area_VT
              end

						end #if count != 4
					end #if sub_surface.subSurfaceType == "Skylight"
				end #surface.subSurfaces.each do |sub_surface| 
			end #if surface.outsideBoundaryCondition 
	  end #space.surfaces.each do |surface|
	total_toplighted_area = 0
		toplighted_areas.each do |area|
	  total_toplighted_area += area
		end
	skylight_area_hash [space] = total_toplighted_area
	total_daylighted_area = primary_sidelighted_area_hash [space] + total_toplighted_area
	floorarea = floor_area_hash [space.name.to_s]
	daylighting_percent = total_daylighted_area / floorarea
		if daylighting_percent > 1.0
	  daylighting_percent = 1.0
		end
	daylighting_percent_hash [space.name.to_s] = daylighting_percent
	#get the skylight effective aperture for the space
	sum_skylight_area_VT = 0
	skylight_area_VTs.each do |area_vt|
      sum_skylight_area_VT += area_vt
	end
	if total_toplighted_area == 0
	ea = nil
	elsif
	ea = sum_skylight_area_VT / total_toplighted_area
	toplighting_ea_hash [space.name.to_s] = ea
	end
	end #model.getSpaces.each do |space|
  
	
	#add the spaces that have greater then 900 SF of toplighted area to the daylight_spaces array unless they are already there
	skylight_area_hash.each do |k, v|
		if v > 83.6127 #900 ft2 in m2 
		daylight_spaces << k unless daylight_spaces.include?(k)
		end
	end
	
	#add the spaces to an array that have a toplighting effective aperture of less than 0.6%
	top_exception_b_spaces = []
	toplighting_ea_hash.each do |k, v|
	  if v <= 0.006
	    top_exception_b_spaces << k
	  end
	end
	
	#loop through the daylight spaces and remove the spaces that are in the top_exception_b_spaces array
	daylight_spaces.each do |dl_space|
	  top_exception_b_spaces.each do |exception_b_space|
	    if exception_b_space == dl_space.name.to_s
		  daylight_spaces.delete(dl_space)
		  runner.registerInfo("#{exception_b_space} has a toplighting effective aperture of less than 0.6% and will not have daylighting controls due to ASHRAE 90.1 2010 exception 9.4.1.5.b")
		end
	  end
	end
	
	#loop through the spaces with a sidelighted area of more then 25 ft2 (2.33 m2) and add a daylight sensor in the middle of the space
	daylight_spaces.each do |daylight_space|
	  #find the floors of the space
	  floors = []
	  daylight_space.surfaces.each do |surface|
	    if surface.surfaceType == "Floor"
		floors << surface
		end
	  end
	  
	  #this method only works for flat (non-inclined) floors
      boundingBox = OpenStudio::BoundingBox.new
      floors.each do |floor|
        boundingBox.addPoints(floor.vertices)
      end
      xmin = boundingBox.minX.get
      ymin = boundingBox.minY.get
      zmin = boundingBox.minZ.get
      xmax = boundingBox.maxX.get
      ymax = boundingBox.maxY.get
	  
	  #create a new sensor and put at the center of the space
	  sensor = OpenStudio::Model::DaylightingControl.new(model)
      sensor.setName("#{daylight_space.name.to_s} daylighting control")
      x_pos = (xmin + xmax) / 2
      y_pos = (ymin + ymax) / 2
      z_pos = zmin + 1 #put it 1 meter above the floor
      new_point = OpenStudio::Point3d.new(x_pos, y_pos, z_pos)
      sensor.setPosition(new_point)
      sensor.setIlluminanceSetpoint(538.2) #in lux, this is 50 fc
      sensor.setLightingControlType("Stepped")
      sensor.setNumberofSteppedControlSteps(2) #0%, 50%, 100%, does this meet code???
      sensor.setSpace(daylight_space)
	  
	  #assign the daylighting control to the zone
	  daylight_zone = daylight_space.thermalZone 
	    if daylight_zone.is_initialized
		  daylight_zone = daylight_zone.get
	      daylight_zone.setPrimaryDaylightingControl(sensor)
		  daylight_fraction = daylighting_percent_hash[daylight_space.name.to_s]
	      daylight_zone.setFractionofZoneControlledbyPrimaryDaylightingControl(daylight_fraction)
		end

	end #daylight_spaces.each do |daylight_space|
	
	#report spaces that had daylighting add to them
	daylight_space_names = []
	daylight_spaces.each do |daylight|
	  daylight_space_names << daylight.name.to_s
	end
	runner.registerInfo("ASHRAE 90.1 2010 daylighting controls have been added to spaces #{daylight_space_names}")

	
	
    return true

  end #end the run method

end #end the measure

#this allows the measure to be used by the application
ASHRAE9012010DaylightingControlWithRunSwitch.new.registerWithApplication